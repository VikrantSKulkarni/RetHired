<?php 
$user_id = $_GET['user_id'];
// echo $user_id;
//die();
if($user_id){

    $resume_url = get_user_meta($user_id,'resume',true);
  
    $attachment_id = attachment_url_to_postid($resume_url);
    // echo $attachment_id;die();
    if ($attachment_id) {
    
        // Delete the attachment
        wp_delete_attachment($attachment_id, true); 
        update_user_meta($user_id, 'resume', '');
        $_SESSION['message'] = "User resume deleted !";
        
        echo "<script>window.location.href='".site_url('candidate-resume')."';</script>";    
    }else{
        //echo "Not Deleted";
        $_SESSION['message'] = "Error in deleting resume !";
        echo "<script>window.location.href='".site_url('candidate-resume')."';</script>";
    }
}
?>