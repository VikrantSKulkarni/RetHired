<?php
include(get_template_directory() . '/template-parts/content-dashboard-header.php');
if (!is_user_logged_in()){
    $_SESSION['message'] = 'Please log in as Employer';
    $_SESSION['redirect_to'] = get_permalink();
    echo "<script>window.location.href='".site_url('login')."'</script>";
    exit;
}else{
    if(current_user_can('subscriber')){
        $_SESSION['message'] = 'Please log in as Employer';
        echo "<script>window.location.href='".site_url('login')."'</script>";
        exit;
    }
}?>
<!-- Dashboard start -->
<div class="dashboard dash-margin">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 p-0">
                <?php get_sidebar();?>
            </div>
            <div class="col-lg-9 col-md-12 col-sm-12 p-0">
                <div class="dashboard-content"> 
                    <div class="dashboard-header clearfix">
                        <div class="row">
                            <div class="col-sm-12 col-md-6"><h4>Post a Job</h4></div>
                            <div class="col-sm-12 col-md-6">
                                <div class="breadcrumb-nav">
                                    <ul>
                                        <li>
                                            <a href="<?php echo home_url(); ?>">Home</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo site_url('employer-dashboard'); ?>">Dashboard</a>
                                        </li>
                                        <li>
                                            <a  class="active" href="<?php echo site_url('create-a-job'); ?>">Post a Job</a>
                                        </li>
                                    </ul>
                                </div>
                            </div> 
                        </div>
                    </div>
                    <?php if(isset($_SESSION['message'])){?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['message']; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php }
                    unset($_SESSION['message']);?>
                     <?php if(isset($_SESSION['error-message'])){?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['error-message']; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php }
                    unset($_SESSION['error-message']);?>
                    <div class="submit-address dashboard-list">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <h4 class="bg-grea-3">Basic Information</h4>
                            <div class="search-contents-sidebar">
                                <div class="row pad-20">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Job Title (<span class="text-danger">*</span>)</label>
                                            <input type="text" class="input-text" name="job_title" placeholder="Job Title" required maxlength="70">
                                            <input type="hidden" name="author_id" id="" value="<?php echo get_current_user_id();?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Job Type (<span class="text-danger">*</span>)</label></label>
                                            <select class="form-control" name="job_type" required>
                                                <option value="0"> -- Select Job Type -- </option>
                                                <option value="Full Time"> Full Time </option>
                                                <option value="Part Time"> Part Time </option>
                                                <option value="Freelance"> Freelance </option>
                                                <option value="Temporary"> Temporary </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                            <label for="job_category">Job Category (<span class="text-danger">*</span>)</label>
                                            <select class="form-control" id="job_category" name="job_category" required>
                                                <?php
                                                $categories = get_terms(array(
                                                    'taxonomy'   => 'job_category',
                                                    'hide_empty' => false,
                                                )); ?>
                                                <option value="0">--Select Category --</option>
                                                <?php foreach ($categories as $category) {
                                                ?>
                                                    <option value="<?php echo $category->term_id; ?>"><?php echo $category->name; ?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Location (<span class="text-danger">*</span>)</label> </label>
                                            <input type="text" class="input-text" name="location" placeholder="Location" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                     <div class="form-group">
                                            <label>Salary (<span class="text-danger">*</span>) (per month)</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">₹</span>
                                                </div>
                                                <input type="number" class="form-control" name="monthly_payment" placeholder="Amount in Rupees" required>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Work Hours (<span class="text-danger">*</span>) (in a week ) </label>
                                            <input type="text" class="input-text" name="weekly_time" placeholder="Work Hour" required >
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Qualification (<span class="text-danger">*</span>)</label>
                                            <select class="form-control" name="qualification" required>
                                                <option value="0"> -- Select Qualification -- </option>
                                                <option value="Bsc">Bsc</option>
                                                <option value="B.A.">B.A.</option>
                                                <option value="B.Com">B.Com</option>
                                                <option value="Bsc(Computer)">Bsc(Computer)</option>
                                                <option value="BSc(Maths)">BSc(Maths)</option>
                                                <option value="BSc(computer application)">BSc (computer application)</option>
                                                <option value="MSc(computer science)">MSc (computer science)</option>
                                                <option value="MSc">MSc</option>
                                                <option value="M.E">M.E</option>
                                                <option value="Any Graduate">Any Graduate </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Experience (<span class="text-danger">*</span>) <small class="text-muted">(e.g. 1, 2,...etc)</small></label>
                                            <input type="number" class="input-text" name="experience" placeholder="Experience" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Skills (<span class="text-danger">*</span>) <small class="text-muted">(e.g. skill1, skill2,...etc)</small> </label>
                                            <input type="text" class="input-text" name="skills" placeholder="Skills" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Application End Date (<span class="text-danger">*</span>)</label>
                                            <input type="date" class="input-text" min ="<?php echo date("Y-m-d"); ?>" name="application_end_date" placeholder="Application End Date" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label>Job Description (<span class="text-danger">*</span>)</label>
                                            <textarea class="input-text" name="job_description" placeholder="Detailed Information" required></textarea>
                                        </div>
                                    </div>
                                    <div class="col-12"><label for="iamge">Featured Image (Optional) : </label></div>
                                    <div class="col-lg-12">
                                        <img id="imagePreview" style="height:150px; margin-bottom:5px;" src="https://placehold.co/100x100" alt="">
                                        <button id="rmBtn" type="button" onclick="removeImage();"; style="display:none;font-size:34px;border:none;background:none;">&times;</button>
                                        <div class="photoUpload photoUpload-2">
                                            Upload Files
                                            <input type="file" class="upload" name="jobImage"  onchange="previewImage(event)">
                                        </div>
                                    </div>
                                    <div class="col-12"><label for="iamge">Banner Image (Optional) : </label></div>
                                    <div class="col-lg-12">
                                        <img id="bannerImagePreview" style="height:150px; margin-bottom:5px;" src="https://placehold.co/1920x355" alt="">
                                        <button id="rmBannerBtn" type="button" onclick="removeBannerImage();"; style="display:none;font-size:34px;border:none;background:none;">&times;</button>
                                        <div class="photoUpload photoUpload-2">
                                            Upload Files
                                            <input type="file" class="upload" name="jobBannerImage"  onchange="previewBannerImage(event)">
                                        </div>
                                        <div class="post-btn"><button type="submit" name="submit" class="btn btn-md button-theme">Post a job</button></div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php get_footer('secondary'); ?>
            </div>
        </div>
    </div>
</div>
<!-- Dashboard end -->
<br><br><br><br>
<!-- Full Page Search -->
<div id="full-page-search">
    <button type="button" class="close">X</button>
    <form action="index.html#">
        <input type="search" value="" placeholder="type keyword(s) here" />
        <button type="submit" class="btn btn-sm button-theme">Search</button>
    </form>
</div>

<?php 
    if(isset($_POST['submit'])){
        $author_id = sanitize_text_field($_POST['author_id']);
        $job_title = sanitize_text_field($_POST['job_title']);
        //echo $job_title;
        $job_description = sanitize_text_field($_POST['job_description']);
        //echo $job_description;
        $qualification = sanitize_text_field($_POST['qualification']);
        //echo $qualification;
        $monthly_payment = sanitize_text_field($_POST['monthly_payment']);
        //echo $monthly_payment;
        $location = sanitize_text_field($_POST['location']);
        //echo $location;
        
        $experience = sanitize_text_field($_POST['experience']);
        //echo $experience;
        
        $job_type = sanitize_text_field($_POST['job_type']);
        //echo $job_type;
        
        $job_category =sanitize_text_field( $_POST['job_category']);
        //echo  $job_category;       
        $weekly_time = sanitize_text_field($_POST['weekly_time']);
        //echo  $weekly_time;
        $application_end_date = sanitize_text_field($_POST['application_end_date']);
        //echo  $application_end_date;
        $skills = sanitize_text_field($_POST['skills']);
        //echo  $skills;
        if (empty($job_title) || empty($location) || empty($experience) || empty($job_description) || empty($monthly_payment) || empty($weekly_time) || empty($skills) || empty($application_end_date)) {
            $_SESSION['error-message'] = "One or more fields are empty !";
            echo "<script>window.location.href='".site_url('create-a-job')."'</script>";
            exit;
        }
        $post = array(
            'post_author' => $author_id,
            'post_type' => 'job-post',
            'post_title' => $job_title,
            'post_content' =>$job_description,
            'post_status' => 'publish',
       );
    
        // Insert the post
        $post_id = wp_insert_post($post);

    // Upload image
    if ($_FILES['jobImage']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = wp_upload_dir();
        $image_path = $upload_dir['path'] . '/' . $_FILES['jobImage']['name'];
        move_uploaded_file($_FILES['jobImage']['tmp_name'], $image_path);

        // Create attachment
        $attachment = array(
            'post_mime_type' => $_FILES['jobImage']['type'],
            'post_title' => sanitize_file_name($_FILES['jobImage']['name']),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attach_id = wp_insert_attachment($attachment, $image_path);

        // Set featured image
        if ($attach_id) {
            set_post_thumbnail($post_id, $attach_id);
        }
    }

     // Upload image
     if ($_FILES['jobBannerImage']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = wp_upload_dir();
        $tmp_name = $_FILES['jobBannerImage']['tmp_name'];
        // Get image size
        list($width, $height) = getimagesize($tmp_name);
        if ($width == 1920 && $height == 355) {
            $image_path = $upload_dir['path'] . '/' . $_FILES['jobBannerImage']['name'];
            move_uploaded_file($_FILES['jobBannerImage']['tmp_name'], $image_path);

            // Create attachment
            $attachment = array(
                'post_mime_type' => $_FILES['jobBannerImage']['type'],
                'post_title' => sanitize_file_name($_FILES['jobBannerImage']['name']),
                'post_content' => '',
                'post_status' => 'inherit'
            );
            $banner = wp_insert_attachment($attachment, $image_path);
            update_field('job_post_banner',$banner,$post_id);
        }else{
            $_SESSION['error-message'] ="Error: The image must be exactly 1920x355 pixels.";
            echo "<script type='text/javascript'>window.location.href='".site_url( 'create-a-job' )."'</script>";
        }
    }
    wp_set_post_terms($post_id, array($job_category), 'job_category');

        update_field('job_title',$job_title,$post_id);
        update_field('skills',$skills,$post_id);
        update_field('qualification', $qualification, $post_id);
        update_field('status', 'Active', $post_id);
        update_field('location', $location, $post_id);
        update_field('experience_required', $experience, $post_id);
        update_field('job_type', $job_type, $post_id);
        update_field('weekly_time_demand', $weekly_time, $post_id);
        update_field('monthly_payment', $monthly_payment, $post_id);
        update_field('application_end_date', $application_end_date, $post_id);

        $_SESSION['message'] = "Job Post Created Succefully";
        echo "<script type='text/javascript'>window.location.href='". site_url("employer-job-list") ."'</script>";
    }
?>