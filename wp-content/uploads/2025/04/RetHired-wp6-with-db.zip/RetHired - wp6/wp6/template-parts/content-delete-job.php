<?php 
    $postId = $_GET['post_id'];
    wp_delete_post($postId, true);
    $_SESSION['message'] = "Job post deleted succefully!";
    echo "<script> window.location.href='".site_url('employer-job-list')."'</script>";
?>