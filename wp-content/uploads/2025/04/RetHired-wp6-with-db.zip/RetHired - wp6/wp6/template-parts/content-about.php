<style>
    .sub-banner{
        background: rgba(0, 0, 0, 0.04) url(<?php echo get_theme_file_uri("/img/job_list_bg3.png"); ?>) top left repeat;
    }
    .counters{
        background-image: url('<?php echo get_theme_file_uri("/img/counter.jpg"); ?>');
    }
</style>
<?php get_header(); ?>
<!-- Sub banner start -->
<div class="sub-banner bg-color-full">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>About Us</h1>
            <ul class="breadcrumbs">
                <li><a href="index.html">Home</a></li>
                <li class="active">About Us</li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub banner end -->

<!-- About us start -->
<div class="about-us content-area-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-7 col-12">
                <div class="about-slider-box simple-slider">
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img class="d-block w-100" src="<?php echo get_template_directory_uri()?>/img/about1.jpeg" alt="slide">
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" src="<?php echo get_template_directory_uri()?>/img/about2.jpeg" alt="slide">
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" src="<?php echo get_template_directory_uri()?>/img/about3.jpeg" alt="slide">
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" src="<?php echo get_template_directory_uri()?>/img/about4.jpeg" alt="slide">
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <span class="slider-mover-left slider-btn btn-left" aria-hidden="true">
                                <i class="fa fa-angle-left"></i>
                            </span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <span class="slider-mover-right slider-btn btn-right" aria-hidden="true">
                                 <i class="fa fa-angle-right"></i>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-5 col-12 align-content-around">
                <div class="about-text">
                    <h3>Welcome To <?php echo get_bloginfo('title'); ?></h3>
                    <p>
                        At ReHired, we believe retirement doesn’t mean slowing down. Our job portal connects retirees with part-time work that fits their schedule, allowing them to stay active, engaged, and fulfilled. Whether you're looking to share your expertise or explore new opportunities, ReHired offers flexible roles to help you make the most of your time, working just 2-3 hours a day. 
                    </p>
                    <p>
                        Join our community of motivated retirees who are redefining what it means to retire. With ReHired, you can find meaningful work that not only keeps you busy but also brings a sense of purpose and accomplishment. Stay connected, make new friends, and continue contributing to the workforce on your own terms.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About us end -->

<!-- Services start -->
<div class="services content-area-3">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Our Service</h1>
            <p>ReHired connects retirees with flexible, part-time jobs that fit their lifestyle, helping them stay active and engaged.</p>
        </div>
        <div class="row mb-5">
            <div class="col-lg-4 col-sm-6 mb-3">
                <div class="service-info">
                    <div class="icon">
                        <i class="flaticon-work"></i>
                    </div>
                    <h5>Advertise A Job</h5>
                    <p>Reach experienced candidates by posting your job openings with ReHired</p>
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 mb-3">
                <div class="service-info">
                    <div class="icon">
                        <i class="flaticon-search"></i>
                    </div>
                    <h5>CV Search</h5>
                    <p>Find qualified retirees quickly with our easy-to-use CV search feature.</p>
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 mb-3 d-none d-lg-block">
                <div class="service-info">
                    <div class="icon">
                        <i class="flaticon-user"></i>
                    </div>
                    <h5>Recruiter Profiles</h5>
                    <p>Connect with top recruiters specializing in part-time and retiree talent.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Services end -->

<!-- Counters strat -->
<div class="counters bg-color-full-2">
    <div class="container">
        <div class="row">
        <?php $users = get_users(); ?>
            <div class="col-md-3 col-6">
                <div class="counter-box">
                    <i class="flaticon-user"></i>
                    <h1 class="counter"><?php echo count($users);?></h1>
                    <p>Members</p>
                </div>
            </div>
            <?php 
            $args = array( 'post_type' => 'job-post','posts_per_page' => -1,'meta_key'=>'status',
            'meta_value'   => 'Active');
            $query  = new WP_Query( $args );
            if ($query->have_posts()) : 
                while ($query->have_posts()) : $query->the_post(); ?>
                <?php $post_count = $query->post_count; ?>
                <?php endwhile; wp_reset_postdata(); endif; ?>
                <div class="col-md-3 col-6">
                    <div class="counter-box">
                        <i class="flaticon-work"></i>
                        <h1 class="counter"><?php echo $post_count; ?></h1>
                        <p>Jobs</p>
                    </div>
                </div>
                <?php $users = get_users();
                $resume_count = 0;
                $company_count = 0;

                foreach($users as $user) {
                    $resume = get_user_meta($user->ID, 'resume', true);
                    $company = get_user_meta($user->ID, 'current_company', true);
                    
                    if (!empty($resume)) { // Check if resume meta exists and is not empty
                        $resume_count++;
                    }
                    if (!empty($company)) { // Check if resume meta exists and is not empty
                        $company_count++;
                    }
                }
            ?>
            <div class="col-md-3 col-6">
                <div class="counter-box">
                    <i class="flaticon-document"></i>
                    <h1 class="counter"><?php echo $resume_count; ?></h1>
                    <p>Resumes</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="counter-box">
                    <i class="flaticon-factory"></i>
                    <h1 class="counter"><?php echo $company_count; ?></h1>
                    <p>Companies</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Counters end -->

<!-- Testimonial start -->
<div class="testimonial">
    <div class="container">
        <div class="main-title">
            <h1>What Our Users Say</h1>
            <p>Real stories from retirees enjoying flexible work that fits their lifestyle.</p>
        </div>
        <div class="slick-slider-area">
            <div class="row slick-carousel" data-slick='{"slidesToShow": 2, "responsive":[{"breakpoint": 1024,"settings":{"slidesToShow": 2}}, {"breakpoint": 768,"settings":{"slidesToShow": 1}}]}'>
            <?php 
            $args = array(
                'post_type' => 'testimonial',
                'posts_per_page' => -1,
            );
            $query = new WP_Query($args);
            
            // List view container
            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post(); ?>
                <div class="slick-slide-item">
                    <div class="testimonial-inner">
                        <div class="content-box">
                            <p><?php echo get_the_content(); ?></p>
                        </div>
                        <div class="media">
                            <a href="#">
                                <?php $url  = get_the_post_thumbnail_url(get_the_ID());?>
                                <img src="<?php if($url){ echo $url;}else { echo 'http://placehold.it/50x50';}?>" alt="testimonial-avatar" class="img-fluid">
                            </a>
                            <div class="media-body align-self-center">
                                <h5>
                                    <?php echo get_the_title();?>
                                </h5>
                                <h6><?php echo get_field('designation'); ?></h6>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                endwhile;  
                wp_reset_postdata();
                endif;
                ?>
            </div>
        </div>
    </div>
</div>
<!-- Testimonial end -->
<?php get_footer(); ?>