<?php
$userID = $_GET['user_id'];
$post_id = $_GET['post_id'];

if($userID and $post_id ){
    $applied  = update_user_meta($userID,'working_status','Released');
    $applied_post_id  = update_user_meta($userID,'working_status_post_id','');
  
    $candidate = get_user_by('ID', $userID);
    if ($candidate) {
        $candidate_id = $candidate->ID;
        $candidate_name = $candidate->display_name;
        $candidate_email = $candidate->user_email;
        $candidate_resume = '';

        $applied_date = date('Y-m-d');

        $working_status = get_user_meta($candidate->ID, 'working_status', true);

        $repeater_field_name = 'job_applicant';

        $existing_candidates = get_field($repeater_field_name, $post_id);

        if ($existing_candidates) {
            // Find the candidate in the array and update the working_status
            foreach ($existing_candidates as &$existing_candidate) {
                if ($existing_candidate['user_id'] == $candidate_id) {
                    $existing_candidate['working_status'] = $working_status;
                    break; // Stop the loop once the candidate is found and updated
                }
            }
            unset($existing_candidate); // Unset the reference to the last element
            $updated_candidates = $existing_candidates;
        } else {
            // If no candidates exist yet, create a new array with the new candidate data
            $updated_candidates = array(
                array(
                    'user_id' => $candidate_id,
                    'name' => $candidate_name,
                    'email' => $candidate_email,
                    'resume' => $candidate_resume,
                    'application_status' => 'Applied',
                    'applied_date' => $applied_date,
                    'working_status' => $working_status
                )
            );
        }

        // Update the repeater field for the current post
        update_field($repeater_field_name, $updated_candidates, $post_id);
 
    if($applied){
        $_SESSION['message'] = "Candidate Released successfully";
        $url = site_url() . "/candidate-view-profile/?user_id=" . $candidate_id . "&post_id=" . $post_id;
        echo "<script type='text/javascript'>window.location.href='$url';</script>";
    }
}
}

// if($userID){
//     $applied  = update_user_meta($userID,'working_status','Released');
//     if($applied){
//         $_SESSION['message'] = "Candidaet has been released successfully";
//         echo "<script type='text/javascript'>window.location.href='". site_url("home") ."'</script>";        
//     }
// }
?>
