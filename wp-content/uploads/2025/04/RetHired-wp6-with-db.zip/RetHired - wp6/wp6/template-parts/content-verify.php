<?php
$userId= $_GET['userid'];
$verification_code= $_GET['verification_code'];
$user_data = get_userdata($userId);

if ($user_data) {
    if($verification_code == $user_data->verification_code){
        update_user_meta($userId, 'user_status', '20');
        $_SESSION['message']="Your account has beeen verified. Now you can login.";
        echo "<script type='text/javascript'>window.location.href='". site_url("/login") ."'</script>";
    }
}
?>