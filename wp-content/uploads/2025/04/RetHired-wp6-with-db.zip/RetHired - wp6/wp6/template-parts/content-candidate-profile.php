<div class="page_loader"></div>
<!-- Dashbord start -->
<?php include(get_template_directory() . '/template-parts/content-dashboard-header.php'); ?>
<div class="dashboard">
   <div class="container-fluid">
      <div class="row">
         <div class="col-lg-3 col-md-12 col-sm-12 p-0">
            <?php get_sidebar();?>
         </div>
         <div class="col-lg-9 col-md-12 col-sm-12 p-0">
               <div class="dashboard-content">
                  <div class="dashboard-header clearfix">
                     <div class="row">
                        <div class="col-sm-12 col-md-6">
                           <h4>Edit Profile</h4>
                        </div>
                        <div class="col-sm-12 col-md-6">
                           <div class="breadcrumb-nav">
                              <ul>
                                 <li>
                                    <a href="<?php  echo home_url('/');?>">Home</a>
                                 </li>
                                 <li>
                                    <a href="<?php echo site_url('candidate-dashboard'); ?>">Dashboard</a>
                                 </li>
                                 <li class="active">Edit Profile</li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <?php if(isset($_SESSION['message'])){ ?>
                  <div class="alert alert-success alert-2" role="alert">
                     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                     <?php echo $_SESSION['message']; ?>
                  </div>
                  <?php }?>
                  <?php unset($_SESSION['message']); ?> 
                  <div class="dashboard-list">
                     <h3 class="heading">Basic Info</h3>
                     <div class="dashboard-message contact-2 bdr clearfix">
                        <form action="" method="post" enctype="multipart/form-data">
                           <div class="row">
                              <div class="col-lg-3 col-md-3">
                                 <!-- Edit profile photo -->
                                 <label for="feature-image profile-img-label">Profile Image:</label><br>
                                 <div class="edit-profile-photo">
                                    <img id="imagePreview" src="<?php echo get_user_meta($_SESSION['userid'],'user_profile_image',true); ?>" alt="User Avatar" class="img-fluid">
                                    <button id="rmBtn" type="button" onclick="removeImage();"; style="display:none;font-size:34px;border:none;background:none;">&times;</button>
                                    <div class="change-photo-btn">
                                       <div class="photoUpload">
                                          <span><i class="fa fa-upload"></i></span>
                                          <!-- <input type="file" class="upload"> -->
                                          <input type="file" class="form-control upload" id="feature-image" name="avatar" onchange="previewImage(event)">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-9 col-md-9">
                                 <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group name">
                                          <label>Your Name</label>
                                          <?php $user_ID = $_SESSION['userid']; 
                                             ?>
                                          <input type="text" name="full_name"  id="full-name" class="form-control" placeholder="Your Name" value="<?php echo get_user_meta( $user_ID, 'first_name', true );?>">
                                       </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group email">
                                          <label>Date of Birth:</label>
                                          <input type="date" id="date-of-birth" name="dob" class="form-control" placeholder="Your Title" value="<?php echo get_user_meta( $user_ID, 'dob', true );?>">
                                       </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group subject">
                                          <label>Phone</label>
                                          <input type="number"  class="form-control" maxlength="9" placeholder="Phone" id="phone-number" name="phone_number" value="<?php echo get_user_meta( $user_ID, 'phone_number', true );?>"  oninput="validatephoneNumber(event);">
                                       </div>
                                    </div>
                                    <!-- <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Email</label>
                                          <?php //$candidate = get_user_by('ID',$_SESSION['userid']); ?>
                                          <input type="email"  class="form-control" placeholder="Email" id="user_email" name="user_email" value="<?php //echo $candidate->user_email;?>" >
                                         
                                       </div>
                                       </div> -->
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                       <div class="form-group">
                                          <label>Gender</label>
                                          <select class="form-control" name="gender" value="<?php $gender = get_user_meta( $user_ID, 'gender', true );?>">
                                             <option value="male" <?php if($gender == 'Male'){ echo "selected";}?>>Male</option>
                                             <option value="female" <?php if($gender == 'female'){ echo "selected";}?>>Female</option>
                                             <option value="other" <?php if($gender == 'Other'){ echo "selected";}?>>Other</option>
                                          </select>
                                       </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Age</label>
                                          <input type="number"  class="form-control" placeholder="Age"  id="age" name="age" value="<?php echo get_user_meta( $user_ID, 'age', true );?>">
                                       </div>
                                    </div>
                                    <?php $currentUser = get_user_by('ID',$_SESSION['userid']);
                                       $user_role = $currentUser->roles[0];
                                       ?>
                                    <?php if($user_role=='contributor'){ ?>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Current Company</label>
                                          <input type="text"  class="form-control" placeholder="Current company" id="Current-company" name="current_company" value="<?php echo get_user_meta( $user_ID, 'current_company', true );?>">
                                       </div>
                                    </div>
                                    <?php } ?>                                   
                                    
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Address</label>
                                          <?php $user_ID = $_SESSION['userid']; ?>
                                          <input type="text"id="address"  name="address" value="<?php echo get_user_meta( $user_ID, 'address', true );?>" class="form-control" placeholder="Address">
                                       </div>
                                    </div>
                                    <!-- <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Category</label>
                                          <input type="text" name="category" class="form-control" placeholder="Category">
                                       </div>
                                       </div> -->
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                       <div class="form-group mb-0 message">
                                          <label>About Me</label>
                                          <textarea class="form-control"  placeholder="Write"  id="about" name="about"><?php echo get_user_meta( $user_ID, 'bio', true );?></textarea>
                                       </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <button type="submit" class="btn btn-md button-theme mt-2" name="submit1">Update</button>
                                       </div>
                                    </div>
                                 </div>
                        </form>
                        </div>
                        </div>
                     </div>
                  </div>
                  <!-- <div class="row">
                     <div class="col-md-6">
                        <div class="dashboard-list">
                           <h3 class="heading">Change Password</h3>
                           <div class="dashboard-message contact-2">
                              <form action="#" method="GET" enctype="multipart/form-data">
                                 <div class="row">
                                    <div class="col-lg-12">
                                       <div class="form-group name">
                                          <label>Current Password</label>
                                          <input type="password" name="current-password" class="form-control" placeholder="Current Password">
                                       </div>
                                    </div>
                                    <div class="col-lg-12">
                                       <div class="form-group email">
                                          <label>New Password</label>
                                          <input type="password" name="new-password" class="form-control" placeholder="New Password">
                                       </div>
                                    </div>
                                    <div class="col-lg-12">
                                       <div class="form-group subject">
                                          <label>Confirm New Password</label>
                                          <input type="password" name="confirm-new-password" class="form-control" placeholder="Confirm New Password">
                                       </div>
                                    </div>
                                    <div class="col-lg-12">
                                       <div class="send-btn">
                                          <button type="submit" class="btn btn-md btn-primary">Change Password</button>
                                       </div>
                                    </div>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>-->
                  <!-- <div class="col-md-6">
                     <div class="dashboard-list">
                        <h3 class="heading">Socials</h3>
                        <div class="dashboard-message contact-2">
                         
                              <div class="row">
                                 <div class="col-lg-12">
                                    <div class="form-group name">
                                       <label>Facebook</label>
                                       <input type="text"  class="form-control" placeholder="https://www.facebook.com"  id="facebook_link" name="facebook" value="<?php //echo get_user_meta( $user_ID, 'facebook', true );?>">
                                    </div>
                                 </div>
                                 <div class="col-lg-12">
                                    <div class="form-group email">
                                       <label>Linkedin</label>
                                       <input type="text" id="linkedin_link" name="linkedin" value="<?php //echo get_user_meta( $user_ID, 'linkedin', true );?>" class="form-control" placeholder="https://twitter.com">
                                    </div>
                                 </div>
                                 <div class="col-lg-12">
                                    <div class="form-group subject">
                                        <label>Vkontakte</label>
                                        <input type="text" name="vkontakte" class="form-control" placeholder="vk.com">
                                    </div>
                                    </div>
                                 <div class="col-lg-12">
                                    <div class="form-group number">
                                       <label>Whatsapp</label>
                                       <input type="email" name="whatsapp" class="form-control" placeholder="https://www.whatsapp.com">
                                    </div>
                                 </div> -->
                  <!-- <div class="col-lg-12">
                     <div class="send-btn">
                        <button type="submit" class="btn btn-md btn-primary"  name="submit" onclick="validateMobileNumber()">Send Changes</button>
                     </div>
                     </div> -->
               </div>
               <p class="sub-banner-2 text-center">&#169; <?php echo get_the_date('Y');?> Theme Vessel. Trademarks and brands are the property of their respective owners.</p>
          </div>
      </div>
   </div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- Dashbord end -->
<!-- Full Page Search -->
<div id="full-page-search">
   <button type="button" class="close">X</button>
   <form action="index.html#">
      <input type="search" value="" placeholder="type keyword(s) here" />
      <button type="submit" class="btn btn-sm button-theme">Search</button>
   </form>
</div>
<?php 
   if (isset($_POST['submit1'])) {
       echo "pixel6 demo";
       // Retrieve form data
       $full_name = sanitize_text_field($_POST['full_name']);
       $dob = sanitize_text_field($_POST['dob']);
       $phone_number = sanitize_text_field($_POST['phone_number']);
       $user_email = sanitize_email($_POST['user_email']);
       $gender = sanitize_text_field($_POST['gender']);
       $age = sanitize_text_field($_POST['age']);
       $current_company = sanitize_text_field($_POST['current_company']);
       //$salary_type = sanitize_text_field($_POST['salary_type']);
    //    $education = sanitize_text_field($_POST['education']);
    //    $experience = sanitize_text_field($_POST['experience']);
    //    $category = sanitize_text_field($_POST['category']);
    //    $language = sanitize_text_field($_POST['language']);
       
    //    $company = sanitize_text_field($_POST['company']);
       
       
    //    $industry = sanitize_text_field($_POST['industry']);
    //    $role = sanitize_text_field($_POST['role']);
    //    $department = sanitize_text_field($_POST['department']);
       
    //    $skills = sanitize_text_field($_POST['skills']);
    //    $facebook = sanitize_text_field($_POST['facebook']);
    //    $linkedin = sanitize_text_field($_POST['linkedin']);
       $about = sanitize_text_field($_POST['about']);
       $address = sanitize_text_field($_POST['address']);
       $user_ID = $_SESSION['userid']; 
   
   
   
       
       // Update user's other meta data
       update_user_meta($user_ID, 'first_name', $full_name);
       update_user_meta($user_ID, 'dob', $dob);
       update_user_meta($user_ID, 'phone_number', $phone_number);
       update_user_meta($user_ID, 'user_email', $user_email);
       update_user_meta($user_ID, 'gender', $gender);
       update_user_meta($user_ID, 'age', $age);
       update_user_meta($user_ID, 'current_company', $current_company);
    //    update_user_meta($user_ID, 'salary_type', $salary_type);
    //    update_user_meta($user_ID, 'education', $education);
    //    update_user_meta($user_ID, 'experience', $experience);
    //    update_user_meta($user_ID, 'job_category', $category);
    //    update_user_meta($user_ID, 'language', $language);
    //    update_user_meta($user_ID, 'current_company', $company);
       
    //    update_user_meta($user_ID, 'industry', $industry);
    //    update_user_meta($user_ID, 'role', $role);
    //    update_user_meta($user_ID, 'department', $department);
    //    update_user_meta($user_ID, 'skills', $skills);
    //    update_user_meta($user_ID, 'facebook', $facebook);
    //    update_user_meta($user_ID, 'linkedin', $linkedin);
       update_user_meta($user_ID, 'bio', $about);
       update_user_meta($user_ID, 'address', $address);
   
   
   
   
   
   if (!empty($_FILES['avatar']['name'])) {
    // Upload image
    if ($_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
       echo "Hellooo";
       $allowed_types = array('image/jpeg', 'image/png', 'image/gif');
       $fileType = $_FILES['avatar']['type'];
   
       if (!in_array($fileType, $allowed_types)) {
          $_SESSION['message'] = "Only PNG,JPG,Jpeg files are allowed.";
          echo "<script type='text/javascript'>window.location.href='". site_url("candidate-profile") ."'</script>";
          exit; // Stop execution
       }
       
       $upload_dir = wp_upload_dir();
       $image_path = $upload_dir['path'] . '/' . $_FILES['avatar']['name'];
       move_uploaded_file($_FILES['avatar']['tmp_name'], $image_path);
       // Create attachment
       $attachment = array(
       'post_mime_type' => $_FILES['avatar']['type'],
       'post_title' => sanitize_file_name($_FILES['avatar']['name']),
       'post_content' => '',
       'post_status' => 'inherit'
       );
       $attach_id = wp_insert_attachment($attachment, $image_path);
       // Set featured image
       if ($attach_id) {
          echo $attach_id;
          $avatar_url = wp_get_attachment_url($attach_id);
          echo "Avatar URL  :".$avatar_url;
          echo $_SESSION['userid'];
          $done = update_user_meta($user_ID,'user_profile_image',$avatar_url);
       }
     
       
    }
   }
   $_SESSION['message'] = "Profile Updated Successfully!";
   echo "<script type='text/javascript'>window.location.href='". site_url("candidate-profile") ."'</script>";
   
   
   }
   
   
   
   
   
   
   ?>
