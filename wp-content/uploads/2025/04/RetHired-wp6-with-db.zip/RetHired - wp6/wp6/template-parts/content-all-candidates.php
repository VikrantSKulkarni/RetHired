<style>
    .sub-banner{
        background: rgba(0, 0, 0, 0.04) url(<?php echo get_theme_file_uri("/img/job_list_bg3.png"); ?>) top left repeat;
    }
</style>
<?php get_header(); ?>
<!-- Sub banner start -->
<div class="sub-banner bg-color-full">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>Candidates Listing</h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <li class="active">Candidates Listing</li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub banner end -->

<!-- Candidate listing section start -->
<div class="candidate-listing-section content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="sidebar-right">
                    <!-- Advanced search start --> 
                    <div class="widget-4 advanced-search">
                        <form method="GET" class="search-form">
                            <div class="form-group">
                                <label>Location</label>
                                <select class="form-control" name="address">
                                    <option value=''> -- select address -- </option>
                                    <option value="Pune" <?php if(isset($_GET['address']) && $_GET['address']=='Pune'){ echo "selected";}?>> Pune</option>
                                    <option value="Baner" <?php if(isset($_GET['address']) && $_GET['address']=='Baner'){ echo "selected";}?>> Baner </option>
                                    <option value="Amaravati" <?php if(isset($_GET['address']) && $_GET['address']=='Amaravati'){ echo "selected";}?>> Amaravati</option>
                                    <option value="Baramati" <?php if(isset($_GET['address']) && $_GET['address']=='Baramati'){ echo "selected";}?>> Baramati</option>
                                </select>
                            </div>
                           
                            <div class="form-group">
                                <label>Experience</label>
                                <select class="form-control" id="experience" name="experience" 
                                 value="<?php  $exp = $_GET['experience'];?>" required>
                                    <option value="0">-- Select experience --</option>
                                    <option value="1"<?php if($exp == '1'){ echo "selected";}?>>1 Year</option>
                                    <option value="2" <?php if($exp == '2'){ echo "selected";}?>>2 Year</option>
                                    <option value="3" <?php if($exp == '3'){ echo "selected";}?>>3 Year</option>
                                    <option value="4" <?php if($exp == '4'){ echo "selected";}?>>4 Year</option>
                                    <option value="5+" <?php if($exp == '5+'){ echo "selected";}?>>5+ Year</option>                                 
                              </select>
                            </div>

                            <div class="form-group">
                                <label>Education </label>
                                <select class="form-control" id="education" name="education" 
                                       value="<?php $edu = $_GET['education']; ?>" required>
                                    <option value="0">-- Select education --</option>
                                    <option value="High School" <?php if ($edu == 'High School') { echo "selected"; } ?>>High School</option>
                                    <option value="Diploma" <?php if ($edu == 'Diploma') { echo "selected"; } ?>>Diploma</option>
                                    <option value="Masters Degree" <?php if ($edu == "Masters Degree") { echo "selected"; } ?>>Master's Degree</option>
                                    <option value="Bachelors Degree" <?php if ($edu == "Bachelors Degree") { echo "selected"; } ?>>Bachelor's Degree</option>
                                    <option value="B.A." <?php if ($edu == 'B.A.') { echo "selected"; } ?>>B.A.</option>
                                    <option value="B.Sc." <?php if ($edu == 'B.Sc.') { echo "selected"; } ?>>B.Sc.</option>
                                    <option value="B.Com." <?php if ($edu == 'B.Com.') { echo "selected"; } ?>>B.Com.</option>
                                    <option value="B.Tech." <?php if ($edu == 'B.Tech.') { echo "selected"; } ?>>B.Tech.</option>
                                    <option value="B.E." <?php if ($edu == 'B.E.') { echo "selected"; } ?>>B.E.</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>industry </label>
                                <select class="form-control" name="industry">
                                    <option value="">-- Select industry -- </option>
                                    <option value="IT Services and Consulting" <?php if(isset($_GET['industry']) && $_GET['industry']=='IT Services and Consulting'){ echo "selected";}?>> IT Services & Consulting </option>
                                    <option value="Digital Marketing" <?php if(isset($_GET['industry']) && $_GET['industry']=='Digital Marketing'){ echo "selected";}?>> Digital Marketing </option>
                                    <option value="Education and Learning" <?php if(isset($_GET['industry']) && $_GET['industry']=='Education and Learning'){ echo "selected";}?>> Education and Learning </option>
                                    <option value="IT support" <?php if(isset($_GET['industry']) && $_GET['industry']=='IT support'){ echo "selected";}?>> IT support </option> 
                                </select>
                            </div>
                            
                            <button class="btn btn-primary rounded" type="submit" name="submit">apply</button>
                            <a href="<?php echo site_url('all-candidates'); ?>" class="btn btn-secondary text-light">reset </a>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-12">
                <!-- Option bar start -->
                <div class="option-bar d-none d-sm-block">
                    <div class="row">
                        <div class="col-lg-6 col-7">
                            <div class="sorting-options2">
                                <span class="sort">Sort by:</span>
                                <?php
                                $cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : null;
                                $current_sort = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : '';

                                $sorting_options = [
                                    'newest' => 'Newest',
                                    'asc' => 'Oldest',
                                ];
                                ?>
                                <select class="selectpicker search-fields" name="default-order" onchange="location = this.value;">
                                    <?php foreach ($sorting_options as $sort_value => $sort_label) : 
                                        $url_params = ['sort' => $sort_value];
                                        if ($cat_id) {
                                            $url_params['cat_id'] = $cat_id;
                                        }
                                        $sort_url = add_query_arg($url_params, get_permalink());
                                        $selected = ($current_sort === $sort_value) ? 'selected' : '';
                                    ?>
                                        <option value="<?php echo esc_url($sort_url); ?>" <?php echo $selected; ?>><?php echo esc_html($sort_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6 col-5">
                            <div class="sorting-options">
                                <a href="#" id="listView" class="change-view-btn active-view-btn"><i class="fa fa-th-list"></i></a>
                                <a href="#" id="gridView" class="change-view-btn"><i class="fa fa-th-large"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    jQuery(document).ready(function($) {
                        function setView(view) {
                            if (view === 'grid') {
                                $("#gridViewContainer").show();
                                $("#listViewContainer").hide();
                                $("#gridView").addClass("active-view-btn");
                                $("#listView").removeClass("active-view-btn");
                            } else {
                                $("#listViewContainer").show();
                                $("#gridViewContainer").hide();
                                $("#listView").addClass("active-view-btn");
                                $("#gridView").removeClass("active-view-btn");
                            }
                            localStorage.setItem('view', view);
                        }

                        // On page load, check localStorage for view state
                        var view = localStorage.getItem('view') || 'list';
                        setView(view);

                        $("#gridView").on("click", function(e) {
                            e.preventDefault();
                            setView('grid');
                        });

                        $("#listView").on("click", function(e) {
                            e.preventDefault();
                            setView('list');
                        });
                    });
                </script>
                <?php
                    $sort_order = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : 'desc';
                    $address = isset($_GET['address']) ? sanitize_text_field($_GET['address']) : '';
                    $experience = isset($_GET['experience']) ? sanitize_text_field($_GET['experience']) : '';
                    $education = isset($_GET['education']) ? sanitize_text_field($_GET['education']) : '';
                    $industry = isset($_GET['industry']) ? sanitize_text_field($_GET['industry']) : '';



                    $order = 'DESC';
                    $orderby = 'date';
    
                    if ($sort_order == 'asc') {
                        $order = 'ASC';
                    } elseif ($sort_order == 'desc') {
                        $order = 'DESC';
                    } 

                    $args = array(
                    'role'    => 'subscriber',
                    'order'   => $order,
                    'meta_query' => array()
                    );

                    if (!empty($address)) {
                        $args['meta_query'][] = array(
                            'key' => 'address',
                            'value' => $address,
                            'compare' => '='
                        );
                    } 
                    if (!empty($experience)) {
                        $args['meta_query'][] = array(
                            'key' => 'experience',
                            'value' => $experience,
                            'compare' => '='
                        );
                    } 
                    if (!empty($education)) {
                        $args['meta_query'][] = array(
                            'key' => 'education',
                            'value' => $education,
                            'compare' => '='
                        );
                    } 
                    if (!empty($industry)) {
                        $args['meta_query'][] = array(
                            'key' => 'industry',
                            'value' => $industry,
                            'compare' => '='
                        );
                    } 

                    $total_users = count_users()['total_users'];
                    $users_per_page = 6;
                    $total_pages = ceil($total_users / $users_per_page);
                    $current_page = max(1, get_query_var('paged'));
                    $offset = ($current_page - 1) * $users_per_page;
                    $args['number'] = $users_per_page;
                    $args['offset'] = $offset;

                    $users = get_users($args); 
                    //echo "<pre>";print_r($users);echo "</pre>";
                echo "<div id='listViewContainer'>";
                if($users){
                    foreach($users as $user){ ?>
                    <!-- Candidate box start -->
                    
                    <div class="candidate-box d-flex">
                        <div class="candidate-logo">
                        <?php
                            $current_user_id = $user->ID; // Replace with specific user ID if needed
                            $custom_avatar_url = get_user_meta($current_user_id, 'profile_image', true);
                            if ($custom_avatar_url) {
                            $avatar_url = esc_url($custom_avatar_url);
                            } else {
                            // Get the default WordPress avatar URL
                            $avatar_url = get_avatar_url($current_user_id);
                            }
                        ?>
                            <img src="<?php echo $avatar_url;?>" alt="avatar">
                        </div>
                        <div class="description d-inline d-md-flex">
                            <div class="">
                                <h5 class="title"><a href="<?php echo esc_url( add_query_arg( array( 'user_id' => $user->ID), site_url('candidate-view-profile') ) );?>"><?php echo get_user_meta($user->ID,'first_name',true);?></a></h5>
                                <div class="candidate-listing-footer">
                                    <?php $industry = get_user_meta($user->ID,'industry',true); 
                                        $address = get_user_meta($user->ID,'address',true);
                                        $company = get_user_meta($user->ID,'current_company',true);
                                    ?>
                                    <ul>
                                        <?php if($company){?><li><i class="flaticon-work"></i> <?php echo $company;?></li><?php }?>
                                        <?php if($industry){?><li><i class="flaticon-tick"></i> <?php echo $industry; ?></li><?php }?>
                                        <?php if($address){?><li><i class="flaticon-pin"></i> <?php echo $address;?></li><?php }?>
                                    </ul>
                                </div>
                            </div>
                            <div>
                                <a href="<?php echo esc_url( add_query_arg( array( 'user_id' => $user->ID), site_url('candidate-view-profile') ) );?>" class="apply-button">View </a>
                                <?php if( is_user_logged_in() and (get_current_user_id() == $user->ID)){?>
                                <a href="<?php echo site_url('profile');?>" class="apply-button btn-success text-light">Edit </a>
                                    <?php }?>
                            </div>
                        </div>
                    </div>
                <?php } echo "</div>";
                }else{
                    echo "<div id='listViewContainer'>";
                        echo "<div class='candidate-box'>";
                            echo "<h3>No Result Found !</h3>";
                        echo "</div>";
                    echo "</div>";
                }                
                ?>
             <div class="row" id="gridViewContainer">       
                <?php foreach($users as $user){ ?>
                    <div class="col-md-6">
                        <div class="card job-grid-card mb-2">
                            <div class="text-center">
                            <?php
                                  $current_user_id = $user->ID; // Replace with specific user ID if needed
                                  $custom_avatar_url = get_user_meta($current_user_id, 'profile_image', true);
                                  if ($custom_avatar_url) {
                                    $avatar_url = esc_url($custom_avatar_url);
                                  } else {
                                    // Get the default WordPress avatar URL
                                    $avatar_url = get_avatar_url($current_user_id);
                                  }
                                 ?>
                            <img style="width: 100px;" src="<?php echo $avatar_url;?>" class="card-img-top rounded-circle mt-2" alt="User Profile">
                            </div> 
                            <div class="card-body">
                                <h5 class="card-title text-center"><a href="<?php echo esc_url( add_query_arg( array( 'user_id' => $user->ID), site_url('candidate-view-profile') ) );?>"><?php echo get_user_meta($user->ID,'first_name',true);?></a></h5>
                                <hr>
                                <div class="candidate-listing-footer text-center">
                                    <?php $industry = get_user_meta($user->ID,'industry',true); 
                                        $address = get_user_meta($user->ID,'address',true);
                                        $company = get_user_meta($user->ID,'current_company',true);
                                    ?>
                                    <ul>
                                        <?php if($company){?><li><i class="flaticon-work"></i> <?php echo $company; ?></li><?php }?>
                                        <?php if($industry){?><li><i class="flaticon-tick"></i> <?php echo $industry; ?></li><?php }?>
                                        <?php if($address){?><li><i class="flaticon-pin"></i> <?php echo $address;?></li><?php }?>
                                    </ul>
                                </div>
                                <div class="text-center mt-4">
                                    <a href="<?php echo esc_url( add_query_arg( array( 'user_id' => $user->ID), site_url('candidate-view-profile') ) );?>" class="btn btn-secondary text-dark pl-5 pr-5" style="background:none;border-radius:50px;">View </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
                <?php 
                if(count($users) == 6) { 
                    echo '<div class="pagination-box hidden-mb-45 text-center">';
                    echo '<nav aria-label="Page navigation example">';
                    echo '<ul class="pagination">';
                    if ($current_page > 1) {
                        $prev_page_url = add_query_arg(array(
                            'paged' => $current_page - 1,
                            'location' => $location,
                            'job_type' => $job_type,
                            'experience' => $experience,
                            'qualification' => $qualification,
                            'job_category' => $job_category,
                            'sort' => $sort_order,
                            'cat_id' => $cat_id,
                        ), get_permalink());
                        echo '<li class="page-item"><a class="page-link" href="' . esc_url($prev_page_url) . '">Previous</a></li>';
                    }
                    for ($i = 1; $i <= $total_pages; $i++) {
                        $active_class = ($i == $current_page) ? 'active' : '';
                        $page_url = add_query_arg(array(
                        'paged' => $i,
                        'location' => $location,
                        'job_type' => $job_type,
                        'experience' => $experience,
                        'qualification' => $qualification,
                        'job_category' => $job_category,
                        'sort' => $sort_order,
                        'cat_id' => $cat_id,
                        ), get_permalink());
                        echo '<li class="page-item ' . $active_class . '"><a class="page-link" href="' . esc_url($page_url) . '">' . $i . '</a></li>';
                    }
                    if ($current_page < $total_pages) {
                        $next_page_url = add_query_arg(array(
                            'paged' => $current_page + 1,
                            'location' => $location,
                            'job_type' => $job_type,
                            'experience' => $experience,
                            'qualification' => $qualification,
                            'job_category' => $job_category,
                            'sort' => $sort_order,
                            'cat_id' => $cat_id,
                        ), get_permalink());
                        echo '<li class="page-item"><a class="page-link" href="' . esc_url($next_page_url) . '">Next</a></li>';
                    }
                    ?>
                    <?php
                    echo '</ul>';
                    echo '</nav>';
                    echo '</div>';
                }?>
            </div>
        </div>
    </div>
</div>
<!-- Candidate listing section start -->

<?php get_footer(); ?>
