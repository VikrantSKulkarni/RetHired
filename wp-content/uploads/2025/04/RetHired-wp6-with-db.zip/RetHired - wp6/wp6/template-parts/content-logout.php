<?php
// Make sure to include WordPress functions
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Log out the user
wp_logout();

// Redirect to the home page
wp_redirect(home_url('/login'));
exit;
?>
