<?php include(get_template_directory() . '/template-parts/content-dashboard-header.php'); ?>

<?php if(!isset($_SESSION['userid'])){ ?>
    <script>window.location.href='<?php echo site_url('login'); ?>';</script>
<?php } elseif($_SESSION['userrole'] =='contributor'){ 
    unset($_SESSION['userid']);
    $_SESSION['message'] = "Please login as a Candidate.";
    ?>
    <script>window.location.href='<?php echo site_url('login'); ?>';</script>
<?php } ?>
<?php
$applied_jobs_count = isset($_SESSION['applied_jobs_count']) ? $_SESSION['applied_jobs_count'] : 0;
$working_status = get_user_meta($_SESSION['userid'], 'working_status', true);
$total_applied_jobs = 0; // Initialize the total applied jobs count

// Fetch all job posts and count the applied jobs by the user
$args = array('post_type' => 'job-post', 'posts_per_page' => -1); // Fetch all job posts
$query = new WP_Query($args);
if ($query->have_posts()) :
    while ($query->have_posts()) : $query->the_post();
        $candidates = get_field('job_applicant');
        if ($candidates) {
            foreach ($candidates as $candidate) {
                if ($candidate['user_id'] == $_SESSION['userid']) {
                    $total_applied_jobs++;
                }
            }
        }
    endwhile;
    wp_reset_postdata();
endif;
$_SESSION['applied_job'] = $total_applied_jobs;
?>

<!-- Dashboard start -->
<div class="dashboard">
    <div class="container-fluid">
        <div class="row" style="margin-top:-22px;">
            <div class="col-lg-3 p-0">
                <?php get_sidebar(); ?>
            </div>
            <div class="col-lg-9 p-0">
                    <div class="dashboard-content">
                        <div class="dashboard-header clearfix">
                            <div class="row">
                                <div class="col-md-6">
                                    <h4>Hello, <?php echo get_user_meta($_SESSION['userid'], 'first_name', true); ?></h4>
                                </div>
                                <div class="col-md-6">
                                    <div class="breadcrumb-nav">
                                        <ul>
                                            <li>
                                                <a href="<?php echo home_url('/'); ?>">Home</a>
                                            </li>
                                            <li>
                                                <a href="" class="active">Dashboard</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                        <div class="row">
                            <div class="col-12">
                                <div class="dashboard-list">
                                    <h3>Job Applied Recently</h3>
                                    <div style="margin-left:25px;"><span>Total Applied Job Count(<?php echo isset($_SESSION['applied_job']) ? $_SESSION['applied_job'] : 0; ?>)</span></div>
                                    <div class="dashboard-message dashboard-table-responsive bdr clearfix">
                                        <div class="table-responsive dashboard-table-responsive">
                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                        <th style="width:25%;">Image</th>
                                                        <th style="width:20%;">Job Title</th>
                                                        <th style="width:20%;">Start Date</th>
                                                        <th style="width:20%;">Due Date</th>
                                                        <th style="width:20%;">Status</th>
                                                        <th style="width:20%;">Assign</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $args = array(
                                                        'post_type' => 'job-post',
                                                       
                                                    );
                                                    $count = 0;
                                                    $query = new WP_Query($args);
                                                    if ($query->have_posts()) :
                                                        while ($query->have_posts()) : $query->the_post();
                                                            $candidates = get_field('job_applicant');
                                                            if ($candidates) {
                                                                foreach ($candidates as $candidate) {
                                                                    if ($candidate['user_id'] == $_SESSION['userid']) {
                                                                        $count++;
                                                                        ?>
                                                                        <tr>
                                                                            <td><img style="height:100px;" src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt=""></td>
                                                                            <td><?php echo get_the_title(); ?></td>
                                                                            <td><?php echo get_the_date(); ?></td>
                                                                            <td><?php echo get_user_meta($_SESSION['userid'], 'application_end_date', true) ? get_user_meta($_SESSION['userid'], 'application_end_date', true) : 'NA'; ?></td>
                                                                            <td>
                                                                                <?php
                                                                                $post_ID = get_the_ID();
                                                                                $abc = get_user_meta($candidates[0]['user_id'], 'working_status_post_id', true);
                                                                                if (get_the_ID() == $abc) { ?>
                                                                                    <span class="badge badge-danger"><?php echo $working_status; ?></span>
                                                                                <?php } else { ?>
                                                                                    <span class="badge badge-success"><?php echo "Free"; ?></span>
                                                                                <?php } ?>
                                                                            </td>
                                                                            <td><?php echo get_user_meta(get_the_author_meta('ID'), 'current_company', true); ?></td>
                                                                        </tr>
                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                        endwhile;
                                                        wp_reset_postdata();
                                                    endif;
                                                    if ($count == 0) { ?>
                                                        <tr class="responsive-table">
                                                            <td class="p-left-20">No Records Found!</td>
                                                        </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="post-btn float-right">
                                        <button type="submit" name="submit" class="btn btn-md button-theme bg-danger">
                                            <a class="text-light" href="<?php echo site_url('candidate-dashboard'); ?>">Back</a>
                                        </button>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <p class="sub-banner-2 text-center">&#169; 2018 Theme Vessel. Trademarks and brands are the property of their respective owners.</p>
               
            </div>
        </div>
    </div>
</div>
<!-- Dashboard end -->
<!-- Full Page Search -->
<div id="full-page-search">
    <button type="button" class="close">X</button>
    <form action="index.html#">
        <input type="search" value="" placeholder="type keyword(s) here" />
        <button type="submit" class="btn btn-sm button-theme">Search</button>
    </form>
</div>
