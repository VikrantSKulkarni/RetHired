<?php include(get_template_directory() . '/template-parts/content-dashboard-header.php'); ?>
<style>
   .alert {
   text-transform: none !important;
   }
</style>
<?php 
if (!is_user_logged_in()) {
   $_SESSION['message'] = 'Please log in to continue.';
   $_SESSION['redirect_to']  = $_SERVER['REQUEST_URI'];
   echo "<script>window.location.href='".site_url('login')."'</script>";
}
if (is_user_logged_in() && current_user_can('contributor')) {
    $_SESSION['message'] = 'Please log in as candidate';
    $_SESSION['redirect_to']  = $_SERVER['REQUEST_URI'];
    wp_redirect(site_url('login'));
    
}
$currentUserId = get_current_user_id();

?>
<!-- Dashboard start -->
<div class="dashboard">
   <div class="container-fluid">
      <div class="row" >
         <div class="col-lg-3 p-0">
            <?php get_sidebar();?>
         </div>
         <div class="col-lg-9 p-0">
            <div class="dashboard-content">
               <div class="dashboard-header clearfix">
                  <div class="row">
                     <div class="col-md-6">
                        <h4>Add Resume</h4>
                     </div>
                     <div class="col-md-6">
                        <div class="breadcrumb-nav">
                           <ul>
                              <li>
                                 <a href="<?php echo home_url('/') ?>">Home</a>
                              </li>
                              <li>
                                 <a href="<?php echo site_url('candidate-dashboard'); ?>">Dashboard</a>
                              </li>
                              <li class="active">Add Resume</li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
               <?php if(isset($_SESSION['message'])){ ?>
               <div class="alert alert-success alert-2" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <?php echo $_SESSION['message']; ?>
               </div>
               <?php }?>
               <?php unset($_SESSION['message']); ?>
               <?php if(isset($_SESSION['error-message'])){ ?>
               <div class="alert alert-danger alert-2" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <?php echo $_SESSION['error-message']; ?>
               </div>
               <?php }?>
               <?php unset($_SESSION['error-message']); ?> 
               <div class="submit-address dashboard-list">
                  <form method="post" enctype="multipart/form-data" action="">
                     <h4 class="bg-grea-3">Basic Information</h4>
                     <div class="search-form">
                        <div class="row pad-20">
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label> Name <span class="text-danger">*</span></label>
                                 <input type="text" readonly class="input-text" name="full_name" placeholder="Your Name" value="<?php echo get_user_meta( $currentUserId, 'first_name', true );?>">
                              </div>
                           </div>
                             <div class="col-md-6">
                              <div class="form-group">
                                 <label>Education <span class="text-danger">*</span></label>
                                 <select class="form-control" id="education" name="education" 
                                       value="<?php $edu = get_user_meta($currentUserId, 'education', true); ?>" required>
                                    <option value="0">-- Select Education --</option>
                                    <option value="High School" <?php if ($edu == 'High School') { echo "selected"; } ?>>High School</option>
                                    <option value="Diploma" <?php if ($edu == 'Diploma') { echo "selected"; } ?>>Diploma</option>
                                    <option value="Masters Degree" <?php if ($edu == "Masters Degree") { echo "selected"; } ?>>Master's Degree</option>
                                    <option value="Bachelors Degree" <?php if ($edu == "Bachelors Degree") { echo "selected"; } ?>>Bachelor's Degree</option>
                                    <option value="B.A." <?php if ($edu == 'B.A.') { echo "selected"; } ?>>B.A.</option>
                                    <option value="B.Sc." <?php if ($edu == 'B.Sc.') { echo "selected"; } ?>>B.Sc.</option>
                                    <option value="B.Com." <?php if ($edu == 'B.Com.') { echo "selected"; } ?>>B.Com.</option>
                                    <option value="B.Tech." <?php if ($edu == 'B.Tech.') { echo "selected"; } ?>>B.Tech.</option>
                                    <option value="B.E." <?php if ($edu == 'B.E.') { echo "selected"; } ?>>B.E.</option>
                                 </select>
                              </div>
                           </div>
                            <div class="col-md-6">
                              <label class="form-label" for="experience">Experience</label>
                              <select class="form-control" id="experience" name="experience" 
                                 value="<?php  $exp = get_user_meta( $currentUserId, 'experience', true );?>" required>
                                 <option value="0">-- Select experience --</option>
                                 <option value="1"<?php if($exp == '1'){ echo "selected";}?>>1 Year</option>
                                 <option value="2" <?php if($exp == '2'){ echo "selected";}?>>2 Year</option>
                                 <option value="3" <?php if($exp == '3'){ echo "selected";}?>>3 Year</option>
                                 <option value="4" <?php if($exp == '4'){ echo "selected";}?>>4 Year</option>
                                 <option value="5+" <?php if($exp == '5+'){ echo "selected";}?>>5+ Year</option>                                 
                              </select>
                            </div>
                           
                           <div class="col-md-6">
                              <label class="form-label" for="experience">Industry</label>
                              <select class="form-control mb-4" id="industry" name="industry" 
                                 value="<?php  $industry = get_user_meta( $currentUserId, 'industry', true );?>">
                                 <option value="0">-- Select industry --</option>
                                 <option value="IT Services and Consulting"<?php if($industry == 'IT Services and Consulting'){ echo "selected";}?>>IT Services and Consulting</option>
                                 <option value="Digital Marketing" <?php if($industry == 'Digital Marketing'){ echo "selected";}?>>Digital Marketing </option>
                                 <option value="Education and Learning" <?php if($industry == 'Education and Learning'){ echo "selected";}?>>Education and Learning </option>
                                 <option value="IT support" <?php if($industry == 'IT support'){ echo "selected";}?>>IT support </option>
                              </select>
                           </div>
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label> Designation </label>
                                 <input type="text" id="designation" name="designation" value="<?php echo get_user_meta( $currentUserId, 'designation', true );?>" class="form-control" placeholder="Designation">
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label>Language   <small class="text-muted"> (e.g. language 1, language 2,...etc)</small></label>
                                 <input type="text"  id="language" name="language"value="<?php echo get_user_meta( $currentUserId, 'language', true );?>"  class="form-control" placeholder="Language">
                              </div>
                           </div>
                        
                        </div>
                     </div>
                     <h4 class="bg-grea-3">Skills & Portfolio </h4>
                     <div class="search-form">
                        <div class="row pad-20">
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label>Skills <span class="text-danger">*</span> <small class="text-muted"> (e.g. skill1, skill2,...etc)</small> </label>
                                 <input type="text"  id="skills" name="skills" value="<?php echo get_user_meta( $currentUserId, 'skills', true );?>" class="form-control" placeholder="Skills" required>
                              </div>
                           </div>
                           <div class="col-12">
                              <label for=""> Resume <small class="text-danger">(only pdf or doc files allowed )</small> </label>
                              <input class="form-control resume-input" type="file" name="resume">
                              <!-- <button type="submit" name="upload" class="btn btn-primary mt-2">Upload</button> -->
                           </div>
                           <div class="col-12 pt-1">
                           <?php $resume_url = get_user_meta($currentUserId,'resume',true);?> 
                           <?php if($resume_url){ ?>
                            <a target="__blank" href="<?php echo  $resume_url ?>" class="text-success"> 
                                <i class="flaticon-view"></i> View </a>
                           <?php   }  ?>
                            
                               <?php if($resume_url) { ?>
                                 <a class="text-danger ml-3" data-toggle="modal" data-target="#deleteAlert"><i class="fa fa-trash"></i> Delete </a>
                              <?php } ?> 
                           </div>
                           
                        </div>
                     </div>
                     <div class="col-lg-4 mb-3">
                        <button type="submit" class="btn btn-primary" name="submit2" onclick="validateMobileNumber()">Update</button>
                     </div>
                  </form>
               </div>
               <?php get_footer('secondary'); ?>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Dashboard end -->
<!-- Full Page Search -->
<div id="full-page-search">
   <button type="button" class="close">X</button>
   <form action="index.html#">
      <input type="search" value="" placeholder="type keyword(s) here" />
      <button type="submit" class="btn btn-sm button-theme">Search</button>
   </form>
</div>
<?php 
   if (isset($_POST['submit2'])) {
       echo "pixel6 demo";
       // Retrieve form data
       $full_name = sanitize_text_field($_POST['full_name']);
       $education = sanitize_text_field($_POST['education']);
       $experience = sanitize_text_field($_POST['experience']);
       $language = sanitize_text_field($_POST['language']);  
       $industry = sanitize_text_field($_POST['industry']);
       $designation = sanitize_text_field($_POST['designation']);
       $skills = sanitize_text_field($_POST['skills']);
       
    //    $company = sanitize_text_field($_POST['company']);       
    //    $role = sanitize_text_field($_POST['role']);
    //    $department = sanitize_text_field($_POST['department']);     
   
        update_user_meta($currentUserId, 'first_name', $full_name);
        update_user_meta($currentUserId, 'education', $education);
        update_user_meta($currentUserId, 'experience', $experience);
        update_user_meta($currentUserId, 'language', $language);
        update_user_meta($currentUserId, 'industry', $industry);
        update_user_meta($currentUserId, 'designation', $designation);
        update_user_meta($currentUserId, 'role', $role);
        update_user_meta($currentUserId, 'skills', $skills);

    //    update_user_meta($user_ID, 'current_company', $company);       
    //    update_user_meta($user_ID, 'department', $department);
   
   
   $_SESSION['message'] = 'Profile updated successfully!';
   // echo "<script>location.href='".site_url('profile')."'</script>";
   ?>
<?php 
   // Upload image
   if ($_FILES['resume']['error'] === UPLOAD_ERR_OK) {
     
      $allowed_types = array('application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
      $fileType = $_FILES['resume']['type'];
   
      if (!in_array($fileType, $allowed_types)) {
         $_SESSION['error-message'] = "Only PDF or DOC files are allowed in resume";
         unset($_SESSION['message']);
         echo "<script type='text/javascript'>window.location.href='". site_url("candidate-resume") ."'</script>";
         exit; // Stop execution
      }
   
     
      $upload_dir = wp_upload_dir();
      $currentUserName = get_user_meta($currentUserId,'first_name',true);
      $image_path = $upload_dir['path'] . '/' .$currentUserName."_".date('d-m-Y')."_Resume";
      move_uploaded_file($_FILES['resume']['tmp_name'], $image_path);
   
      // Create attachment
      $attachment = array(
          'post_mime_type' => $_FILES['resume']['type'],
          'post_title' => sanitize_file_name($_FILES['resume']['name']),
          'post_content' => '',
          'post_status' => 'inherit'
      );
      $attach_id = wp_insert_attachment($attachment, $image_path);
   
      // Set featured image
      if ($attach_id) {
         //echo $attach_id;
         $resume_url = wp_get_attachment_url($attach_id);
         echo $resume_url;
         update_user_meta($currentUserId,'resume',$resume_url);
      }
   }
   $_SESSION['message'] = "Resume updated successfully!";
      if($_SESSION['redirect_to']){
         echo "<script type='text/javascript'>window.location.href='".$_SESSION['redirect_to']."'</script>";  
         unset($_SESSION['redirect_to']); 
      }else{
         echo "<script type='text/javascript'>window.location.href='". site_url("candidate-resume") ."'</script>";
      }
   }
   ?>
<div class="modal fade" id="resumeAlert" tabindex="-1" role="dialog" aria-labelledby="resumeAlertLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="resumeAlertLabel">Alert Message </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            Please upload your resume ! 
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-secondary" data-dismiss="modal">OK</button>
        </div>
        </div>
    </div>
</div>






<div class="modal fade" id="deleteAlert" tabindex="-1" role="dialog" aria-labelledby="resumeAlertLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="resumeAlertLabel">Alert Message </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
           Are You Sure You Want To Delete Your Resume!
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            <a href="<?php echo esc_url( add_query_arg('user_id',$currentUserId, site_url('delete-user-resume')));?>" class="btn btn-danger">Delete</a>
        </div>
        </div>
    </div>
</div>