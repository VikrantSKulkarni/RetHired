<?php 
get_header();
if(!is_user_logged_in()){ ?>
<script>
    document.getElementById("header").style.display='none';
</script>
<?php }else{
    if(current_user_can('contributor')){    
    echo "<script>location.href='".site_url('employer-dashboard')."'</script>";
}elseif(current_user_can('subscriber')){
    echo "<script>location.href='".site_url('candidate-dashboard')."'</script>";
}elseif(current_user_can('administrator')){
    echo "<script>location.href='".admin_url()."'</script>";
}
}
?>
<!-- Contact section start -->
<div class="contact-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- Form content box start -->
                <div class="form-content-box">
                    <?php if(isset($_SESSION['message'])){?>
                    <div class="alert alert-success alert-2 text-capitalize" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo $_SESSION['message']; ?>
                    </div>
                    <?php }
                    unset($_SESSION['message']);?>
                    <?php if(isset($_SESSION['errorMessage'])){?>
                    <div class="alert alert-danger alert-2 text-capitalize" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo $_SESSION['errorMessage']; ?>
                    </div>
                    <?php }
                    unset($_SESSION['errorMessage']);?>
                    <!-- details -->
                    <div class="details">
                        <!-- Logo-->
                        <a href="<?php echo home_url(); ?>">
                            <?php 
                                if(has_custom_logo()){
                                the_custom_logo();
                                }
                            ?>
                        </a>
                        <!-- Name -->
                        <h3>Create an account</h3>
                        <!-- Form start-->
                        <form action="" method="post">
                            <div class="form-group">
                                <input type="text" name="fullname" class="input-text" placeholder="Full Name" required>
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="input-text" placeholder="Email Address" required>
                            </div>

                            <div class="form-group">
                        <!-- <label for="password">Password *</label> -->
                        <div class="input-group">
                           <input style="border-right:none;"  type="password" autocomplete="off" class="form-control" oninput="validateFormCanCan(event);"  name="password" id="password_can" placeholder="Password" required>
                           <button style="border-left:none;border-color:#ced4da" class="btn btn-outline-secondary" type="button" id="togglePassword_can" onclick="togglePasswordCan();">
                           <i class="fa fa-eye" id="eye-can" aria-hidden="true"></i>
                           </button>
                        </div>
                        <div id="passwordLengthError-can" class="text-danger" style="display:none;">Password must be at least 8 characters long.</div>
                     </div>
                     <div class="form-group">
                        <div class="input-group">
                           <input style="border-right:none;"  type="password"  autocomplete="off" class="form-control" id="confirmPassword-can"  name="confirmpassword-can" oninput="validateConfirmPassword(event);" placeholder="Confirm Password" required>
                           <button style="border-left:none;border-color:#ced4da" class="btn btn-outline-secondary" type="button" id="togglePassword_can_confirm" onclick="togglePasswordCanCconfirm();">
                           <i class="fa fa-eye" id="eye-can-confirm" aria-hidden="true"></i>
                           </button>
                        </div>
                        <div id="passwordMatchError-can" class="text-danger" style="display:none;">Passwords do not match.</div>
                     </div>
                         
                         <div class="" >
                            <hr>
                            <label style="display:flex;">Choose Role</label>
                            <div class="d-flex mb-3">
                            <div class="form-check form-check-inline">
                                <input checked class="form-check-input" type="radio" name="user_role" id="candidate" value="subscriber" required>
                                <label class="form-check-label" for="candidate">Candidate</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="user_role" id="employer" value="contributor" required>
                                <label class="form-check-label" for="employer">Employer</label>
                            </div>
                            </div>
                        </div>

                            <div class="form-group mb-0">
                                <button type="submit" class="btn-md button-theme btn-block" name="register">Signup</button>
                            </div>
                        </form>
                       
                    </div>
                    <!-- Footer -->
                    <div class="footer">
                        <span>Already a member? <a href="<?php echo site_url('/login');?>">Login</a></span>
                    </div>
                </div>
                <!-- Form content box end -->
            </div>
        </div>
    </div>
</div>
<?php
if(isset($_POST['register'])){
    
    $username = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $userrole = trim($_POST['user_role']);
    
    if(empty($email) || empty($username) || empty($password)){
        $_SESSION['message'] = "One or more field is empty !";
        echo "<script type='text/javascript'>window.location.href='". site_url("/register") ."'</script>";
        exit;
    }

    $existing_user = get_user_by('email', $email);
    if ($existing_user) {
        $_SESSION['message'] = 'User with this email already exists.';
        echo "<script type='text/javascript'>window.location.href='". site_url("/register") ."'</script>";
        exit;
    }

    $verification_code = rand(1000, 9999);

    $user_data = array(
        'user_login'  => $username, 
        'first_name'  => $username,
        'user_email'  => $email,
        'user_pass'   => $password,
        'role'        => $userrole
    );

    $userId = wp_insert_user($user_data);

    echo $userId;

    if (!is_wp_error($userId)) {
        
        update_user_meta($userId, 'user_status', '10');
        update_user_meta($userId, 'verification_code', $verification_code);
        update_user_meta($userId, 'working_status', 'Released');

        $to = $email; 
        $subject = 'Email Verification';
        $body = 'Hello '.$username.',<br>
        <br>
        Welcome to RetHired!<br> 
        We appreciate you registering to our site. To confirm you as a member, please click on the following link:<br>
        <a href="' . home_url("/verify") . '?userid=' . $userId . '&verification_code=' . $verification_code . '">Click to verify your email address</a><br>
        <br>
        Thank you!<br>
        RetHired Team';
        $from = "no-reply@rethired.in";
        $headers = array(
                'Content-Type: text/html',
                "From: RetHired<$from>",
                "Reply-To: $from"
        );
        wp_mail( $to, $subject, $body, $headers);
        $_SESSION['message'] = "A verification email has been sent";
        echo "<script type='text/javascript'>window.location.href='". site_url("/login") ."'</script>";
        
    } else {
        $_SESSION['error-message'] = "Fail to created user !";
        echo "<script type='text/javascript'>window.location.href='". site_url("/register") ."'</script>";
        echo 'Error: ' . $userId->get_error_message();
    }    
}
?>
