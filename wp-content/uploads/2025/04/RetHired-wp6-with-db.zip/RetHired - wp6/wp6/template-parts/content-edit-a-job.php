<?php include(get_template_directory() . '/template-parts/content-dashboard-header.php'); ?>
<?php 
if (is_user_logged_in() && current_user_can('subscriber')) {
    $_SESSION['message'] = 'Please log in as Employer';
    $_SESSION['redirect_to']  = $_SERVER['REQUEST_URI'];
    wp_redirect(site_url('login'));
}
?>
<?php 
$author_id = $_GET['author_id'];
$args = array(
    'post_type' => 'job-post',
    'p'         => $_GET['post_id'], 
    'author'    => $_GET['author_id'],
);
$query  = new WP_Query( $args );
if ($query->have_posts()) : 
while ($query->have_posts()) : $query->the_post(); 
$edit_post_id =  get_the_id();
$title = get_the_title();
$job_description = get_the_content();
$post_id =  get_the_ID();
//echo $post_id;
$employer_name = get_usermeta($author_id,'last_name',true); 
$employer_email = get_usermeta($author_id,'user_email',true); 
$employer_phone = get_usermeta($author_id,'phone_number',true); 
$employer_company = get_usermeta($author_id,'current_company',true); 

$job_type = get_field('job_type');
$status = get_field('status');
$categories = get_terms(array(
    'taxonomy' => 'category', 
    'hide_empty' => false,
));

$experience = get_field('experience_required');

$location  =  get_field('location');

$qualification = get_field('qualification');
$monthly_payment = get_field('monthly_payment');
$skills = get_field('skills');
$job_type = get_field('job_type');

$weekly_time = get_field('weekly_time_demand');
$application_end_date = get_field('application_end_date');
$formatted_application_end_date = date('Y-m-d', strtotime($application_end_date));
$post_image = get_the_post_thumbnail_url(get_the_ID(),'medium');?>
<!-- Dashboard start -->
<div class="dashboard">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 p-0">
                <?php get_sidebar();?> 
            </div>
            <div class="col-lg-9 col-md-12 col-sm-12 p-0">
                <div class="dashboard-content">
                    <div class="dashboard-header clearfix">
                        <div class="row">
                            <div class="col-sm-12 col-md-6"><h4>Edit a Job</h4></div>
                            <div class="col-sm-12 col-md-6">
                                <div class="breadcrumb-nav">
                                    <ul>
                                        <li>
                                            <a href="<?php echo home_url(); ?>">Home</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo site_url('employer-dashboard'); ?>">Dashboard</a>
                                        </li>
                                        <li class="active">Edit a Job</li>
                                    </ul>
                                </div>
                            </div> 
                        </div>
                    </div>
                    <?php if(isset($_SESSION['message'])){?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['message']; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php }
                    unset($_SESSION['message']);?>
                     <?php if(isset($_SESSION['error-message'])){?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['error-message']; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php }
                    unset($_SESSION['error-message']);?>
                    <div class="submit-address dashboard-list">
                        <form method="POST" action="" enctype="multipart/form-data">
                        <input type="hidden" name="edit_post_id" id="" value="<?php echo $edit_post_id; ?>">
                        
                        <input type="hidden" name="employer_name" value="<?php echo $employer_name; ?>">
                        <input type="hidden" name="employer_email" value="<?php echo $employer_email; ?>">
                        <input type="hidden" name="employer_phone" value="<?php echo $employer_phone;?>">
                        <input type="hidden" name="employer_company" value="<?php echo $employer_company;?>">
                        
                            <h4 class="bg-grea-3">Basic Information</h4>
                            <div class="search-contents-sidebar">
                                <div class="row pad-20">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Job Title</label>
                                            <input type="text" class="input-text" name="job_title" placeholder="Job Title" 
                                            value="<?php echo  $title; ?>">
                                            <input type="hidden" name="author_id" id="" value="2">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Job Type</label>
                                            <select class="selectpicker search-fields" name="job_type">
                                                <option>Job Type</option>
                                               
                                                <option <?php if ($job_type == 'Full Time') { echo 'selected'; } ?>>Full Time</option>
                                                <option <?php if ($job_type == 'Part Time') { echo 'selected'; } ?>>Part Time</option>
                                                <option <?php if ($job_type == 'Freelance') { echo 'selected'; } ?>>Freelance</option>
                                                <option <?php if ($job_type == 'Temporary') { echo 'selected'; } ?>>Temporary</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <?php
                                            $post_id = $_GET['post_id'];
                                            
                                            // Get the category of the post in the 'job_category' taxonomy
                                            $categories = wp_get_post_terms($post_id, 'job_category');
                                            $selected_category = !is_wp_error($categories) && !empty($categories) ? $categories[0]->name : '';

                                            // Fetch all terms in the 'job_category' taxonomy
                                            $all_categories = get_terms(array(
                                                'taxonomy' => 'job_category',
                                                'hide_empty' => false,
                                            ));
                                            ?>
                                            <label>Job Category</label>
                                            <select class="selectpicker search-fields" name="job_category">
                                                <?php
                                                foreach ($all_categories as $cat) {
                                                    ?>
                                                    <option value="<?php echo $cat->term_id; ?>" <?php if($selected_category == $cat->name) { echo "selected"; } ?>><?php echo $cat->name; ?></option>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Location</label>
                                            <input type="text" class="input-text" name="location" placeholder="Location"
                                             value="<?php echo $location;?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Salary (per month)</label>
                                            <input type="text" class="input-text" name="monthly_payment" placeholder="Rs"
                                            value="<?php echo $monthly_payment; ?>">
                                        </div>
                                    </div>
                                    <!-- <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Gender</label>
                                            <select class="selectpicker search-fields" name="gender">
                                                <option>Gender</option>
                                                <option >Male</option>
                                                <option>Female</option>
                                            </select>
                                        </div>
                                    </div> -->
                                    <!-- <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <select class="selectpicker search-fields" name="country">
                                                    <option>Country</option>
                                                    <option>Usa</option>
                                                    <option>Bangladesh</option>
                                                    <option>Indea</option>
                                                    <option>Canada</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div> -->
                                    <!-- <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <div class="form-group">
                                                <label>City</label>
                                                <select class="selectpicker search-fields" name="City">
                                                    <option>City</option>
                                                    <option>Dhaka</option>
                                                    <option>Dubai</option>
                                                    <option>Mumbai</option>
                                                    <option>Califonia</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div> -->
                                    <!-- <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Qualification</label>
                                            <select class="selectpicker search-fields" name="qualification">
                                                <option>Qualification</option>
                                                <option>Matriculation</option>
                                                <option>Gradute</option>
                                            </select>
                                        </div>
                                    </div> -->
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <?php $qualification = get_field('qualification'); ?>
                                            <label>Qualification (<span class="text-danger">*</span>)</label>
                                            <select class="form-control" name="qualification" required>
                                                <option value="0">Qualification</option>
                                                <option value="Bsc"<?php if($qualification == 'Bsc'){ echo "selected";} ?>>Bsc</option>
                                                <option value="B.A." <?php if($qualification == 'B.A.'){ echo "selected";} ?>>B.A.</option>
                                                <option value="B.Com" <?php if($qualification == 'B.Com'){ echo "selected";} ?>>B.Com</option>
                                                <option value="Bsc(Computer)" <?php if($qualification == 'Bsc(Computer)'){ echo "selected";} ?>>Bsc(Computer)</option>
                                                <option value="BSc(Maths)" <?php if($qualification == 'BSc(Maths)'){ echo "selected";} ?>>BSc(Maths)</option>
                                                <option value="BSc(computer application)" <?php if($qualification == 'BSc(computer application)'){ echo "selected";} ?>>BSc (computer application)</option>
                                                <option value="MSc(computer science)" <?php if($qualification == 'MSc(computer science)'){ echo "selected";} ?>>MSc (computer science)</option>
                                                <option value="MSc" <?php if($qualification == 'MSc'){ echo "selected";} ?>>MSc</option>
                                                <option value="M.E" <?php if($qualification == 'M.E'){ echo "selected";} ?>>M.E</option>
                                                <option value="Any Graduate" <?php if($qualification == 'Any Graduate'){ echo "selected";} ?>>Any Graduate </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Work Hours</label>
                                            <input type="text" class="input-text" value="<?php echo $weekly_time; ?>" name="weekly_time" placeholder="Work Hour">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Application End Date </label>
                                            <?php //echo get_field('application_end_date');?>
                                            <input type="date" class="input-text" name="application_end_date"
                                             placeholder="Application End Date" value="<?php echo $formatted_application_end_date;?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Skills <small class="text-muted">(e.g. skill1, skill2,...etc)</small></label>
                                            <input type="text" class="input-text" name="skills" placeholder="Skills"
                                             value="<?php echo $skills;?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Status </label>
                                            <select class="selectpicker search-fields" name="status">
                                                <option>Status</option>
                                                <option <?php if ($status == 'Active') { echo 'selected'; } ?>>Active </option>
                                                <option <?php if ($status == 'In-Active') { echo 'selected'; } ?>>In-Active</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <label>Experience </label>
                                            <input type="text" class="input-text" name="experience" placeholder="Experience"
                                            value="<?php echo $experience;?>"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label>Job Description</label>
                                            <textarea class="input-text" name="job_description" placeholder="Detailed Information">
                                                <?php echo $job_description; ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <img id="imagePreview" style="height:150px; margin-bottom:5px;" src="<?php echo $post_image; ?>" alt="">
                                        <div class="photoUpload photoUpload-2">
                                            Upload Files
                                            <input type="file" class="upload" name="jobImage"  onchange="previewImage(event)">
                                        </div>
                                    </div>
                                    <div class="col-12"><label for="iamge">Banner Image (Optional): </label></div>
                                    <div class="col-lg-12">
                                        <?php $banner = get_field('job_post_banner'); ?>
                                        <img id="bannerImagePreview" style="height:150px; margin-bottom:5px;" 
                                        src="<?php if($banner){echo $banner;}else{ echo 'https://placehold.co/1920x355'; }?>" alt="">
                                        <div class="photoUpload photoUpload-2">
                                            Upload Files
                                            <input type="file" class="upload" name="jobBannerImage"  onchange="previewBannerImage(event)">
                                        </div>
                                        <div class="post-btn"><button type="submit" name="submit" class="btn btn-md button-theme">Save Changes</button></div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endwhile; wp_reset_postdata(); endif; ?>

<!-- Dashboard end -->
<br><br><br><br>
<!-- Full Page Search -->
<div id="full-page-search">
    <button type="button" class="close">X</button>
    <form action="index.html#">
        <input type="search" value="" placeholder="type keyword(s) here" />
        <button type="submit" class="btn btn-sm button-theme">Search</button>
    </form>
</div>

<?php 
    if(isset($_POST['submit'])){

        echo "helloooooo";
        $author_id = $_POST['author_id'];
        $edit_post_id = $_POST['edit_post_id'];
        //echo $edit_post_id;
        $job_title = $_POST['job_title'];
        $job_description = $_POST['job_description'];
        $qualification = $_POST['qualification'];
        $location = $_POST['location'];
        $experience = $_POST['experience'];
        $job_type = $_POST['job_type'];
        $status = $_POST['status'];

        $job_category = $_POST['job_category'];

        echo $job_category;

        $weekly_time = $_POST['weekly_time'];
        $monthly_payment = $_POST['monthly_payment'];
      
        
        $application_end_date = $_POST['application_end_date'];
       

        $skills = $_POST['skills'];
      
       
        
    // Upload image
    if ($_FILES['jobImage']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = wp_upload_dir();
        $image_path = $upload_dir['path'] . '/' . $_FILES['jobImage']['name'];
        move_uploaded_file($_FILES['jobImage']['tmp_name'], $image_path);

        // Create attachment
        $attachment = array(
            'post_mime_type' => $_FILES['jobImage']['type'],
            'post_title' => sanitize_file_name($_FILES['jobImage']['name']),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attach_id = wp_insert_attachment($attachment, $image_path);

        // Set featured image
        if ($attach_id) {
            set_post_thumbnail($edit_post_id, $attach_id);
        }
    }
      // Upload image
      if ($_FILES['jobBannerImage']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = wp_upload_dir();
        $tmp_name = $_FILES['jobBannerImage']['tmp_name'];

        // Get image size
        list($width, $height) = getimagesize($tmp_name);
        if ($width == 1920 && $height == 355) {
            $image_path = $upload_dir['path'] . '/' . $_FILES['jobBannerImage']['name'];
            move_uploaded_file($_FILES['jobBannerImage']['tmp_name'], $image_path);

            // Create attachment
            $attachment = array(
                'post_mime_type' => $_FILES['jobBannerImage']['type'],
                'post_title' => sanitize_file_name($_FILES['jobBannerImage']['name']),
                'post_content' => '',
                'post_status' => 'inherit'
            );
            $banner = wp_insert_attachment($attachment, $image_path);
            update_field('job_post_banner',$banner,$post_id);
        }else{
            $_SESSION['error-message'] ="Error: The image must be exactly 1920x355 pixels.";
            echo "<script type='text/javascript'>window.location.href='".add_query_arg( array( 'post_id' =>  $_GET['post_id'] ,
            'author_id'=> $_GET['author_id'] ), site_url( 'edit-a-job' ) )."'</script>";
        }
    }


        //Create the post
        $post = array(
            'ID' =>$edit_post_id,
            'post_author' => $author_id,
            'post_type' => 'job-post',
            'post_title' => $job_title,
            'post_content' => $job_description,
            'post_status' => 'publish',
            'post_author' => $_SESSION['userid'],
              );


        // Insert the post
        $post_id = wp_update_post($post);

        
        $post_id = $_GET['post_id']; // Assuming the post ID is passed via GET parameter
        
        // Set the post's terms in the 'job_category' taxonomy
        wp_set_post_terms($post_id, array($job_category), 'job_category');

        
        update_field('skills',$skills,$post_id);
        update_field('qualification', $qualification, $post_id);
        update_field('location', $location, $post_id);
        update_field('experience_required', $experience, $post_id);
        update_field('job_type', $job_type, $post_id);
        

        update_field('weekly_time_demand', $weekly_time, $post_id);
        update_field('monthly_payment', $monthly_payment, $post_id);
        update_field('application_end_date', $application_end_date, $post_id);
        update_field('status', $status, $post_id);

        
        $_SESSION['message'] = "Job Post Updated Succefully";
        //echo "<script type='text/javascript'>window.location.href='". add_query_arg( array( 'post_id' => $edit_post_id ), site_url( 'edit-a-job' ) ) ."'</script>";

        echo "<script type='text/javascript'>window.location.href='".site_url('employer-job-list') ."'</script>";
 

        
        

        
    }
?>