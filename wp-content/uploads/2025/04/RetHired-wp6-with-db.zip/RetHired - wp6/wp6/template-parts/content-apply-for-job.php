<?php
session_start();

$userID = $_GET['userId'];
$postID = $_GET['postId'];

if (is_user_logged_in() && current_user_can('contributor')) {
     
    $_SESSION['message'] = 'Please log in as candidate';
    $title = implode('-', explode(' ', get_the_title($postID)));
    $title = str_replace('/', '-', $title);
    $_SESSION['redirect_to'] =  home_url().'/job-post/'.$title;
    
    wp_logout();
    wp_redirect('login');
    exit;
    
    $_SESSION['redirect_to']  = $_SERVER['REQUEST_URI'];
    wp_redirect(site_url('login'));
    
}
//echo "post id is = " . $postID;
$author_id = get_post_field( 'post_author', $postID );
$candidate = get_user_by('ID', $userID);
// echo "<pre>";
// print_r($candidate);
// echo "</pre>";
// die();
if ($candidate) {
    $candidate_id = $candidate->ID;
    $candidate_name = $candidate->display_name;
    $candidate_email = $candidate->user_email; 
    $candidate_mobile = get_user_meta($candidate->ID,'phone_number',true);
    
    $candidate_dob = get_user_meta($candidate->ID,'dob',true);
    $candidate_gender = get_user_meta($candidate->ID,'gender',true);
    
    $candidate_current_company = get_user_meta($candidate->ID,'current_company',true);
    $candidate_address = get_user_meta($candidate->ID,'address',true);
    
    //echo "Mobile : ".$candidate_mobile;
    $candidate_resume = get_user_meta($candidate->ID,'resume',true); 
    //echo "Resume : ".$candidate_resume;
    
    $candidate_skills = get_user_meta($candidate->ID,'skills',true); 
    //echo "Skills : ".$candidate_skills;
    if (
        empty($candidate_mobile) || 
        empty($candidate_skills) || 
        empty($candidate_resume) || 
        empty($candidate_dob) || 
        empty($candidate_gender) || 
        empty($candidate_current_company) || 
        empty($candidate_address)
    ) {
        $_SESSION['errorMessage'] = "Please complete your profile & update resume";
        $title = implode('-', explode(' ', get_the_title($postID)));
        $title = str_replace('/', '-', $title);
        echo "<script type='text/javascript'>window.location.href='". home_url() . '/job-post/' . $title . "'</script>";
        exit;
    }
    
    // if($candidate_skills == ''){
    //     $_SESSION['errorMessage'] = "Please Add at lease 1 skill in resume before applying.";
    //     //echo $_SESSION['errorMessage'];
    //     $title = implode('-', explode(' ', get_the_title($postID)));
    //     $title = str_replace('/', '-', $title);
    //     $redirectUrl = home_url().'/job-post/'.$title;
    //     $_SESSION['redirect_to'] = $redirectUrl;
    //     echo "<script type='text/javascript'>window.location.href='". home_url().'/job-post/'.$title."'</script>";
    //     exit;
    // }
   
    // if($candidate_resume == ''){
    //     $_SESSION['errorMessage'] = "Please uplaod resume before applying.";
    //     $title = implode('-', explode(' ', get_the_title($postID)));
    //     $title = str_replace('/', '-', $title);
    //     $redirectUrl = home_url().'/job-post/'.$title;
    //     $_SESSION['redirect_to'] = $redirectUrl;
    //     echo "<script type='text/javascript'>window.location.href='". home_url().'/job-post/'.$title."'</script>";
    //     exit;
    // }
    
    $working_status = get_usermeta($candidate->ID,'working_status',true);
    //echo $working_status;
    //die();
   
    $repeater_field_name = 'job_applicant';

   
    $existing_candidates = get_field($repeater_field_name, $postID);

   
    $new_candidate_data = array(
        'user_id' => $candidate_id,
        'name' => $candidate_name,
        'email' => $candidate_email,
        'resume' => $candidate_resume,
        'application_status' => 'Applied', 
        'working_status'=>$working_status,
        'employer_id'=>$author_id,
    );

   
    if ($existing_candidates) {
        $existing_candidates[] = $new_candidate_data;
        $updated_candidates = $existing_candidates;
    } else {
      
        $updated_candidates = array($new_candidate_data);
    }

    // Update the repeater field for the current post
    update_field($repeater_field_name, $updated_candidates, $postID);
    $_SESSION['application_status'] = $new_candidate_data['application_status'];

    //echo "Candidate ID and Name added to repeater field successfully.";
    $_SESSION['message'] = "Job Application sent successfully";
    //echo home_url().'/job-post/'. get_the_title( $postID ); 
    $title = implode('-', explode(' ', get_the_title($postID)));
    $title = str_replace('/', '-', $title);
    
    echo "<script type='text/javascript'>window.location.href='". home_url().'/job-post/'.$title."'</script>";
} else {
    if (!is_user_logged_in()){
        $_SESSION['message'] = "Please login to continue";
        $title = implode('-', explode(' ', get_the_title($postID)));
        $title = str_replace('/', '-', $title);
        $_SESSION['redirect_to'] =  home_url().'/job-post/'.$title;
        wp_redirect('login');
        exit;
    }

    $title = implode('-', explode(' ', get_the_title($postID)));
    $title = str_replace('/', '-', $title);
    echo "<script type='text/javascript'>window.location.href='". home_url().'/job-post/'.$title."'</script>";
}
?>
