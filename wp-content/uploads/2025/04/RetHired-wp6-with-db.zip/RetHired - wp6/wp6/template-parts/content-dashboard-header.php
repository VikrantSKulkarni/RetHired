<?php session_start();?>
<!DOCTYPE html>
<html lang="zxx">
<head>
    <title>RetHired - <?php echo the_title(); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
  
    <!-- Favicon icon -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>

    <link rel="shortcut icon" href="<?php echo bloginfo('template_directory');?>/img/favicon.ico" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,300,700">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Dosis%7CMontserrat:200,300,400,500,600,700,800,900%7CNunito+Sans:200,300,400,600,700,800,900">

    <?php wp_head(); ?>
</head>
<style>
/* .modal-backdrop.show {
    opacity: 0 !important; or 0 if you want it fully transparent
} */

    /* .nav-item  a{
        color:black!important;
    } */
    /* .nav-item  a:hover{
        color:blue!important;
    } */
    /* .dropdown-content {
    right: 0;
    left: auto;
}
    .sticky-header{
        background: white!important;
    }
    .sticky-header .navbar-expand-lg .navbar-nav .nav-link {
        background: white!important;
    } */
</style>
<body>
<!-- <div class="page_loader"></div> -->
 <!-- Main header start -->
 <header class="main-header sticky-header dashboards-header" id="header">
    <div class="container-fluid">
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand logo" href="<?php echo home_url(); ?>">
            <?php 
            if(has_custom_logo()){
            the_custom_logo();
            }?>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <?php if(is_user_logged_in() && current_user_can('subscriber')) {?>
            <ul class="navbar-nav ml-auto">
                <li>
                <div class="dropdown btns">
                    <a class="dropdown-toggle nav-link text-dark" data-toggle="dropdown">
                        <?php 
                            $current_user_id = get_current_user_id(); 
                            $custom_avatar_url = get_user_meta($current_user_id, 'profile_image', true);

                            if ($custom_avatar_url) {
                            $avatar_url = esc_url($custom_avatar_url);
                            } else {
                            // Get the default WordPress avatar URL
                            $avatar_url = get_avatar_url($current_user_id);
                            }
                        ?>
                        <?php 
                        //echo get_avatar(get_current_user_id(), 40, '', 'avatar', ['class' => 'user-avatar rounded-circle']);
                    ?>
                    <img src="<?php echo $avatar_url; ?>" alt="avatar" style="width: 40px;height:40px;border-radius:50%;">
                    Hi, <?php echo get_user_meta(get_current_user_id(), 'first_name', true); ?>
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo site_url('/candidate-dashboard'); ?>"> <i class="flaticon-dashboard"></i> Dashboard</a>
                        <a class="dropdown-item" href="<?php echo site_url('/profile'); ?>"><i class="flaticon-user"></i> Edit profile</a>
                        <a class="dropdown-item" href="<?php echo site_url('/candidate-resume'); ?>"> <i class="flaticon-portfolio"></i> Add Resume </a>
                        <a class="dropdown-item" data-toggle="modal" data-target="#logoutModal" href="<?php echo site_url('/logout'); ?>"><i class="flaticon-logout"></i> Logout</a>
                    </div>
                </div>
                </li>
            </ul>
            <?php }elseif(is_user_logged_in() && current_user_can('contributor')){?>
            <ul class="navbar-nav ml-auto">
                <li>
                <div class="dropdown btns">
                    <a class="dropdown-toggle nav-link text-dark" data-toggle="dropdown">
                            <?php
                            $current_user_id = get_current_user_id(); 
                            $custom_avatar_url = get_user_meta($current_user_id, 'profile_image', true);

                            if ($custom_avatar_url) {
                            $avatar_url = esc_url($custom_avatar_url);
                            } else {
                            // Get the default WordPress avatar URL
                            $avatar_url = get_avatar_url($current_user_id);
                            }?>
                    <img src="<?php echo $avatar_url; ?>" alt="avatar" style="width:40px; height:40px;border-radius:50%;">
                    Hi, <?php echo get_user_meta(get_current_user_id(),'first_name',true);?>
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo site_url('/employer-dashboard');?>"><i class="flaticon-dashboard"></i>  Dashboard</a>
                        <a class="dropdown-item" href="<?php echo site_url('/profile');?>"><i class="flaticon-user"></i>  Edit profile</a>
                        <a class="dropdown-item" href="<?php echo site_url('employer-job-list'); ?>"><i class="flaticon-work"></i> Manage Jobs</a>
                        <a class="dropdown-item" data-toggle="modal" data-target="#logoutModal" href="<?php echo site_url('/logout');?>"><i class="flaticon-logout"></i> Logout</a>
                    </div>
                </div>
                </li>
                <li class="nav-item">
                <a href="<?php echo site_url('create-a-job'); ?>" class="nav-link link-color"><i class="flaticon-plus"></i> Post a Job</a>
                </li>
            </ul>
            <?php }elseif(is_user_logged_in() && current_user_can('administrator')){ ?>
                <ul class="navbar-nav ml-auto">
                <li>
                <div class="dropdown btns">
                    <a class="dropdown-toggle nav-link text-dark" data-toggle="dropdown">
                            <?php
                            $current_user_id = get_current_user_id(); 
                            $custom_avatar_url = get_user_meta($current_user_id, 'profile_image', true);

                            if ($custom_avatar_url) {
                            $avatar_url = esc_url($custom_avatar_url);
                            } else {
                            // Get the default WordPress avatar URL
                            $avatar_url = get_avatar_url($current_user_id);
                            }?>
                    <img src="<?php echo $avatar_url; ?>" alt="avatar" style="width:40px; height:40px;border-radius:50%;">
                    Hi, <?php echo get_user_meta(get_current_user_id(),'first_name',true);?>
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo $redirect_to = admin_url(); ?>"><i class="flaticon-dashboard"></i>  Dashboard</a>
                        <a class="dropdown-item" href="<?php echo site_url('/profile');?>"><i class="flaticon-user"></i>  Edit profile</a>
                        <a class="dropdown-item" href="<?php echo site_url('employer-job-list'); ?>"><i class="flaticon-work"></i> Manage Jobs</a>
                        <a class="dropdown-item" data-toggle="modal" data-target="#logoutModal" href="<?php echo site_url('/logout');?>"><i class="flaticon-logout"></i> Logout</a>
                    </div>
                </div>
                </li>
                <li class="nav-item">
                <a href="<?php echo site_url('create-a-job'); ?>" class="nav-link link-color"><i class="flaticon-plus"></i> Post a Job</a>
                </li>
            </ul>
            <?php }
            else{ ?>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item ">
                <a class="nav-link" href="<?php echo site_url('login');?>">
                <i class="flaticon-logout"></i>Sign In
                </a>
                </li>
                <li class="nav-item">
                <a href="<?php echo site_url('create-a-job'); ?>" class="nav-link link-color"><i class="flaticon-plus"></i> Post a Job</a>
                </li>
            </ul>
            <?php }?>
        </div>
    </nav>
    </div>
</header>
<script>
    function adjustHeader() {
        var windowWidth = $(window).width();
        var $logoImg = $('.logo img');
        var $stickyHeader = $('.sticky-header');

        if (windowWidth > 992) {
            if ($(document).scrollTop() >= 100) {
                if (!$stickyHeader.hasClass('header-shrink')) {
                    $stickyHeader.addClass('header-shrink');
                }
                $logoImg.attr('src', '<?php echo bloginfo('template_directory')."/img/pixel6_black.png"; ?>');
            } else {
                $stickyHeader.removeClass('header-shrink');
                $logoImg.attr('src', '<?php echo bloginfo('template_directory')."/img/pixel6_white.png"; ?>');
            }
        } else {
            $logoImg.attr('src', '<?php echo bloginfo('template_directory')."/img/pixel6_black.png"; ?>');
        }
    }

    $(document).ready(function() {
        adjustHeader();
    });

    $(window).on('scroll resize', function() {
        adjustHeader();
    });
</script>
