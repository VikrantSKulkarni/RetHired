<?php session_start();
get_header(); 
if(!is_user_logged_in()){ ?>
    <script>
        document.getElementById("header").style.display='none';
    </script>
    <?php }else{
        if(current_user_can('contributor')){    
        echo "<script>location.href='".site_url('employer-dashboard')."'</script>";
    }elseif(current_user_can('subscriber')){
        echo "<script>location.href='".site_url('candidate-dashboard')."'</script>";
    }elseif(current_user_can('administrator')){
        echo "<script>location.href='".admin_url()."'</script>";
    }
    }
    ?>
<?php if (is_page('login')){?>
    <script>
        document.getElementById("header").style.display='none';
    </script>    
<?php }?>
<div class="contact-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-message-box">
                    <?php if (isset($_SESSION['message'])) { ?>
                        <div class="alert alert-success alert-2" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                        </div>
                    <?php } ?>

                    <?php if (isset($_SESSION['error_message'])) { ?>
                        <div class="alert alert-danger alert-2" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                        </div>
                    <?php } ?>
                </div>
                <div class="form-content-box">
                    <div class="details">
                        <a href="<?php echo home_url(); ?>">
                            <img src="<?php echo get_theme_file_uri("/img/logos/p-6.png"); ?>" alt="logo">
                        </a>
                        <h3>Sign into your account</h3>
                        <form action="" method="post">
                            <div class="form-group">
                                <input type="text" name="email" class="input-text" placeholder="Username or Email" autofocus required>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <input style="border-right:none;" type="password" autocomplete="off" class="form-control" id="password" name="password_login" placeholder="Password" required>
                                    <button style="border-left:none;border-color:#ced4da" class="btn btn-outline-secondary" type="button" onclick="togglePasswordLog();" id="togglePassword">
                                        <i class="fa fa-eye" id="eye-icon" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="checkbox">
                                <a href="<?php echo site_url('forgot-password'); ?>" class="link-not-important pull-right">Forgot Password?</a>
                                <div class="clearfix"></div>
                            </div>
                            <div class="form-group mb-0">
                                <button type="submit" name="login" class="btn-md button-theme btn-block">Login</button>
                            </div>
                        </form>
                    </div>
                    <div class="footer">
                        <span>Don't have an account? <a href="<?php echo site_url('/register'); ?>">Register</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- <script src="js/jquery-2.2.0.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-submenu.js"></script>
<script src="js/rangeslider.js"></script>
<script src="js/jquery.mb.YTPlayer.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.scrollUp.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/leaflet.js"></script>
<script src="js/leaflet-providers.js"></script>
<script src="js/leaflet.markercluster.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/daterangepicker.min.js"></script>
<script src="js/dropzone.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/jquery.filterizr.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.countdown.js"></script>
<script src="js/maps.js"></script>
<script src="js/app.js"></script>
<script src="js/ie10-viewport-bug-workaround.js"></script>
<script src="js/ie10-viewport-bug-workaround.js"></script> -->
</body>
</html>
