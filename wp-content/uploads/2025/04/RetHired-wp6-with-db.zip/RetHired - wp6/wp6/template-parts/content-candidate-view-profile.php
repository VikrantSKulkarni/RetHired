<?php $candidate = get_user_by('ID',$_GET['user_id']); 
//    echo "<pre>";
//    print_r($candidate);
//    echo "</pre>";
   
   ?>
<style>
    .sub-banner{
        background: rgba(0, 0, 0, 0.04) url(<?php echo get_theme_file_uri("/img/job_list_bg3.png"); ?>) top left repeat;
    }
</style>
<?php get_header(); ?>
<!-- Sub banner start -->
<div class="sub-banner bg-color-full">
    <div class="container">
        <div class="breadcrumb-area">
            <h1><?php echo $candidate->first_name.$candidate->last_name; ?></h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo home_url();?>">Home</a></li>
                <li class="active"><?php echo $candidate->first_name.$candidate->last_name; ?></li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub banner end -->

<!-- Candidate section start -->
<div class="candidate-section content-area">

    <div class="container">
    <?php if (isset($_SESSION['message'])) { ?>
        <div class="alert alert-success alert-2" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
        </div>
    <?php } ?>
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <!-- job box start -->
                <div class="job-box-2">
                    <div class="company-logo">
                        <?php
                            $current_user_id = $candidate->ID; // Replace with specific user ID if needed
                            $custom_avatar_url = get_user_meta($current_user_id, 'profile_image', true);
                            if ($custom_avatar_url) {
                            $avatar_url = esc_url($custom_avatar_url);
                            } else {
                            // Get the default WordPress avatar URL
                            $avatar_url = get_avatar_url($current_user_id);
                            }
                        ?>
                        <img src="<?php echo $avatar_url;?>" alt="avatar">
                    </div>
                    <div class="description">
                        <h5 class="title"><a href="#"><?php echo get_user_meta( $candidate->ID, 'first_name', true ); ?></a></h5>
                        <div class="candidate-listing-footer">
                            <ul>
                                <?php if(get_user_meta( $candidate->ID, 'job_profile', true )){ ?><li><i class="flaticon-tick"></i> <?php echo get_user_meta( $candidate->ID, 'job_profile', true ); ?></li> <?php }?>
                                <?php if(get_user_meta( $candidate->ID, 'address', true )){?><li><i class="flaticon-pin"></i> <?php echo get_user_meta( $candidate->ID, 'address', true ); ?></li><?php }?>
                            </ul>
                        </div>
                    </div>
                </div>

                <hr class="hr-boder clearfix">
                <!-- about me start -->
                <div class="about-me mb-40">
                    <h3 class="heading-2">About </h3>
                    <p><?php $bio = get_user_meta($candidate->ID,'bio', true);if($bio){echo $bio;}else{
                        echo "<span class='text-muted'>No data found !</spnan>";
                    } ?></p>
                </div>
                <!-- Education start-->
                <div class="education mb-50">
                    <h3 class="heading-2">Education</h3>
                    <?php if(get_user_meta($candidate->ID,'education', true)){ ?>
                    <div class="education-box">
                        <div class="icon">
                            <i class="flaticon-mortarboard"></i>
                        </div>
                        <div class="employer-info">
                            <!-- <h5>Web Designer <span> / themeforest</span></h5> -->
                            <!-- <h6>2015 - 2019</h6> -->
                            <p><?php echo get_user_meta($candidate->ID,'education', true); ?></p>
                        </div>
                    </div>
                    <?php }else{ echo "<span class='text-muted'>No data found !</span>"; }?>
                    <!-- <div class="education-box mb-0">
                        <div class="icon">
                            <i class="flaticon-mortarboard"></i>
                        </div>
                        <div class="employer-info">
                            <h5>Graphic Designer <span> / themeforest</span></h5>
                            <h6>2014 - 2018</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus tincidunt aliquam. Aliquam gravida massa at sem vulputate interdum.</p>
                        </div>
                    </div> -->
                </div>
                <!-- Work experiance start-->
                <!-- <div class="work-experiance mb-50">
                    <h3 class="heading-2">Work Experiance</h3>
                    <div class="education-box">
                        <div class="icon">
                            <i class="flaticon-work"></i>
                        </div>
                        <div class="employer-info">
                            <h5>Dhaka College <span> / Economics</span></h5>
                            <h6>2015 - 2019</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus tincidunt aliquam. Aliquam gravida massa at sem vulputate interdum.</p>
                        </div>
                    </div>
                    <div class="education-box mb-0">
                        <div class="icon">
                            <i class="flaticon-work"></i>
                        </div>
                        <div class="employer-info">
                            <h5>University of south asia <span> / Computer Science</span></h5>
                            <h6>2014 - 2018</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus tincidunt aliquam. Aliquam gravida massa at sem vulputate interdum.</p>
                        </div>
                    </div>
                </div> -->
                <!-- Progressbar example start -->
                <div class="progressbar-example mb-40">
                    <h3 class="heading-2">Professional Skills</h3>
                    <!-- <div class="row">
                        <div class="col-lg-12">
                            <div class="progress-box">
                                <p class="progress-title">Web Development</p>
                                <p class="progress-size">80%</p>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="progress-box">
                                <p class="progress-title">Consulting</p>
                                <p class="progress-size">100%</p>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="progress-box">
                                <p class="progress-title">Branding & Identity</p>
                                <p class="progress-size">70%</p>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="progress-box">
                                <p class="progress-title">Graphic Design</p>
                                <p class="progress-size">90%</p>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%"></div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <?php $skills = get_user_meta($candidate->ID,'skills',true);
                        //echo $skills;
                        if($skills){
                    $allskills = explode(",",$skills);
                    //print_r($allskills);
                    foreach($allskills as $skill){ ?>
                        <span class="badge p-3 text-light bg-secondary mb-2"><?php echo $skill; ?></span>
                    <?php }
                    }else{
                        echo "<span class='text-muted'>No data found !</span>";
                    }
                    ?>
                </div>
                <!-- Portfolio start -->
                <!-- <div class="portfolio">
                    <h3 class="heading-2">Portfolio</h3>
                    <div class="container">
                        <div class="slick-slider-area">
                            <div class="row slick-carousel" data-slick='{"slidesToShow": 3, "responsive":[{"breakpoint": 1024,"settings":{"slidesToShow": 3}}, {"breakpoint": 768,"settings":{"slidesToShow": 2}}]}'>
                                <div class="slick-slide-item">
                                    <div class="portfolio-item">
                                        <a href="http://placehold.it/750x540" title="Portfolio">
                                            <img src="http://placehold.it/214x160" alt="gallery" class="img-fluid">
                                        </a>
                                        <div class="portfolio-content">
                                            <div class="portfolio-content-inner">
                                                <p>Portfolio</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="slick-slide-item">
                                    <div class="portfolio-item">
                                        <a href="http://placehold.it/750x540" title="Portfolio">
                                            <img src="http://placehold.it/214x160" alt="gallery" class="img-fluid">
                                        </a>
                                        <div class="portfolio-content">
                                            <div class="portfolio-content-inner">
                                                <p>Portfolio</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="slick-slide-item">
                                    <div class="portfolio-item">
                                        <a href="http://placehold.it/750x540" title="Portfolio">
                                            <img src="http://placehold.it/214x160" alt="gallery" class="img-fluid">
                                        </a>
                                        <div class="portfolio-content">
                                            <div class="portfolio-content-inner">
                                                <p>Portfolio</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="slick-slide-item clearfix">
                                    <div class="portfolio-item">
                                        <a href="http://placehold.it/750x540" title="Portfolio">
                                            <img src="http://placehold.it/214x160" alt="gallery" class="img-fluid">
                                        </a>
                                        <div class="portfolio-content">
                                            <div class="portfolio-content-inner">
                                                <p>Portfolio</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="slick-prev slick-arrow-buton">
                                <i class="fa fa-angle-left"></i>
                            </div>
                            <div class="slick-next slick-arrow-buton">
                                <i class="fa fa-angle-right"></i>
                            </div>
                        </div>
                    </div>
                </div> -->
            </div>
            <div class="col-lg-4 col-md-12">
                <div class="sidebar-right-2">
                    <div class="widget">
                        <form method="GET">
                        <?php
                                if(is_user_logged_in()){
                                $current_user_id = get_current_user_id();
                                $currentUser = wp_get_current_user();
                               
                                $click_cv_id = $_GET['user_id'];
                                $user_role = $currentUser->roles[0];
                                }

                                if (isset($user_role) && isset($current_user_id)) {
                                
                                    if ($user_role == 'contributor') {
                                      $user_resume = get_user_meta($click_cv_id,'resume',true); 
                                        if($user_resume){ ?>
                                        <div class="form-group mb-0">
                                            <button class="search-button button-theme">
                                                <a class="text-light" target= "__blank" href="<?php  echo get_user_meta($click_cv_id,'resume',true);?>">Download CV</a>
                                            </button>
                                        </div>
                                        <?php }?>
                                        
                                <?php
                                    
                                    } elseif ($user_role == 'subscriber' && $current_user_id == $click_cv_id) {
                                ?>
                                        <div class="form-group mb-0">
                                            <button class="search-button button-theme">
                                                <a class="text-light" target="__blank" href="<?php echo get_user_meta($click_cv_id,'resume',true);?>">Download CV</a>
                                            </button>
                                        </div>
                                <?php
                                    }
                                }
                             ?>



                            <div class="form-group mb-0 mt-2">
                                <?php
                                //echo  get_user_meta($_GET['user_id'],'working_status',true);
                                if(is_user_logged_in() && current_user_can('contributor') && isset($_GET['post_id'])){
                                if((get_user_meta($_GET['user_id'],'working_status',true)) == 'Released'){?>
                                    <a href="<?php echo esc_url( add_query_arg(   array(
                                    'user_id' => $_GET['user_id'],'post_id'=>$_GET['post_id'],
                                    ), site_url('selection') ) ); ?>" class="btn btn-success btn-lg w-100 btn-engaged">Select</a>
                                    <!-- <a href="" class="btn btn-danger btn-sm btn-engaged">Reject</a> -->
                                    <?php
                                }else{?>
                                    <p class="btn btn-danger btn-lg w-100 text-center">Engaged </p>
                                    <?php if (get_user_meta($_GET['user_id'], 'working_status_post_id', true) == $_GET['post_id']) { ?>
                                        <a onclick="return confirm('Are you sure to release this candidate ?');"  href="<?php echo esc_url( add_query_arg(   array(
                                        'user_id' => $_GET['user_id'],'post_id'=>$_GET['post_id'],
                                        ), site_url('released') ) ); ?>"class="btn btn-success btn-sm text-center btn-lg w-100">Release </a>
                                    <?php } ?>

                                    <?php 
                                }?>
                                <?php }?>
                            </div>
                        </form>
                    </div>
                    <!-- Job overview start -->
                    <div class="job-overview widget">
                        <h3 class="sidebar-title">Overview</h3>
                        <div class="s-border"></div>
                        <ul>
                            <!-- <li><i class="flaticon-money"></i><h5>Salary</h5><span>£12,000 - £25,000</span></li> -->
                            <?php if(get_user_meta( $candidate->ID, 'address', true )){?><li><i class="flaticon-pin"></i><h5>Location</h5><span><?php echo get_user_meta( $candidate->ID, 'address', true ); ?></span></li><?php }?>
                            <?php if(get_user_meta( $candidate->ID, 'gender', true )){?><li><i class="flaticon-woman"></i><h5>Gender</h5><span><?php echo get_user_meta( $candidate->ID, 'gender', true ); ?></span></li><?php }?>
                            <!-- <li><i class="flaticon-work"></i><h5>Job Type</h5><span>Full Time</span></li> -->
                            <?php if(get_user_meta( $candidate->ID, 'qualification', true )){?><li><i class="flaticon-honor"></i><h5>Qualification</h5><span><?php echo get_user_meta( $candidate->ID, 'education', true ); ?></span></li><?php }?>
                                <?php if(get_user_meta( $candidate->ID, 'experience', true )){?><li><i class="flaticon-notepad"></i><h5>Experience</h5><span><?php echo get_user_meta( $candidate->ID, 'experience', true ); ?> Year(s)</span></li><?php }?>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                    <!-- Quick contact start -->
                    <!-- <div class="widget-5 contact-2 quick-contact">
                        <h3 class="sidebar-title">Quick Contacts</h3>
                        <div class="s-border"></div>
                        <form action="#" method="GET" enctype="multipart/form-data">
                            <div class="form-group name">
                                <input type="text" name="name" class="form-control" placeholder="Name">
                            </div>
                            <div class="form-group email">
                                <input type="email" name="email" class="form-control" placeholder="Email">
                            </div>
                            <div class="form-group message">
                                <textarea class="form-control" name="message" placeholder="Write message"></textarea>
                            </div>
                            <div class="send-btn">
                                <button type="submit" class="btn btn-md button-theme">Send Message</button>
                            </div>
                        </form>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Candidate section end -->
<?php get_footer(); ?>