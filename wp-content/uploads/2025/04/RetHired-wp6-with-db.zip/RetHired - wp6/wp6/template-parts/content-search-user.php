<?php get_header(); ?>
<div class="container" style="background:#F5F5F5;">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-12 col-sm-12">
            <h1 class="title">Candidates</h1>
        </div>
        <div class="col-lg-5 col-md-12 col-sm-12">
            <form action="<?php echo site_url('search-user');?>" method="get" class="form-group">
                <div class="input-group">
                    <label class="visually-hidden" for="searchUser">Search</label>
                    <input type="text" name="candidate" id="searchUser" class="form-control" placeholder="Search for a candidate">
                    <button type="submit" name="search" class="btn btn-success">Search</button>
                </div>
            </form>
        </div> 
    </div>
    <div class="row">
        <?php
        if(isset($_GET['search'])){
         $search = $_GET['candidate'];
        }      
        $args = array(
                  'role'         => 'subscriber',
                  'meta_key'     => 'first_name',
                  'meta_value'   => $search,
                  'meta_compare' => 'LIKE'
                  );
        $total_users = count_users()['total_users'];
        $users_per_page = 6;
        $total_pages = ceil($total_users / $users_per_page);
        $current_page = max(1, get_query_var('paged'));
        $offset = ($current_page - 1) * $users_per_page;
        $args['number'] = $users_per_page;
        $args['offset'] = $offset;
        $users = get_users($args);
        //echo "<pre>";print_r($users);echo "</pre>";
        foreach($users as $user){ ?>
        <div class="col-lg-4 col-md-12 col-sm-12">
            <div class="card text-center align-items-center p-2">
                <img class="rounded-circle" style="width:100px;height:100px;" src="<?php echo get_user_meta($user->ID,'user_profile_image',true);?>" class="card-img-top" alt="Candidate Profile">
                    <div class="mt-2 mb-2">
                        <?php $work_status = get_user_meta($user->ID,'working_status',true);
                            if($work_status == 'Released'){
                            ?><span class="badge bg-success"><?php echo $work_status; ?></span>
                        <?php }elseif($work_status=='Engaged'){?>
                        <span class="badge bg-danger"><?php echo $work_status; ?></span>
                        <?php }?>
                    </div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo get_user_meta($user->ID,'first_name',true);?></h5>
                    <p class="card-text" style="height:70px;overflow:hidden;"><?php echo get_user_meta($user->ID,'bio',true);?></p>
                    <a href="<?php echo esc_url( add_query_arg( array( 'user_id' => $user->ID ), site_url('candidate-view-profile') ) );?>" class="btn btn-success">
                      View Profile
                    </a>
                </div>
            </div> 
        </div><!-- Repeating container  -->
        <?php }?>
        <!--  Pagination Div ---------->
        <div class="row justify-content-center">
            <div class="col-2 mt-4">
            <?php
                // Pagination
                echo '<ul class="pagination">';
                echo '<li class="page-item">';
                echo paginate_links( array(
                    'total' =>  $total_pages,
                    'current' => $current_page,
                    'prev_next' => true,
                    'prev_text' => __('« Previous'),
                    'next_text' => __('Next »'),
                ) );
                echo '</li>';
                echo '</ul>';
                echo '</div>';
            ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>