<?php 
if (!is_user_logged_in()) {
   $_SESSION['message'] = 'Please log in to continue.';
   $_SESSION['redirect_to']  = $_SERVER['REQUEST_URI'];
   wp_redirect(site_url('login'));  
}
$currentUserId = get_current_user_id();
//echo $currentUserId;
?>
<!-- Dashbord start -->
<?php include(get_template_directory() . '/template-parts/content-dashboard-header.php'); ?>
<div class="dashboard">
   <div class="container-fluid">
      <div class="row">
         <div class="col-lg-3 col-md-12 col-sm-12 p-0">
            <?php get_sidebar();?>
         </div>
         <div class="col-lg-9 col-md-12 col-sm-12 p-0">
               <div class="dashboard-content">
                  <div class="dashboard-header clearfix">
                     <div class="row">
                        <div class="col-sm-12 col-md-6">
                           <h4>Edit Profile</h4>
                        </div>
                        <div class="col-sm-12 col-md-6">
                           <div class="breadcrumb-nav">
                              <ul>
                                 <li>
                                    <a href="<?php  echo home_url('/');?>">Home</a>
                                 </li>
                                 
                                 <?php if (is_user_logged_in() && current_user_can('contributor')){?>
                                 <li>
                                    <a href="<?php echo site_url('employer-dashboard'); ?>">Dashboard</a>
                                 </li>
                                 <?php }else{?>
                                 <li>
                                    <a href="<?php echo site_url('candidate-dashboard'); ?>">Dashboard</a>
                                 </li>
                                 <?php }?>
                                 <li class="active">Edit Profile</li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmLabel" aria-hidden="true">
                     <div class="modal-dialog" role="document">
                        <div class="modal-content">
                           <div class="modal-header">
                              <h5 class="modal-title" id="deleteConfirmLabel">Delete Confirmation</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                              </button>
                           </div>
                           <div class="modal-body">
                              Are you sure you want to delete?
                           </div>
                           <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                              <a href="<?php echo add_query_arg( array('user_id'=>$currentUserId ), site_url( 'delete-user-avatar' ) );?>" class="btn btn-danger">Delete</a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <?php if(isset($_SESSION['message'])){ ?>
                  <div class="alert alert-success alert-2" role="alert">
                     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                     <?php echo $_SESSION['message']; ?>
                  </div>
                  <?php }?>
                  <?php unset($_SESSION['message']); ?> 
                  <div class="dashboard-list">
                     <h3 class="heading">Basic Info</h3>
                     <div class="dashboard-message contact-2 bdr clearfix">
                        <form action="" method="post" enctype="multipart/form-data">
                           <div class="row">
                              <div class="col-lg-3 col-md-3">
                                 <!-- Edit profile photo -->
                                 <label for="feature-image profile-img-label">Profile Image:</label><br>
                                 <?php $profileImg = get_user_meta($currentUserId,'profile_image',true);
                                    //echo $image_url;
                                    $attachment_id = attachment_url_to_postid($profileImg);
                                    if($attachment_id){ ?>
                                 <a  id="deleteBtn" class="text-danger" data-toggle="modal" data-target="#deleteConfirm" href="#" ><i class="delete fa fa-trash-o"></i> Delete </a>
                                 <?php }?>
                                 <div class="edit-profile-photo">
                                 <?php
                                  $current_user_id = get_current_user_id(); // Replace with specific user ID if needed
                                  $custom_avatar_url = get_user_meta($current_user_id, 'profile_image', true);
                                  if ($custom_avatar_url) {
                                    $avatar_url = esc_url($custom_avatar_url);
                                  } else {
                                    // Get the default WordPress avatar URL
                                    $avatar_url = get_avatar_url($current_user_id);
                                  }
                                 ?>
                                    <img id="imagePreview" src="<?php echo $avatar_url; ?>" alt="User Avatar" class="img-fluid">
                                    <!-- <button id="rmBtn" type="button" onclick="removeImage();"; style="display:none;font-size:34px;border:none;background:none;">&times;</button> -->
                                    <div class="change-photo-btn">
                                       <div class="photoUpload">
                                          <span><i class="fa fa-upload"></i></span>
                                          <!-- <input type="file" class="upload"> -->
                                          <input type="file" class="form-control upload" id="feature-image" name="avatar" onchange="previewImage(event)">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-9 col-md-9">
                                 <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group name">
                                          <label>Your Name</label>
                                          <input type="text" name="full_name"  id="full-name" class="form-control" placeholder="Your Name" value="<?php echo get_user_meta( $currentUserId, 'first_name', true );?>">
                                       </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group email">
                                          <label>Date of Birth:</label>
                                          <input type="date" id="date-of-birth" name="dob" class="form-control" placeholder="Your Title" max="<?php echo date("Y-m-d"); ?>" value="<?php echo get_user_meta( $currentUserId, 'dob', true );?>" onchange="calculateAge()">
                                       </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group subject">
                                          <label>Phone</label>
                                          <div class="d-flex">
                                          <select name="country_code" id="country_code" style="border-color: #fdf;width:40%;">
                                          </select>
                                          <?php $mobile = get_user_meta( $currentUserId, 'phone_number', true );
                                                $mobile = explode(" ",$mobile);

                                          ?>
                                             <input type="number"  class="form-control" maxlength="10" placeholder="Phone" id="phone-number" name="phone_number" value="<?php echo $mobile[1];?>"  oninput="validatephoneNumber(event);">   
                                          </div>
                                       </div>
                                    </div>
                                    <script>
                                       // Fetch countries from API
                                       fetch("https://api.countrystatecity.in/v1/countries/", {
                                          method: 'GET',
                                          headers: {
                                                "X-CSCAPI-KEY": "NHhvOEcyWk50N2Vna3VFTE00bFp3MjFKR0ZEOUhkZlg4RTk1MlJlaA=="
                                          }
                                       })
                                       .then(response => response.json()) // Parse response as JSON
                                       .then(data => {
                                          // Select the dropdown element
                                          var select = document.getElementById('country_code');

                                          // Iterate over each country in the data
                                          data.forEach(country => {
                                                // Create an option element
                                                var option = document.createElement('option');
                                                option.value = country.phonecode; // Set option value to phonecode
                                                option.textContent = `${country.iso2} (${country.phonecode})`; // Set option text to "Country Name (Phone Code)"
                                                select.appendChild(option); // Append option to select dropdown

                                                 // Check if this country code matches user's stored country code
                                                 <?php
                                                         $mobile = get_user_meta($currentUserId, 'phone_number', true);
                                                         $mobile_parts = explode(" ", $mobile);
                                                         $user_phonecode = $mobile_parts[0]; // Extracted phone code
                                                   ?>
                                                 // Check if this country code matches user's stored phone code
                                                   if ('<?php echo $user_phonecode; ?>' === country.phonecode) {
                                                      option.selected = true; // Pre-select this option
                                                   }
                                          });
                                       })
                                       .catch(error => console.log('error', error));
                                    </script>

                                    <!-- <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Email</label>
                                          <?php //$candidate = get_user_by('ID',$_SESSION['userid']); ?>
                                          <input type="email"  class="form-control" placeholder="Email" id="user_email" name="user_email" value="<?php //echo $candidate->user_email;?>" >
                                         
                                       </div>
                                       </div> -->
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                       <div class="form-group">
                                          <label>Gender</label>
                                          <select class="selectpicker search-fields" name="gender" value="<?php $gender = get_user_meta( $currentUserId, 'gender', true );?>">
                                             <option value="male" <?php if($gender == 'Male'){ echo "selected";}?>>Male</option>
                                             <option value="female" <?php if($gender == 'female'){ echo "selected";}?>>Female</option>
                                             <option value="other" <?php if($gender == 'Other'){ echo "selected";}?>>Other</option>
                                          </select>
                                       </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Age</label>
                                          <input readonly="true" type="number"  class="form-control" placeholder="Age"  id="age" name="age" value="<?php echo get_user_meta( $currentUserId, 'age', true );?>">
                                       </div>
                                    </div>
                                    <?php $currentUser = wp_get_current_user();
                                       $user_role = $currentUser->roles[0];
                                       ?>
                                    <?php //if($user_role=='contributor'){ ?>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Current Company</label>
                                          <input type="text"  class="form-control" placeholder="Current company" id="Current-company" name="current_company" value="<?php echo get_user_meta( $currentUserId, 'current_company', true );?>">
                                       </div>
                                    </div>
                                    <?php //} ?>
                                    <!-- <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Experience</label>
                                          <input type="text"  class="form-control" placeholder="Experience" id="experience" name="experience" value="<?php //echo get_user_meta( $user_ID, 'experience', true );?>">
                                       </div>
                                       </div> -->
                                    <!-- <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Language</label>
                                          <input type="text"  id="language" name="language"value="<?php //echo get_user_meta( $user_ID, 'language', true );?>"  class="form-control" placeholder="Language">
                                       </div>
                                       </div> -->
                                    <!-- <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Current Company</label>
                                          <input type="text"name="company" value="<?php //echo get_user_meta( $user_ID, 'current_company', true );?>" class="form-control" placeholder="Current Company">
                                       </div>
                                       </div> -->
                                    <!-- <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Industry</label>
                                          <input type="text" id="industry" name="industry" value="<?php //echo get_user_meta( $user_ID, 'industry', true );?>" class="form-control" placeholder="Industry">
                                       </div>
                                       </div>
                                       <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Skills</label>
                                          <input type="text"  id="skills" name="skills" value="<?php //echo get_user_meta( $user_ID, 'skills', true );?>" class="form-control" placeholder="Skills">
                                       </div>
                                       </div> -->
                                    <div class="col-lg-12 col-md-12">
                                       <div class="form-group number">
                                          <label>Address</label>
                                          <input type="text"id="address"  name="address" value="<?php echo get_user_meta( $currentUserId, 'address', true );?>" class="form-control" placeholder="Address">
                                       </div>
                                    </div>
                                    <!-- <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <label>Category</label>
                                          <input type="text" name="category" class="form-control" placeholder="Category">
                                       </div>
                                       </div> -->
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                       <div class="form-group mb-0 message">
                                          <label>About Me</label>
                                          <textarea class="form-control"  placeholder="Write"  id="about" name="about"><?php echo get_user_meta( $currentUserId, 'bio', true );?></textarea>
                                       </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                       <div class="form-group number">
                                          <button type="submit" class="btn btn-md button-theme mt-2" name="submit1">Update</button>
                                       </div>
                                    </div>
                                 </div>
                        </form>
                        </div>
                        </div>
                     </div>
                  </div>
               </div>
               <?php get_footer('secondary'); ?>
           </div>
      </div>
   </div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- Dashbord end -->
<!-- Full Page Search -->
<div id="full-page-search">
   <button type="button" class="close">X</button>
   <form action="index.html#">
      <input type="search" value="" placeholder="type keyword(s) here" />
      <button type="submit" class="btn btn-sm button-theme">Search</button>
   </form>
</div>
<?php 
   if (isset($_POST['submit1'])) {
       echo "pixel6 demo";
       // Retrieve form data
       $full_name = sanitize_text_field($_POST['full_name']);
       $dob = sanitize_text_field($_POST['dob']);
       $phone_number = sanitize_text_field($_POST['phone_number']);
       $country_code = sanitize_text_field($_POST['country_code']);

       $numberWithCode = $country_code." ".$phone_number;
       
       $user_email = sanitize_email($_POST['user_email']);
       $gender = sanitize_text_field($_POST['gender']);
       $age = sanitize_text_field($_POST['age']);
       $current_company = sanitize_text_field($_POST['current_company']);
       $about = sanitize_text_field($_POST['about']);
       $address = sanitize_text_field($_POST['address']);
       
   
   
       
       // Update user's other meta data
       update_user_meta($currentUserId, 'first_name', $full_name);
       update_user_meta($currentUserId, 'dob', $dob);
       update_user_meta($currentUserId, 'phone_number', $numberWithCode);
       
       update_user_meta($currentUserId, 'user_email', $user_email);
       update_user_meta($currentUserId, 'gender', $gender);
       update_user_meta($currentUserId, 'age', $age);
       update_user_meta($currentUserId, 'current_company', $current_company);
       update_user_meta($currentUserId, 'bio', $about);
       update_user_meta($currentUserId, 'address', $address);
   
   
   
   
   
   if (!empty($_FILES['avatar']['name'])) {
    // Upload image
    if ($_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
       echo "Hellooo";
       $allowed_types = array('image/jpeg', 'image/png', 'image/gif');
       $fileType = $_FILES['avatar']['type'];
   
       if (!in_array($fileType, $allowed_types)) {
          $_SESSION['message'] = "Only PNG,JPG,Jpeg files are allowed.";
          echo "<script type='text/javascript'>window.location.href='". site_url("profile") ."'</script>";
          exit; // Stop execution
       }
       
       $upload_dir = wp_upload_dir();
       $image_path = $upload_dir['path'] . '/' . $_FILES['avatar']['name'];
       move_uploaded_file($_FILES['avatar']['tmp_name'], $image_path);
       // Create attachment
       $attachment = array(
       'post_mime_type' => $_FILES['avatar']['type'],
       'post_title' => sanitize_file_name($_FILES['avatar']['name']),
       'post_content' => '',
       'post_status' => 'inherit'
       );
       $attach_id = wp_insert_attachment($attachment, $image_path);
       // Set featured image
      //  if ($attach_id) {
      //     echo $attach_id;
      //     $avatar_url = wp_get_attachment_url($attach_id);
      //     echo "Avatar URL  :".$avatar_url;
      //     $done = update_user_meta($currentUserId,'profile_image',$avatar_url);
      //  }

      if ($attach_id) {
         echo $attach_id;
         $avatar_url = wp_get_attachment_url($attach_id);
         echo "Avatar URL: " . $avatar_url;
         $done = update_user_meta($currentUserId, 'profile_image', $avatar_url);
     }
     
       
    }
   }
   $_SESSION['message'] = "Profile Updated Successfully!";
   echo "<script type='text/javascript'>window.location.href='". site_url("profile") ."'</script>";
   
   
   }
   
   
   
   
   
   
   ?>