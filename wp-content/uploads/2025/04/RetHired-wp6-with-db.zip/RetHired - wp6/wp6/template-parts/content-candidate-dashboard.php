<?php include(get_template_directory() . '/template-parts/content-dashboard-header.php'); ?>

<?php 
if (is_user_logged_in() && current_user_can('contributor')) {
    $_SESSION['message'] = 'Please log in as candidate';
    $_SESSION['redirect_to']  = $_SERVER['REQUEST_URI'];
    wp_redirect(site_url('login'));
    
}
if (!is_user_logged_in()){
    $_SESSION['message'] = 'Please log in as Candidate';
    $_SESSION['redirect_to']  = $_SERVER['REQUEST_URI'];
    echo "<script>window.location.href='".site_url('login')."'</script>";
    exit;
}
$currentUserId = get_current_user_id(); ?>
<?php
$applied_jobs_count = isset($_SESSION['applied_jobs_count']) ? $_SESSION['applied_jobs_count'] : 0;
$working_status = get_user_meta($currentUserId, 'working_status', true);
?>

<!-- Dashboard start -->
<div class="dashboard">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 p-0">
                <?php get_sidebar(); ?>
            </div>
            <div class="col-lg-9 p-0">
                    <div class="dashboard-content">
                        <div class="dashboard-header clearfix">
                            <div class="row">
                                <div class="col-sm-6 col-12">
                                    <h4>Hello, <?php echo get_user_meta($currentUserId, 'first_name', true); ?></h4>
                                </div>
                                <div class="col-md-6">
                                    <div class="breadcrumb-nav">
                                        <ul>
                                            <li>
                                                <a href="<?php echo home_url('/'); ?>">Home</a>
                                            </li>
                                            <li>
                                                <a href="" class="active">Dashboard</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if(isset($_SESSION['message'])){ ?>
                        <div class="alert alert-success alert-2" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo $_SESSION['message']; ?>
                        </div>
                        <?php }?>
                        <?php unset($_SESSION['message']); ?>
                        <?php if(isset($_SESSION['error-message'])){ ?>
                        <div class="alert alert-danger alert-2" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo $_SESSION['error-message']; ?>
                        </div>
                        <?php }?>
                        <?php unset($_SESSION['error-message']); ?>
                        
                        <div class="row">
                            <div class="col-12 col-sm-6">
                                  <div class="ui-item bg-primary">
                                    <div>
                                        <h4><?php echo isset($_SESSION['applied_job']) ? $_SESSION['applied_job'] : 0;?></h4>
                                        <p>Applied Job</p>
                                    </div>
                                    <div>
                                        <i class="flaticon-work"></i>
                                    </div>
                                </div>
                            </div>
                            <?php if($working_status == 'Released') { ?>
                                <div class="col-12 col-sm-6">
                                    <div class="ui-item bg-success">
                                        <div>
                                            <h4><?php echo $working_status; ?></h4>
                                            <p>Working Status</p>
                                        </div>
                                        <div>
                                            <i class="flaticon-user-1"></i>
                                        </div>
                                    </div>
                                </div>
                            <?php } elseif($working_status == 'Engaged') { ?>
                                <div class="col-12 col-sm-6">
                                    <div class="ui-item bg-danger">
                                        <div>
                                            <h4><?php echo $working_status; ?></h4>
                                            <p>Working Status</p>
                                        </div>
                                        <div>
                                            <i class="flaticon-lock"></i>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="dashboard-list">
                                    <h3>Job Applied Recently</h3>
                                    <div class="dashboard-message dashboard-table-responsive bdr clearfix">
                                        <div class="table-responsive dashboard-table-responsive">
                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>Sr.no</th>
                                                        <th>Title</th>
                                                        <th> Deadline</th>
                                                        <th>Status</th>
                                                        <th>Company </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $args = array('post_type' => 'job-post','posts_per_page' => -1);
                                                    $count = 0;
                                                    $counter = 1;
                                                    $query = new WP_Query($args);
                                                    if ($query->have_posts()) :
                                                        while ($query->have_posts()) : $query->the_post();
                                                            $candidates = get_field('job_applicant');
                                                            //print_r($candidates);
                                                            if ($candidates) {
                                                                foreach ($candidates as $candidate) {
                                                                    if ($candidate['user_id'] == $currentUserId) {
                                                                        $count++;
                                                                        $_SESSION['applied_job'] = $count;
                                                                        ?>
                                                                        <tr>
                                                                            <td><?php echo $counter; ?></td>
                                                                            <td> <a href="<?php echo  get_the_permalink(); ?>"> <?php echo get_the_title(); ?> </a></td>
                                                                            <td><?php echo get_field('application_end_date'); ?></td>
                                                                            <td>
                                                                                <?php
                                                                                $post_ID = get_the_ID();
                                                                                foreach($candidates as $candidate){
                                                                                    $abc = get_user_meta($candidate['user_id'], 'working_status_post_id', true);
                                                                                    if (get_the_ID() == $abc) { ?>
                                                                                        <span class="badge badge-danger"><?php echo $working_status; ?></span>
                                                                                    
                                                                                <?php }else{?>
                                                                                    <span class="badge badge-success"><?php echo "Released"; ?></span>
                                                                                <?php }
                                                                            } ?>
                                                                            </td>
                                                                            <td><?php echo get_user_meta(get_the_author_meta('ID'), 'current_company', true); ?></td>
                                                                        </tr>
                                                                        <?php
                                                                    }
                                                                }
                                                                $counter ++;
                                                            }
                                                            
                                                        endwhile;
                                                        wp_reset_postdata();
                                                    endif;
                                                    if ($count == 0) { ?>
                                                        <tr class="responsive-table">
                                                            <td class="p-left-20">No Records Found!</td>
                                                        </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <?php if ($count == 5) {
                                     ?>
                                    <div class="post-btn float-right">
                                        <button type="submit" name="submit" class="btn btn-md button-theme">
                                            <a class="text-light" href="<?php echo site_url('candidate-applied-job'); ?>">View More</a>
                                        </button>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <?php get_footer('secondary'); ?>
             </div>
        </div>
    </div>
</div>
<!-- Dashboard end -->
<!-- Full Page Search -->
<div id="full-page-search">
    <button type="button" class="close">X</button>
    <form action="index.html#">
        <input type="search" value="" placeholder="type keyword(s) here" />
        <button type="submit" class="btn btn-sm button-theme">Search</button>
    </form>
</div>
