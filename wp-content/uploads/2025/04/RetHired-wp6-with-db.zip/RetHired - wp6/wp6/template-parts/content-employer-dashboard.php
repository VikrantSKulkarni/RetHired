<?php include(get_template_directory() . '/template-parts/content-dashboard-header.php'); 

if (!is_user_logged_in()){
    $_SESSION['message'] = 'Please log in as Employer';
    echo "<script>window.location.href='".site_url('login')."'</script>";
    exit;
}else{
    if(current_user_can('subscriber')){
        $_SESSION['message'] = 'Please log in as Employer';
        echo "<script>window.location.href='".site_url('login')."'</script>";
        exit;
    }
}

?>
<!-- Dashbord start -->
<div class="dashboard">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-12 p-0">
                <?php get_sidebar(); ?>
            </div>
            <?php $firstName = get_user_meta(get_current_user_id(),'first_name',true);?>
            <div class="col-lg-9 col-12 p-0">
                <div class="dashboard-content">
                    <div class="dashboard-header clearfix">
                        <div class="row">
                            <div class="col-md-6"><h4>Hello , <?php if($firstName){ echo $firstName;}else{ echo 'Admin';}?></h4></div>
                            <div class="col-md-6">
                                <div class="breadcrumb-nav">
                                    <ul>
                                        <li>
                                            <a href="<?php echo home_url(); ?>">Home</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo site_url('employer-dashboard'); ?>" class="active">Dashboard</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if(isset($_SESSION['message'])){?>
                    <div class="alert alert-success alert-2" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo $_SESSION['message']; ?>
                    </div>
                    <?php }
                    unset($_SESSION['message']);?>
                    
                    <?php if(isset($_SESSION['error-message'])){?>
                    <div class="alert alert-danger alert-2" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo $_SESSION['error-message']; ?>
                    </div>
                    <?php }
                    unset($_SESSION['error-message']);?>
                        <?php 
                        $total_active_Jobs = 0; // Initialize the variable to count active jobs

                        $args = array(
                            'post_type' => 'job-post',
                            'author' => get_current_user_id(),
                            'posts_per_page' => -1,
                            'meta_query' => array(
                                array(
                                    'key' => 'status', // Custom field key
                                    'value' => 'Active', // Custom field value to filter
                                    'compare' => '=', // Comparison operator: '=' for exact match
                                ),
                            ),
                        );
                        
                        $query = new WP_Query($args);

                        if ($query->have_posts()) :
                            while ($query->have_posts()) : $query->the_post();
                                // Loop through each post
                                $total_active_Jobs++; // Increment the count for each active job
                            endwhile;
                            wp_reset_postdata();
                        endif; ?>
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <div class="ui-item bg-success">
                                <div>
                                    <h4><?php  echo $total_active_Jobs; ?></h4>
                                    <p>Active Jobs</p>
                                </div>
                                <div>
                                    <i class="fa fa-briefcase"></i>
                                </div>
                            </div>
                        </div>
                        <?php 
                        $total_Jobs= 0;
                            $args = array( 'post_type' => 'job-post','author'=>get_current_user_id(),'posts_per_page' => -1);
                            $query  = new WP_Query( $args );
                            if ($query->have_posts()) : 
                            while ($query->have_posts()) : $query->the_post();
                            endwhile; wp_reset_postdata(); 
                            $total_Jobs =  $query->post_count;
                        endif;
                        
                        ?>
                        <div class="col-12 col-sm-6">
                            <div class="ui-item bg-dark">
                                <div>
                                    <h4><?php  echo $total_Jobs;?></h4>
                                    <p>Total Jobs </p>
                                </div>
                                <div>
                                    <i class="fa fa-briefcase"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                        <div class="row">
                        <div class="col-lg-12">
                        <?php 
                            $args = array(
                                'post_type' => 'job-post',
                                'author'=> get_current_user_id()
                            );

                            $query = new WP_Query($args);
                            $has_notifications = false;

                            if ($query->have_posts()) : 
                                while ($query->have_posts()) : $query->the_post();
                                    $candidates = get_field('job_applicant');
                                    if($candidates) {
                                        $has_notifications = true;
                                        break; // Exit the loop as we only need to know if there are any notifications
                                    }
                                endwhile; 
                                wp_reset_postdata();
                            endif;
                            ?>
                            <?php if($has_notifications): ?>
                            <div class="dashboard-list">
                                <h3>
                                    Recent Notification : </h3>
                                <div class="dashboard-message dashboard-table-responsive bdr clearfix " style="max-height:300px;overflow-y:scroll;">
                                    <div class="table-responsive dashboard-table-responsive">
                                        <?php 
                                        $args = array(
                                        'post_type' => 'job-post',
                                        'author'=>get_current_user_id());
                                        

                                        //echo "User Id : ".$_SESSION['userid'];

                                        $query  = new WP_Query( $args );
                                        if ($query->have_posts()) : 
                                            while ($query->have_posts()) : $query->the_post();
                                                $candidates = get_field('job_applicant');
                                                //echo print_r($candidates);
                                                $post_id =  get_the_ID();
                                                $author_id = get_post_field('post_author', $post_id);   
                                                //echo ">".$author_id;
                                                
                                                if($candidates){ 
                                                    $_SESSION['notifications'] = true;
                                                    // echo $candidates;?>
                                                <div class="notification-container">
                                                <?php foreach($candidates as $candidate){ 
                                                if(!(($candidate['working_status'] == 'Engaged') && $candidate['employer_id']==get_current_user_id())){
                                                        ?>
                                                <div class="d-flex justify-content-between mb-2 bg-white">
                                                    <p class="text-secondary"><span class="fa fa-bell text-danger"></span>  <?php echo get_user_meta($candidate['user_id'],'first_name',true); ?> has been applied for  <?php the_title(); ?> job.</p>
                                                    <div class="p-1">
                                                        <a href="<?php echo esc_url( add_query_arg( array(
                                                            'user_id' => $candidate['user_id'],
                                                            'post_id'=>$post_id
                                                            ), site_url('candidate-view-profile') ) ); ?>" class="btn btn-danger btn-sm">
                                                            View Profile
                                                        </a>
                                                    </div>
                                                </div>
                                                <hr>
                                                <?php } ?>              
                                                <?php } ?>
                                                </div>
                                                <?php }
                                            endwhile; wp_reset_postdata(); else:?>
                                            No notifications found !
                                        <?php  endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                        <h3> Recent Jobs : </h3>
                            <div class="dashboard-list">
                                <div class="job-info job-info-2">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Sr.no</th>
                                            <th>Title</th>
                                            <th class="hdn">Due Date</th>
                                            <th>Applications</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        $args = array( 'post_type' => 'job-post','posts_per_page' => 5 ,'author'=> get_current_user_id());
                                        $query  = new WP_Query( $args );
                                        $count = 1;
                                        if ($query->have_posts()) : 
                                            while ($query->have_posts()) : $query->the_post();  ?>
                                                <div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deleteConfirmLabel">Delete Confirmation</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure you want to Delete?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                        <a   data-target="#deleteConfirm"  href="<?php echo add_query_arg( array( 'post_id' => $post->ID,
                                                            'author_id'=>$_SESSION['userid'] ), site_url( 'delete-job' ) );?>" class="btn btn-danger">Delete</a>
                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <tr class="responsive-table">
                                            <td class="p-left-20 pr-0"><?php echo $count; ?></td>
                                            <td class="p-left-2">
                                                <div class="inner">
                                                    <h5><a href="<?php echo get_the_permalink();?>"><?php echo get_the_title();?></a></h5>
                                                    <ul>
                                                        <li><i class="flaticon-pin"></i> <?php echo get_field('location');?></li>
                                                        <li><i class="flaticon-time"></i> <?php echo get_field('job_type');?></li>
                                                    </ul>
                                                </div>
                                            </td>
                                            <td class="hdn"><?php echo get_field('application_end_date');?></td>
                                            <td><?php if(get_field('job_applicant')){ echo "<b>(".count(get_field('job_applicant')) .")</b> Applications"; }else{ echo "<b>(0)</b> Applications"; } ?></td>
                                            <td>
                                            <?php $status = get_field('status');
                                            if($status =='Active'){?>
                                            <span class="badge badge-success"><?php echo $status; ?></span>
                                            <?php }else{?>
                                                <span class="badge badge-danger"><?php echo $status; ?></span>
                                            <?php }?>
                                            </td>
                                            <td class="actions">
                                                <a href="<?php echo add_query_arg( array( 'post_id' => $post->ID,'author_id'=>get_current_user_id() ), site_url( 'edit-a-job' ) ); ?>"><i class="fa fa-pencil"></i></a>
                                                <a href="<?php echo get_delete_post_link($post->ID) ?>"   data-toggle="modal" data-target="#deleteConfirm" ><i class="delete fa fa-trash-o"></i></a>
                                            </td>
                                        </tr>
                                        <?php $count = $count +1;
                                        endwhile; wp_reset_postdata();  else: ?>
                                        <tr class="responsive-table">
                                            <td class="p-left-20">
                                                No Records Found !
                                            </td>
                                        </tr>
                                        
                                        <?php endif; ?>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <td  colspan="6">
                                            <?php if ($query->have_posts()) :
                                                if($query->post_count == 5){?>
                                                    <div class="post-btn d-flex justify-content-end">
                                                        <button type="submit" name="submit" class="btn btn-md button-theme">
                                                            <a class="text-light" href="<?php echo site_url('employer-job-list'); ?>">View More</a>
                                                        </button>
                                                    </div>
                                                <?php }?>
                                            <?php endif;?>
                                            </td>
                                        </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3"></div>
            <div class="col-lg-9">
                <?php get_footer('secondary'); ?>
            </div>
        </div>
    </div>
</div>
<!-- Dashbord end -->
