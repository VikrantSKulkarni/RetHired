<?php session_start(); ?>
<?php 
if (!is_user_logged_in()) {
   $_SESSION['message'] = 'Please log in to continue.';
   $_SESSION['redirect_to']  = $_SERVER['REQUEST_URI'];
   wp_redirect(site_url('login'));  
}
$current_user = wp_get_current_user();
// print_r($current_user->roles[0]);
?>
<!-- Dashbord start -->
<?php include(get_template_directory() . '/template-parts/content-dashboard-header.php'); ?>
<!-- Dashbord start -->
<div class="dashboard dash-margin">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 p-0">
                <?php get_sidebar();?>
            </div>
            <div class="col-lg-9 p-0">
                <div class="dashboard-content">
                    
                    <?php if(isset($_SESSION['message'])){ ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo $_SESSION['message']; ?>
                        </div>
                        <?php unset($_SESSION['message']); ?>
                    <?php } ?>

                    <?php if(isset($_SESSION['error-message'])){ ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $_SESSION['error-message']; ?>
                        </div>
                        <?php unset($_SESSION['error-message']); ?>
                    <?php } ?>

                        <div class="dashboard-header clearfix">
                            <div class="row">
                                <div class="col-md-6"><h4>Change Password</h4></div>
                                <div class="col-md-6">
                                    <div class="breadcrumb-nav">
                                        <ul>
                                            <li>
                                                <a href="<?php echo home_url(); ?>">Index</a>
                                            </li>
                                            <?php if($current_user->roles[0] == 'subsscriber'){?>
                                                <li>
                                                <a href="<?php echo site_url('candidate-dashboard'); ?>">Dashboard</a>
                                                </li>
                                            <?php }else{?>
                                                <li>
                                                <a href="<?php echo site_url('employer-dashboard'); ?>">Dashboard</a>
                                                </li>
                                            <?php }?>
                                            <li class="active">Change Password</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="dashboard-list">
                                    <h3 class="heading">Change Password</h3>
                                    <div class="dashboard-message contact-2">
                                        <form id="passwordForm" action="" method="POST" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="form-group name">
                                                        <label>Current Password</label>
                                                        <div class="d-flex">
                                                            <input style="border-right:none;" type="password" id="currentPass" name="current_password" class="form-control" placeholder="Current Password" required autofocus>
                                                            <button style="border-left:none;border-color:#eee;" class="btn btn-outline-secondary" type="button" id="toggleCurrentPassword">
                                                                <i class="fa fa-eye" id="eye-icon" aria-hidden="true"></i>
                                                            </button>
                                                        </div>
                                                        <script>
                                                            $(document).ready(function() {
                                                                console.log("ready!");

                                                                function togglePasswordVisibility(passwordField, eyeIcon) {
                                                                    if (passwordField.attr('type') === "password") {
                                                                        passwordField.attr('type', "text");
                                                                        eyeIcon.removeClass("fa-eye");
                                                                        eyeIcon.addClass("fa-eye-slash");
                                                                    } else {
                                                                        passwordField.attr('type', "password");
                                                                        eyeIcon.removeClass("fa-eye-slash");
                                                                        eyeIcon.addClass("fa-eye");
                                                                    }
                                                                }

                                                                $("#toggleCurrentPassword").on("click", function() {
                                                                    togglePasswordVisibility($('#currentPass'), $('#eye-icon'));
                                                                });

                                                                $("#toggleNewPassword").on("click", function() {
                                                                    togglePasswordVisibility($('#newPass'), $('#eye-icon2'));
                                                                });

                                                                $("#toggleNewConfirmPassword").on("click", function() {
                                                                    togglePasswordVisibility($('#newConfirmPass'), $('#eye-icon3'));
                                                                });
                                                            });
                                                        </script>
                                                        <script>
                                                            document.addEventListener('DOMContentLoaded', function() {
                                                                const form = document.getElementById('passwordForm');
                                                                const newPassInput = document.getElementById('newPass');
                                                                const confirmPassInput = document.getElementById('newConfirmPass');
                                                                const newPassError = document.getElementById('newPassError');
                                                                const confirmPassError = document.getElementById('confirmPassError');

                                                                // Prevent form submission on Enter key
                                                                form.addEventListener('keydown', function(e) {
                                                                    if (e.key === 'Enter') {
                                                                        e.preventDefault();
                                                                    }
                                                                });

                                                                // Validate password fields on keyup
                                                                newPassInput.addEventListener('keyup', validatePassword);
                                                                confirmPassInput.addEventListener('keyup', validatePassword);

                                                                function validatePassword() {
                                                                    const newPassValue = newPassInput.value;
                                                                    const confirmPassValue = confirmPassInput.value;

                                                                    // Clear previous error messages
                                                                    newPassError.textContent = '';
                                                                    confirmPassError.textContent = '';

                                                                    // You can add more complex validation here if needed
                                                                    if (newPassValue.length < 8) {
                                                                        newPassError.textContent = 'Password must be at least 8 characters long';
                                                                    }

                                                                    if (newPassValue !== confirmPassValue) {
                                                                        confirmPassError.textContent = 'Passwords do not match';
                                                                    }
                                                                }
                                                            });

                                                        </script>

                                                    </div>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="form-group email">
                                                        <label>New Password</label>
                                                        <div class="d-flex">
                                                            <input style="border-right:none;" type="password" id="newPass" name="new_password" class="form-control" placeholder="New Password"  required>
                                                            <button style="border-left:none;border-color:#eee;" class="btn btn-outline-secondary" type="button" id="toggleNewPassword">
                                                                <i class="fa fa-eye" id="eye-icon2" aria-hidden="true"></i>
                                                            </button>
                                                        </div>
                                                        <p id="newPassError" class="text-danger"></p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="form-group subject">
                                                        <label>Confirm New Password</label>
                                                        <div class="d-flex">
                                                            <input style="border-right:none;" type="password" id="newConfirmPass" name="confirm_new_password" class="form-control" placeholder="Confirm New Password"  required>
                                                            <button style="border-left:none;border-color:#eee;" class="btn btn-outline-secondary" type="button" id="toggleNewConfirmPassword">
                                                                <i class="fa fa-eye" id="eye-icon3" aria-hidden="true"></i>
                                                            </button>
                                                        </div>
                                                        <p id="confirmPassError" class="text-danger"></p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="send-btn">
                                                        <button type="submit" name="submit" class="btn btn-md button-theme">Change Password</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php get_footer('secondary'); ?>
            </div>
        </div>
    </div>
</div>
<!-- Dashbord end -->

<!-- Full Page Search -->
<div id="full-page-search">
    <button type="button" class="close">X</button>
    <form action="index.html#">
        <input type="search" value="" placeholder="type keyword(s) here" />
        <button type="submit" class="btn btn-sm button-theme">Search</button>
    </form>
</div>
<?php 
if(isset($_POST['submit'])){
    // Sanitize input fields
    $current_password = sanitize_text_field($_POST['current_password']);
    $new_password = sanitize_text_field($_POST['new_password']);
    $confirm_new_password = sanitize_text_field($_POST['confirm_new_password']);
    
    // Check if user is logged in
    if(is_user_logged_in()) {
        
        $user_id = get_current_user_id();
        
        // Get current user object
        $current_user = get_user_by('ID', $user_id);

        if($current_user) {
            // Get stored password hash
            $stored_password_hash = $current_user->user_pass;

            // Verify current password
            if (wp_check_password($current_password, $stored_password_hash, $user_id)) {
                // Check if new password matches confirm password
                if ($new_password === $confirm_new_password) {
                    // Hash the new password
                    $new_password_hash = wp_hash_password($new_password);

                    // Update user's password
                    wp_set_password($new_password, $user_id);
                    $_SESSION['message'] = "Password updated successfully!";
                } else {
                    $_SESSION['error-message'] = "New password and confirm password do not match.";
                }
            } else {
                $_SESSION['error-message'] = "Current password is incorrect.";
            }
        } else {
            $_SESSION['error-message'] = "User not found.";
        }
    } else {
        $_SESSION['error-message'] = "User not logged in.";
    }

    // Redirect back to the change password page
    echo "<script>window.location.href='" . site_url('login') . "';</script>";
}
?>
