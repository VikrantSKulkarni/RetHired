<?php get_header(); ?>
<style>
    .sub-banner {
      background: rgba(0, 0, 0, 0.04) url(<?php echo get_theme_file_uri("/img/job_list_bg4.png"); ?>) top center repeat;
      background-size:cover;
   }
</style>

<!-- Sub banner start -->
<div class="sub-banner bg-color-full">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>Job Listing</h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <li class="active">Job Listing</li>
            </ul>
        </div>
    </div>
</div>
<?php 
//Change status to In-Active if application deadline exceeds

$args_to_deactivate = array(
    'post_type' => 'job-post',
    'posts_per_page' => -1,
    'meta_key' => 'status',
    'meta_value' => 'Active',
);
$query = new WP_Query($args_to_deactivate);

// List view container
if ($query->have_posts()) :
    while ($query->have_posts()) : $query->the_post();
        $currentDate = date('Y/m/d'); 
        $application_end_date = get_field('application_end_date');

        if($currentDate > $application_end_date){
            update_post_meta( get_the_ID(), 'status', 'In-Active');
        }
        
    endwhile;  
    wp_reset_postdata();
    endif;
     ?>
<!-- Sub banner end -->
<!-- job listing section start -->
<div class="job-listing-section content-area">
    <div class="container">
        <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-12">
                    <div class="sidebar-right">
                        <!-- Advanced search start -->
                        <div class="widget-4 advanced-search">
                            <form method="GET" class="informeson">
                                <div class="form-group">
                                    <?php if(isset($_GET['search'])){?>
                                    <input class="form-control mb-2" type="text" name="search" placeholder="Search Keyword" value="<?php echo esc_attr( $search ); ?>">
                                    <?php } ?>
                                    <label>Location</label>
                                    <select class="form-control" name="location">
                                        <option value=''>-- select location -- </option>
                                        <option value="Pune" <?php if(isset($_GET['location']) && $_GET['location']=='Pune'){ echo "selected";}?>> Pune</option>
                                        <option value="Baner" <?php if(isset($_GET['location']) && $_GET['location']=='Baner'){ echo "selected";}?>> Baner </option>
                                        <option value="Amaravati" <?php if(isset($_GET['location']) && $_GET['location']=='Amaravati'){ echo "selected";}?>> Amaravati</option>
                                        <option value="Baramati" <?php if(isset($_GET['location']) && $_GET['location']=='Baramati'){ echo "selected";}?>> Baramati</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Categories</label>
                                    <select class="form-control" name="job_category">
                                        <?php
                                        $categories = get_terms(array(
                                            'taxonomy'   => 'job_category',
                                            'hide_empty' => false,
                                        )); ?>
                                        <option value="0">-- Select category -- </option>
                                        <?php foreach ($categories as $category) {
                                        ?>
                                            <option value="<?php echo $category->term_id; ?>" <?php if(isset($_GET['job_category']) && $_GET['job_category'] == $category->term_id){ echo "selected";}?>><?php echo $category->name; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Job Type</label>
                                    <select class="form-control" name="job_type">
                                        <option value="">-- select job type-- </option>
                                        <option value="Part Time" <?php if(isset($_GET['job_type']) && $_GET['job_type']=='Part Time'){ echo "selected";}?>> Part Time</option>
                                        <option value="Full Time" <?php if(isset($_GET['job_type']) && $_GET['job_type']=='Full Time'){ echo "selected";}?>> Full Time </option>
                                        <option value="Freelance" <?php if(isset($_GET['job_type']) && $_GET['job_type']=='Freelance'){ echo "selected";}?>> Freelance </option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Experience</label>
                                    <?php $years = [1,2,3,4,5,6,7,8,9,10,11,12,];?>
                                    <select class="form-control" name="experience">
                                        <option value="">-- select experience --</option>
                                        <?php foreach($years as $year){?>
                                        <option value="<?php echo $year;?>" <?php if(isset($_GET['experience']) && $_GET['experience']== $year ){ echo "selected";}?>> 
                                        <?php echo $year." Year(s)";?> </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Qualification </label>
                                    <select class="form-control" name="qualification">
                                        <?php  $qualification = $_GET['qualification']; ?>
                                            <option value="0">-- select qualification --</option>
                                            <option value="Bsc"<?php if($qualification == 'Bsc'){ echo "selected";} ?>>Bsc</option>
                                            <option value="B.A." <?php if($qualification == 'B.A.'){ echo "selected";} ?>>B.A.</option>
                                            <option value="B.Com" <?php if($qualification == 'B.Com'){ echo "selected";} ?>>B.Com</option>
                                            <option value="Bsc(Computer)" <?php if($qualification == 'Bsc(Computer)'){ echo "selected";} ?>>Bsc(Computer)</option>
                                            <option value="BSc(Maths)" <?php if($qualification == 'BSc(Maths)'){ echo "selected";} ?>>BSc(Maths)</option>
                                            <option value="BSc(computer application)" <?php if($qualification == 'BSc(computer application)'){ echo "selected";} ?>>BSc (computer application)</option>
                                            <option value="MSc(computer science)" <?php if($qualification == 'MSc(computer science)'){ echo "selected";} ?>>MSc (computer science)</option>
                                            <option value="MSc" <?php if($qualification == 'MSc'){ echo "selected";} ?>>MSc</option>
                                            <option value="M.E" <?php if($qualification == 'M.E'){ echo "selected";} ?>>M.E</option>
                                            <option value="Any Graduate" <?php if($qualification == 'Any Graduate'){ echo "selected";} ?>>Any Graduate </option> 
                                    </select>
                                </div>
                                
                                <button class="btn btn-primary rounded" type="submit" name="submit">apply</button>
                                <a href="<?php echo site_url('jobs'); ?>" class="btn btn-secondary text-light">reset </a>
                            </form>
                        </div>
                    </div> 
                </div>
            <div class="col-xl-8 col-lg-8 col-md-8">
                <!-- Option bar start -->
                <div class="option-bar d-none d-xl-block d-lg-block d-md-block d-sm-block">
                    <div class="row">
                        <div class="col-lg-6 col-md-7 col-sm-7">
                            <div class="sorting-options2">
                                <span class="sort">Sort by:</span>
                                <?php
                                $cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : null;
                                $current_sort = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : '';

                                $sorting_options = [
                                    'newest' => 'Newest',
                                    'asc' => 'Oldest',
                                    'random' => 'Random'
                                ];
                                ?>
                                <select class="selectpicker search-fields" name="default-order" onchange="location = this.value;">
                                    <?php foreach ($sorting_options as $sort_value => $sort_label) : 
                                        $url_params = ['sort' => $sort_value];
                                        if ($cat_id) {
                                            $url_params['cat_id'] = $cat_id;
                                        }
                                        $sort_url = add_query_arg($url_params, get_permalink());
                                        $selected = ($current_sort === $sort_value) ? 'selected' : '';
                                    ?>
                                        <option value="<?php echo esc_url($sort_url); ?>" <?php echo $selected; ?>><?php echo esc_html($sort_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-5 col-sm-5">
                            <div class="sorting-options">
                                <a href="#" id="listView" class="change-view-btn active-view-btn"><i class="fa fa-th-list"></i></a>
                                <a href="#" id="gridView" class="change-view-btn"><i class="fa fa-th-large"></i></a>
                            </div>
                        </div>
                    </div>
                </div> 
                <script>
                    jQuery(document).ready(function($) {
                        function setView(view) {
                            if (view === 'grid') {
                                $("#gridViewContainer").show();
                                $("#listViewContainer").hide();
                                $("#gridView").addClass("active-view-btn");
                                $("#listView").removeClass("active-view-btn");
                            } else {
                                $("#listViewContainer").show();
                                $("#gridViewContainer").hide();
                                $("#listView").addClass("active-view-btn");
                                $("#gridView").removeClass("active-view-btn");
                            }
                            localStorage.setItem('view', view);
                        }

                        // On page load, check localStorage for view state
                        var view = localStorage.getItem('view') || 'list';
                        setView(view);

                        $("#gridView").on("click", function(e) {
                            e.preventDefault();
                            setView('grid');
                        });

                        $("#listView").on("click", function(e) {
                            e.preventDefault();
                            setView('list');
                        });
                    });
                </script>
                <?php

                $cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : null;
                $sort_order = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : 'desc';
                $order = 'DESC';
                $orderby = 'date';

                if ($sort_order == 'asc') {
                    $order = 'ASC';
                } elseif ($sort_order == 'desc') {
                    $order = 'DESC';
                } elseif ($sort_order == 'random') {
                    $orderby = 'rand';
                }

                $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

                $location = isset($_GET['location']) ? $_GET['location'] : null;
                $job_type = isset($_GET['job_type']) ? $_GET['job_type'] : null;
                $experience = isset($_GET['experience']) ? $_GET['experience'] : null;
                $qualification = isset($_GET['qualification']) ? $_GET['qualification'] : null;
                $job_category = isset($_GET['job_category']) ? $_GET['job_category'] : null;

                
                // Fetch posts for list view
                $args = array(
                    'post_type' => 'job-post',
                    'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                    'posts_per_page' => 6,
                    'meta_key' => 'status',
                    'meta_value' => 'Active',
                    'orderby' => $orderby,
                    'order' => $order,
                    'meta_query' => array()
                );

                if (!empty($location)) {
                    $args['meta_query'][] = array(
                        'key' => 'location',
                        'value' => $location,
                        'compare' => '='
                    );
                }

                if (!empty($job_category)) {
                    $args['tax_query'][] = array(
                        'taxonomy' => 'job_category',
                        'field' => 'term_id',
                        'terms' => $job_category,
                    );
                }

                if (!empty($job_type)) {
                    $args['meta_query'][] = array(
                        'key' => 'job_type',
                        'value' => $job_type,
                        'compare' => '='
                    );
                }
                if (!empty($experience)) {
                    $args['meta_query'][] = array(
                        'key' => 'experience_required',
                        'value' => $experience,
                        'compare' => '='
                    );
                }

                if (!empty($qualification)) {
                    $args['meta_query'][] = array(
                        'key' => 'qualification',
                        'value' => $qualification,
                        'compare' => '='
                    );
                }

                if ($cat_id) {
                    $args['tax_query'] = array(
                        array(
                            'taxonomy' => 'job_category',
                            'field'    => 'term_id',
                            'terms'    => $cat_id,
                        )
                    );
                }

                $query = new WP_Query($args);

                // List view container
                if ($query->have_posts()) :
                    echo '<div id="listViewContainer">';
                    while ($query->have_posts()) : $query->the_post(); ?>
                        <div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deleteConfirmLabel">Delete Confirmation</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        Are you sure you want to delete?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <a href="<?php echo add_query_arg(array('post_id' => $post->ID, 'author_id' => $_SESSION['userid']), site_url('delete-job')); ?>" class="btn btn-danger">Delete</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- job box start -->
                        <div class="job-box">
                        <div class="company-logo">
                            <img src="<?php 
                                if (has_post_thumbnail()) {
                                    echo get_the_post_thumbnail_url(get_the_ID(), 'medium');
                                } else {
                                    echo 'https://via.placeholder.com/300x300?text=No+Image';
                                }
                            ?>" alt="logo">
                        </div>
                            <div class="description">
                                <div class="float-left">
                                    <h5 class="title"><a href="<?php the_permalink(); ?>"><?php 
                                    $title = get_the_title(); echo wp_trim_words($title, 7, '...' ); ?></a>
                                    <?php $endDate = get_field('application_end_date');
                                    $currentDate = date('Y/m/d');
                                    //echo "Current Date : ".$currentDate."<br>";
                                    //echo "End Date : ".$endDate."<br>";
                                    if($currentDate > $endDate){ ?>
                                    <div class="badge badge-secondary">Closed </div>
                                    <?php } ?></h5>
                                    <div class="candidate-listing-footer">
                                        <ul>
                                            <?php $author_id = get_post_field('post_author', get_the_ID()); ?>
                                            <li><i class="flaticon-work"></i>  <?php echo get_user_meta($author_id,'current_company',true); ?></li>
                                            <li><i class="flaticon-pin"></i> <?php echo get_field('location'); ?></li>
                                            <li><i class="flaticon-time"></i> <?php echo get_field('job_type'); ?></li>
                                        </ul>
                                        <?php
                                          $application_end_date = get_field('application_end_date');
                                          $date = date("F j, Y", strtotime($application_end_date));
                                        ?>
                                        <h6 class="mt-2">Deadline: <?php echo $date; ?></h6>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <a href="<?php echo get_the_permalink(); ?>" class="apply-button">View</a>
                                    <?php
                                    $author_id = get_post_field('post_author', get_the_ID());
                                    if (is_user_logged_in() and $author_id == get_current_user_id()) { ?>
                                        <a class="text-success apply-button border-radius-0 ml-3" href="<?php echo add_query_arg(array('post_id' => $post->ID, 'author_id' => $_SESSION['userid']), site_url('edit-a-job')); ?>"><i class="fa fa-pencil"></i></a>
                                        <a class="text-danger apply-button ml-3" data-toggle="modal" data-target="#deleteConfirm" href="#"><i class="fa fa-trash"></i></a>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile;  
                    echo '</div>';
                    wp_reset_postdata();
                endif;
                ?>
                
                <?php

                // Fetch posts for grid view
                $query2 = new WP_Query($args);
                if ($query2->have_posts()) :
                    echo '<div class="row" id="gridViewContainer">';
                    while ($query2->have_posts()) : $query2->the_post(); ?>
                    <div class="col-md-6">
                        <div class="card job-grid-card mb-2">
                            <div class="img-wrap">
                            <img  class="card-img-top" src="<?php 
                              if (has_post_thumbnail()) {
                                 echo get_the_post_thumbnail_url(get_the_ID(), 'medium');
                              } else {
                                 echo 'https://via.placeholder.com/400x200?text=No+Image';
                                }
                            ?>" alt="logo">
                                <!-- <img  src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>" class="card-img-top" alt="Job Post"> -->
                            </div>
                            <div class="card-body">
                                <h5 class="card-title text-truncate"><a href="<?php echo get_the_permalink(); ?>"><?php
                                $title = get_the_title();
                                echo wp_trim_words($title, 5, '...' ); ?></a></h5>
                                <div class="candidate-listing-footer">
                                    <ul>
                                        <?php $author_id = get_post_field('post_author', get_the_ID()); ?>
                                        <li><i class="flaticon-work"></i>  <?php echo get_user_meta($author_id,'current_company',true); ?></li>
                                        <li><i class="flaticon-pin"></i> <?php echo get_field('location'); ?></li>
                                        <li><i class="flaticon-time"></i> <?php echo get_field('job_type'); ?></li>
                                    </ul>
                                    <?php 
                                        $application_end_date = get_field('application_end_date');
                                        $date = date("F j, Y", strtotime($application_end_date));  ?>
                                    <h6 class="mt-2">Deadline: <?php echo $date; ?></h6>
                                </div>
                                <div class="text-center mt-4">
                                    <a href="<?php echo get_the_permalink(); ?>" class="btn btn-secondary text-dark pl-5 pr-5" style="background:none;border-radius:50px;">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile;
                    echo '</div>';
                    wp_reset_postdata();
                endif;
                ?>
                
                <?php
                    $total_post_count = $query->post_count;
                    if ($total_post_count == 6) {
                        $total_pages = $query->max_num_pages;
                        $current_page = max(1, get_query_var('paged'));

                        // Capture the current filter parameters
                        $location = isset($_GET['location']) ? sanitize_text_field($_GET['location']) : '';
                        $job_type = isset($_GET['job_type']) ? sanitize_text_field($_GET['job_type']) : '';
                        $experience = isset($_GET['experience']) ? sanitize_text_field($_GET['experience']) : '';
                        $qualification = isset($_GET['qualification']) ? sanitize_text_field($_GET['qualification']) : '';
                        $job_category = isset($_GET['job_category']) ? intval($_GET['job_category']) : '';
                        $sort_order = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : '';
                        $cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : '';

                        echo '<div class="pagination-box hidden-mb-45 text-center">';
                        echo '<nav aria-label="Page navigation example">';
                        echo '<ul class="pagination">';

                        // Previous page link
                        if ($current_page > 1) {
                            $prev_page_url = add_query_arg(array(
                                'paged' => $current_page - 1,
                                'location' => $location,
                                'job_type' => $job_type,
                                'experience' => $experience,
                                'qualification' => $qualification,
                                'job_category' => $job_category,
                                'sort' => $sort_order,
                                'cat_id' => $cat_id,
                            ), get_permalink());
                            echo '<li class="page-item"><a class="page-link" href="' . esc_url($prev_page_url) . '">Previous</a></li>';
                        }

                        // Pagination links
                        for ($i = 1; $i <= $total_pages; $i++) {
                            $active_class = ($i == $current_page) ? 'active' : '';
                            $page_url = add_query_arg(array(
                                'paged' => $i,
                                'location' => $location,
                                'job_type' => $job_type,
                                'experience' => $experience,
                                'qualification' => $qualification,
                                'job_category' => $job_category,
                                'sort' => $sort_order,
                                'cat_id' => $cat_id,
                            ), get_permalink());
                            echo '<li class="page-item ' . $active_class . '"><a class="page-link" href="' . esc_url($page_url) . '">' . $i . '</a></li>';
                        }

                        // Next page link
                        if ($current_page < $total_pages) {
                            $next_page_url = add_query_arg(array(
                                'paged' => $current_page + 1,
                                'location' => $location,
                                'job_type' => $job_type,
                                'experience' => $experience,
                                'qualification' => $qualification,
                                'job_category' => $job_category,
                                'sort' => $sort_order,
                                'cat_id' => $cat_id,
                            ), get_permalink());
                            echo '<li class="page-item"><a class="page-link" href="' . esc_url($next_page_url) . '">Next</a></li>';
                        }

                        echo '</ul>';
                        echo '</nav>';
                        echo '</div>';
                    }
                ?>

            </div>
        </div>
    </div>
</div>
<!-- job listing section end -->
<?php get_footer(); ?>