<?php
get_header(); // Include header template
?>
<style>
    .sub-banner{
        background: rgba(0, 0, 0, 0.04) url('<?php if($banner_image){ echo $banner_image; }else{ echo get_theme_file_uri("/img/job_list_bg4.png"); }?>') top center repeat;
    }
</style>

<!-- Sub banner start -->
<div class="sub-banner bg-color-full">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>Blogs </h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <li class="active">blogs </li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub banner end -->

<!-- Blog body start -->
<div class="blog-body content-area">
    <div class="container">
        <div class="row">
        <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                
                $args = array(
                'post_type'=> 'post',
                'orderby'    => 'ID',
                'post_status' => 'publish',
                'order'    => 'DESC',
                'posts_per_page' => 6, // this will retrive all the post that is published 
                'paged'          => $paged
                );
                $result = new WP_Query( $args );
                if ( $result-> have_posts() ) : 
                    while ( $result->have_posts() ) : $result->the_post();
            ?>
              <?php $date = get_the_date();
                    $date = implode(' ',explode(',',$date));
                    $expl_date = explode(' ',$date);
                ?>
            <div class="col-lg-4 col-md-6">
                <div class="blog-1">
                    <div class="blog-photo">
                        <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'medium'); ?>" alt="small-blog" class="img-fluid">
                        <div class="date-box">
                            <span><?php echo $expl_date[1]; ?></span><?php echo $expl_date[0]; ?>
                        </div>
                    </div>
                    <div class="detail">
                        <h3 class="text-truncate">
                            <a href="<?php the_permalink(); ?>"><?php
                            $title = get_the_title();

                            echo wp_trim_words( $title, 3, '...' ); ?></a>
                        </h3>
                        <div class="post-meta">
                            <span><a href="#"><i class="flaticon-male"></i><?php the_author(); ?></a></span>
                            <span><a href="#"><i class="flaticon-comment"></i><?php echo get_comments_number(); ?></a></span>
                            <!-- <span><a href="#"><i class="fa fa-heart-o"></i>27</a></span> -->
                        </div>
                        <p style="height:90px;overflow-y:hidden;"><?php echo get_the_excerpt(); ?></p>
                        <a href="<?php the_permalink(); ?>" class="read-more">Read more</a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
            <?php  wp_reset_postdata(); endif; ?>
        </div>

        <?php 
        $total_pages = $result->max_num_pages;
        if($total_pages >1){
            echo '<div class="pagination-box hidden-mb-45 text-center">';
            echo '<nav aria-label="Page navigation example">';
            echo '<ul class="pagination">';
                $total_post_count = $result->post_count; 
               //echo "helllo ".$total_post_count;
               $total_pages = $result->max_num_pages;
               //echo $total_pages;
               $current_page = max(1, get_query_var('paged'));
               if ($current_page > 1) {
                $prev_page_url = add_query_arg(array(
                    'paged' => $current_page - 1,
                ),get_permalink());
                echo '<li class="page-item"><a class="page-link" href="' . esc_url($prev_page_url) . '">Previous</a></li>';
            }
            for ($i = 1; $i <= $total_pages; $i++) {
                $active_class = ($i == $current_page) ? 'active' : '';
                $page_url = add_query_arg(array(
                'paged' => $i,), get_permalink());
                echo '<li class="page-item ' . $active_class . '"><a class="page-link" href="' . esc_url($page_url) . '">' . $i . '</a></li>';
            }
            if ($current_page < $total_pages) {
                $next_page_url = add_query_arg(array(
                'paged' => $current_page + 1,get_permalink()),);
                echo '<li class="page-item"><a class="page-link" href="' . esc_url($next_page_url) . '">Next</a></li>';
                }
            echo '</ul>';
            echo '</nav>';
            echo '</div>';
        } ?>
    </div>
</div>
<!-- Blog body end -->
<?php
//get_sidebar(); // Include sidebar template
get_footer(); // Include footer template
?>
