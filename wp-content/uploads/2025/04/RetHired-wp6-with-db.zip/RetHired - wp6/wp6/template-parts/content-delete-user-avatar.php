<?php 
$user_id = $_GET['user_id'];
if($user_id){

    $image_url = get_user_meta($user_id,'profile_image',true);
    //echo $image_url;
    $attachment_id = attachment_url_to_postid($image_url);
    //echo $attachment_id;
    if ($attachment_id) {
        if (wp_attachment_is_image($attachment_id)) {
            // Delete the attachment
            
            $deleted = wp_delete_attachment($attachment_id, true);
         
            if($deleted){
                delete_user_meta($user_id, 'profile_image');
                //echo "Deleted ";
                $_SESSION['message'] = "User avatar deleted !";
                echo "<script>window.location.href='".site_url('profile')."';</script>";
            }else{
                //echo "Not Deleted";
                $_SESSION['error-message'] = "Error in deleting avatar !";
                echo "<script>window.location.href='".site_url('profile')."';</script>";
            }
        }
    }else{
        echo "Not Found";
    }
}
?>