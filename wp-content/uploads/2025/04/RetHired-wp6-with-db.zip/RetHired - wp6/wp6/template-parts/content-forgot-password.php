<?php get_header(); ?>
<?php if (!is_page('login')){?>
    <script>
        document.getElementById("header").style.display='none';
    </script>    
<?php }?>
<!-- <?php 
   if(!(isset($_SESSION['userid']))){ ?>
<script>
   document.getElementById("header").style.display='none';
</script>
<?php }else{ ?>
   <script> window.history.back(); </script>
<?php }
   ?> -->
<!-- <div class="page_loader"></div> -->
<!-- Contact section start -->
<div class="contact-section">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <!-- Form content box start -->
            <div class="form-content-box">
               <?php if(isset($_SESSION['message'])){?>
               <div class="alert alert-success alert-2" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <?php echo $_SESSION['message']; ?>
               </div>
               <?php }
                  unset($_SESSION['message']);?>
               <?php if(isset($_SESSION['error-message'])){?>
               <div class="alert alert-danger alert-2" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <?php echo $_SESSION['error-message']; ?>
               </div>
               <?php }
                  unset($_SESSION['error-message']);?>
               <!-- details -->
               <div class="details">
                  <!-- Logo -->
                  <a href="<?php echo home_url();?>">
                     <?php 
                        if(has_custom_logo()){
                        the_custom_logo();
                        }
                        ?>
                     <!-- <img src="<?php echo get_theme_file_uri("/img/logos/black-logo.png"); ?>" alt=""> -->
                  </a>
                  <!-- Name -->
                  <h3> Forgot Password </h3>
                  <?php
                     if (isset($_GET['password_reset']) && $_GET['password_reset'] == 'true') {
                        echo '<div class="alert alert-success">Email has been sent.</div>';
                     }
                     if (isset($_GET['password_reset_error'])) {
                        $error_message = urldecode($_GET['password_reset_error']);
                        echo '<div class="alert alert-danger">' . esc_html($error_message) . '</div>';
                     }
                     ?>

                     <form class="form-group" data-parsley-validate="" action="<?php echo esc_url(home_url('/lost-password')); ?>" method="post" name="lostpasswordform" id="lostpasswordform">
                        <div class="pb-2">
                           <div class="fl-input mb-4 text-left"> 
                                 <label >Email address</label>
                                 <div class="fl-input__field">
                                    <input class="form-control" type="email" placeholder="Enter your email" name="user_login" id="user_login" data-parsley-error-message="Invalid" required>
                                    <input type="hidden" name="redirect_to" value="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" />
                                 </div>
                           </div>
                        </div>
                        <div class="text-center mb-3">
                           <button class="btn btn-primary forgot btn--primary w-100" type="submit" name="wp-submit" id="wp-submit">Send a link on mail</button>
                        </div>
                     </form>


               </div>
            </div>
            <!-- Form content box end -->
         </div>
      </div>
   </div>
</div>
<!-- Contact section end -->
<!-- Full Page Search -->
<div id="full-page-search">
   <button type="button" class="close">X</button>
   <form action="index.html#">
      <input type="search" value="" placeholder="type keyword(s) here" />
      <button type="submit" class="btn btn-sm button-theme">Search</button>
   </form>
</div>
<script src="js/jquery-2.2.0.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script  src="js/bootstrap-submenu.js"></script>
<script  src="js/rangeslider.js"></script>
<script  src="js/jquery.mb.YTPlayer.js"></script>
<script  src="js/bootstrap-select.min.js"></script>
<script  src="js/jquery.easing.1.3.js"></script>
<script  src="js/jquery.scrollUp.js"></script>
<script  src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script  src="js/leaflet.js"></script>
<script  src="js/leaflet-providers.js"></script>
<script  src="js/leaflet.markercluster.js"></script>
<script  src="js/moment.min.js"></script>
<script  src="js/daterangepicker.min.js"></script>
<script  src="js/dropzone.js"></script>
<script  src="js/slick.min.js"></script>
<script  src="js/jquery.filterizr.js"></script>
<script  src="js/jquery.magnific-popup.min.js"></script>
<script  src="js/jquery.countdown.js"></script>
<script  src="js/maps.js"></script>
<script  src="js/app.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script  src="js/ie10-viewport-bug-workaround.js"></script>
<!-- Custom javascript -->
<script  src="js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>
<?php if(isset($_POST['submit'])){

}?>