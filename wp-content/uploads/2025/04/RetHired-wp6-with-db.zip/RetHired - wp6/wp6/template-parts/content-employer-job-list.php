<?php include(get_template_directory() . '/template-parts/content-dashboard-header.php'); 
if (!is_user_logged_in()){
    $_SESSION['message'] = 'Please log in as Employer';
    $_SESSION['redirect_to'] = get_permalink();
    echo "<script>window.location.href='".site_url('login')."'</script>";
    exit;
}else{
    if(current_user_can('subscriber')){
        $_SESSION['message'] = 'Please log in as Employer';
        echo "<script>window.location.href='".site_url('login')."'</script>";
        exit;
    }
}?>
<!-- Dashboard start -->
<div class="dashboard dash-margin">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-12 p-0">
               <?php get_sidebar();?>
            </div>
            <div class="col-lg-9 col-12 p-0">
                    <div class="dashboard-content">
                        <div class="dashboard-header clearfix">
                            <div class="row">
                                <div class="col-12 col-md-6"><h4>Manage Jobs</h4></div>
                                <div class="col-12 col-md-6">
                                    <div class="breadcrumb-nav">
                                        <ul>
                                            <li>
                                                <a href="<?php echo home_url();?>">Home</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo site_url('employer-dashboard');?>">Dashboard</a>
                                            </li>
                                            <li class="active">Manage Jobs</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if(isset($_SESSION['message'])){?>
                        <div class="alert alert-success alert-2" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo $_SESSION['message']; ?>
                        </div>
                        <?php }
                        unset($_SESSION['message']);?>
                        <?php if(isset($_SESSION['error-message'])){?>
                        <div class="alert alert-danger alert-2" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo $_SESSION['error-message']; ?>
                        </div>
                        <?php }
                        unset($_SESSION['error-message']);?>
                        <div class="dashboard-list">
                            <div class="job-info job-info-2">
                                <table class="table" id="job_list">
                                    <thead>
                                    <tr>
                                        <th>Sr.no</th>
                                        <th>Title</th>
                                        <th class="hdn">Due Date</th>
                                        <th>Applications</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $args = array( 'post_type' => 'job-post','posts_per_page' => -1 ,'author'=>get_current_user_id());
                                    $query  = new WP_Query( $args );
                                    $count = 1;
                                    if ($query->have_posts()) : 
                                        while ($query->have_posts()) : $query->the_post();  ?>
                                             <!-- Main header end -->
                                            <div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deleteConfirmLabel">Delete Confirmation</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure you want to Delete?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                        <a href="<?php echo add_query_arg( array( 'post_id' => $post->ID,
                                                            'author_id'=>get_current_user_id() ), site_url( 'delete-job' ) );?>" class="btn btn-danger">Delete</a>
                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                    <tr class="responsive-table">
                                        <td class="p-left-20 pr-0"><?php echo $count; ?></td>
                                        <td class="p-left-20">
                                            <div class="inner">
                                                <h5><a href="<?php echo get_the_permalink();?>"><?php echo get_the_title();?></a></h5>
                                                <ul>
                                                    <li><i class="flaticon-pin"></i> <?php echo get_field('location');?></li>
                                                    <li><i class="flaticon-time"></i> <?php echo get_field('job_type');?></li>
                                                </ul>
                                            </div>
                                        </td>
                                        <td class="hdn"><?php echo get_field('application_end_date');?></td>
                                        <td><?php if(get_field('job_applicant')){ echo "<b>(".count(get_field('job_applicant')) .")</b> Applications"; }else{ echo "<b>(0)</b> Applications"; } ?></td>
                                        <td>
                                        <?php $status = get_field('status');
                                        if($status =='Active'){?>
                                        <span class="badge badge-success"><?php echo $status; ?></span>
                                        <?php }else{?>
                                            <span class="badge badge-danger"><?php echo $status; ?></span>
                                        <?php }?>
                                        </td>
                                        <td class="actions">
                                            <a href="<?php echo add_query_arg( array( 'post_id' => $post->ID,'author_id'=>get_current_user_id() ), site_url( 'edit-a-job' ) ); ?>"><i class="fa fa-pencil"></i></a>
                                            <a data-toggle="modal" data-target="#deleteConfirm" href="<?php echo add_query_arg( array( 'post_id' => $post->ID,'author_id'=>get_current_user_id()  ), 
                                            site_url( 'delete-job' ) );?>">
                                            <i class="delete fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                $count = $count +1;
                                endwhile; wp_reset_postdata(); endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php get_footer('secondary'); ?>
            </div>
            
        </div>
    </div>
</div>

<!-- Dashboard end -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/2.0.7/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/2.0.7/js/dataTables.bootstrap4.js"></script>
<style>
      <?php if($count < 10){?>
    .paging_full_numbers,.dt-info{
      
        display:none !important;
        
    }
    <?php }?>
</style>
<script>
    $(document).ready(function() {
        $('#job_list').DataTable({
            searching: false, // Hide the search bar
            lengthChange: false, // Hide the entries per page dropdown
            pageLength: 10// Set the default entries per page to 10
        });
    });
</script>