<style>
    .sub-banner{
        background: rgba(0, 0, 0, 0.04) url(<?php echo get_theme_file_uri("/img/job_list_bg3.png"); ?>) top left repeat;
    }
</style>
<?php get_header(); ?>
<!-- Sub banner start -->
<div class="sub-banner bg-color-full">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>Contact us</h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <li class="active">Contact us</li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub banner end -->

<!-- Contact 2 start -->
<div class="contact-2 content-area-5">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Contact Us</h1>
            <p>We're here to help with any questions or support you need.</p>
        </div>
        <!-- Contact info -->
        <div class="contact-info">
            <div class="row justify-content-center">
                <div class="col-md-3 col-8 col-sm-6 mb-50">
                    <a href="#location">                        
                        <i class="flaticon-pin"></i>
                        <p>Office Address</p>
                        <strong>404, V18, Balewadi High Street, Baner</strong>
                        <strong>Pune, Maharashtra</strong>
                        <strong>India - 411045</strong>
                    </a>
                </div>
                <div class="col-md-3 col-8 col-sm-6 mb-50">
                    <a href="tel:+91 88 0506 0506">
                        <i class="flaticon-phone"></i>
                        <p>Phone Number</p>
                        <strong>+91 88 0506 0506</strong> 
                    </a>
                </div>
                <div class="col-md-3 col-8 col-sm-6 mb-50">
                    <a  target="__blank" href="mailto:info@pixel6.co">
                        <i class="flaticon-mail"></i>
                        <p>Email Address</p>
                        <strong>  info@pixel6.co</strong>
                    </a>
                </div>
                <div class="col-md-3 col-8 col-sm-6 mb-50">
                    <a href="https://pixel6.co/" target="__blank">
                        <i class="flaticon-internet"></i>
                        <p>Web</p>
                        <strong> https://pixel6.co/ </strong>
                    </a>
                </div>
            </div>
        </div>
            <div class="row">
                <div class="col-lg-8">
                    <?php echo do_shortcode('[contact-form-7 id="2ab903c" title="Contact form 1"]');?>
                </div>
                <div class="col-lg-4">
                    <div class="opening-hours bg-light">
                        <h3>Opening Hours</h3>
                        <ul class="list-style-none">
                            <li><strong>Sunday</strong> <span class="text-danger"> closed</span></li>
                            <li><strong>Monday</strong> <span> 9 AM - 6 PM</span></li>
                            <li><strong>Tuesday </strong> <span> 9 AM - 6 PM</span></li>
                            <li><strong>Wednesday </strong> <span> 9 AM - 6 PM</span></li>
                            <li><strong>Thursday </strong> <span> 9 AM - 6 PM</span></li>
                            <li><strong>Friday </strong> <span> 9 AM - 6 PM</span></li>
                            <li><strong>Saturday </strong><span class="text-danger"> closed</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
</div>
<!-- Contact 2 end -->
<!-- Google map start -->
<div class="section" id="location">
    <div class="map text-center">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3782.0842850275485!2d73.77308217413325!3d18.570238482533036!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2b939c980f80f%3A0x10bfa44ac46e6781!2sPixel6%20Web%20Studio%20Pvt.%20Ltd.!5e0!3m2!1sen!2sin!4v1718624555405!5m2!1sen!2sin" width=80% height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</div>
<!-- Google map end -->
<?php get_footer(); ?>