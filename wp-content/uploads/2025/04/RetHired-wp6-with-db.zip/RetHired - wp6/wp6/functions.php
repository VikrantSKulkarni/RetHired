<?php
// In functions.php
function start_session() {
  if (!session_id()) {
      session_start();
  }
}
add_action('init', 'start_session', 1);

function handle_login_form() {
  if (isset($_POST['login'])) {
      $email = $_POST['email'];
      $password = $_POST['password_login'];

      if (!empty($email) && !empty($password)) {
          $user = get_user_by('email', $email) ?: get_user_by('login', $email);

          if ($user && wp_check_password($password, $user->user_pass, $user->ID)) {
              $user_status = get_user_meta($user->ID, 'user_status', true);
              if($user_status == '10'){
                $_SESSION['message'] = "Please verify your email before login !";
                wp_redirect(site_url('login'));
                exit;
              }
              wp_set_current_user($user->ID);
              wp_set_auth_cookie($user->ID);

              $_SESSION['message'] = "Login Successfully!";
            //   $_SESSION['userid'] = $user->ID;
            //   $_SESSION['username'] = $user->user_login;
            //   $_SESSION['useremail'] = $user->user_email;
            //   $_SESSION['usermobile'] = get_user_meta($user->ID, 'phone_number', true);
            //   $_SESSION['userrole'] = $user->roles[0];

              //echo $redirect_to; die();
              //unset($_SESSION['redirect_to']);
              if($_SESSION['redirect_to']){
                $redirect_to = $_SESSION['redirect_to'];
                unset($_SESSION['redirect_to']);
              }else{
                if (in_array('administrator', $user->roles)) {
                  $redirect_to = admin_url(); 
                } elseif (in_array('subscriber', $user->roles)) {
                    $redirect_to = site_url('candidate-dashboard');
                } elseif (in_array('contributor', $user->roles)) {
                    $redirect_to = site_url('employer-dashboard');
                } else {
                    $redirect_to = site_url();
                }
              }
              wp_redirect($redirect_to);
              exit;
          } else {
              $_SESSION['error_message'] = 'Invalid email or password!';
              wp_redirect(site_url('login'));
              exit;
          }
      } else {
          $_SESSION['error_message'] = 'Empty email or password!';
          wp_redirect(site_url('login'));
          exit;
      }
  }
}
add_action('init', 'handle_login_form');


function load_stylesheets(){
    wp_register_style('custom', get_template_directory_uri().'/css/bootstrap.min.css');
    wp_enqueue_style('custom'); 

    wp_register_style('animate', get_template_directory_uri().'/css/animate.min.css');
    wp_enqueue_style('custom'); 

    wp_register_style('bootstrap-submenu', get_template_directory_uri().'/css/bootstrap-submenu.css');
    wp_enqueue_style('animate'); 

    wp_register_style('bootstrap-select', get_template_directory_uri().'/css/bootstrap-select.min.css');
    wp_enqueue_style('bootstrap-select'); 

  wp_register_style('magnific-popup', get_template_directory_uri().'/css/magnific-popup.css');
  wp_enqueue_style('magnific-popup'); 

  wp_register_style('daterangepicker', get_template_directory_uri().'/css/daterangepicker.css');
  wp_enqueue_style('daterangepicker'); 

  wp_register_style('jquery.mScrollbar', get_template_directory_uri().'/css/jquery.mCustomScrollbar.css');
  wp_enqueue_style('jquery.mScrollbar'); 

  wp_register_style('dropzone', get_template_directory_uri().'/css/dropzone.css');
  wp_enqueue_style('dropzone'); 

  wp_register_style('slick', get_template_directory_uri().'/css/slick.css');
  wp_enqueue_style('slick'); 

  wp_register_style('style', get_template_directory_uri().'/css/style.css');
  wp_enqueue_style('style'); 

  wp_register_style('midnight-blue', get_template_directory_uri().'/css/skins/midnight-blue.css');
  wp_enqueue_style('midnight-blue'); 

  wp_register_style('ie10-viewport', get_template_directory_uri().'/css/ie10-viewport-bug-workaround.css');
  wp_enqueue_style('ie10-viewport'); 

  wp_register_style('leaflet', get_template_directory_uri().'/css/leaflet.css');
  wp_enqueue_style('leaflet'); 

  wp_register_style('map', get_template_directory_uri().'/css/map.css');
  wp_enqueue_style('map'); 

  wp_register_style('font-awesome', get_template_directory_uri().'/fonts/font-awesome/css/font-awesome.min.css');
  wp_enqueue_style('font-awesome'); 


  wp_register_style('flaticon', get_template_directory_uri().'/fonts/flaticon/font/flaticon.css');
  wp_enqueue_style('flaticon'); 

  wp_register_style('linearicons', get_template_directory_uri().'/fonts/linearicons/style.css');
  wp_enqueue_style('linearicons'); 
}
add_action('wp_enqueue_scripts','load_stylesheets');

function include_custom_js(){
 wp_enqueue_script('popper', get_template_directory_uri() .'/js/popper.min.js');
  wp_enqueue_script('bootstrap', get_template_directory_uri() .'/js/bootstrap.min.js');
  wp_enqueue_script('bootstrap-submenu', get_template_directory_uri() .'/js/bootstrap-submenu.js');
  wp_enqueue_script('rangeslider', get_template_directory_uri() .'/js/rangeslider.js');
  wp_enqueue_script('jquery-mb-YTPlayer', get_template_directory_uri() .'/js/jquery.mb.YTPlayer.js');
  wp_enqueue_script('bootstrap-select', get_template_directory_uri() .'/js/bootstrap-select.min.js');
  wp_enqueue_script('jquery.easing', get_template_directory_uri() .'/js/jquery.easing.1.3.js');
  wp_enqueue_script('jquery.scrollUp', get_template_directory_uri() .'/js/jquery.scrollUp.js');
  wp_enqueue_script('jquery.mCustomScrollbar', get_template_directory_uri() .'/js/jquery.mCustomScrollbar.concat.min.js');
  wp_enqueue_script('leaflet', get_template_directory_uri() .'/js/leaflet.js');
  wp_enqueue_script('leaflet-providers', get_template_directory_uri() .'/js/leaflet-providers.js');
  wp_enqueue_script('leaflet.markercluster', get_template_directory_uri() .'/js/leaflet.markercluster.js');
 wp_enqueue_script('moment', get_template_directory_uri() .'/js/moment.min.js');
  wp_enqueue_script('daterangepicker', get_template_directory_uri() .'/js/daterangepicker.min.js');
  wp_enqueue_script('dropzone', get_template_directory_uri() .'/js/dropzone.js');
  wp_enqueue_script('slick', get_template_directory_uri() .'/js/slick.min.js');
  wp_enqueue_script('jquery.filterizr', get_template_directory_uri() .'/js/jquery.filterizr.js');
  wp_enqueue_script('jquery.magnific-popup', get_template_directory_uri() .'/js/jquery.magnific-popup.min.js');
  wp_enqueue_script('jquery.countdown', get_template_directory_uri() .'/js/jquery.countdown.js');
  wp_enqueue_script('maps', get_template_directory_uri() .'/js/maps.js');
  wp_enqueue_script('app', get_template_directory_uri() .'/js/app.js');
  wp_enqueue_script('ie10-viewport-bug-workaround', get_template_directory_uri() .'/js/ie10-viewport-bug-workaround.js');
  wp_enqueue_script('ie10-viewport-bug-workaround-2', get_template_directory_uri() .'/js/ie10-viewport-bug-workaround.js');
  wp_enqueue_script('custom-script', get_template_directory_uri() .'/js/custom.js');

}
add_action('wp_enqueue_scripts','include_custom_js');
?>



<?php
function remove_footer_on_specific_pages() {
  if (is_page(array('candidate-dashboard'))) { // Replace with your page slugs or IDs
      remove_action('wp_footer', 'your_theme_footer_function'); // Replace 'your_theme_footer_function' with the actual function name if necessary
  }
}
add_action('wp', 'remove_footer_on_specific_pages');

add_theme_support( 'custom-logo', array(
  'width'       => 150,  // Set your desired width
  'flex-width'  => true, // Allow the logo width to be flexible
  'flex-height' => true, // Allow the logo height to be flexible
) );

add_theme_support( 'post-thumbnails' );
add_theme_support( 'menus' );

register_nav_menus(
    array(
        'top-menu' =>__('Top Menu','theme'),
        'side-menu' =>__('Side Menu','theme'),
    )      
  );

// Function to modify the excerpt length
//function custom_excerpt_length( $length ) {
  //return 11; // Change 20 to the number of words you want to limit the excerpt to
//}
//add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );
?>

<?php 
function custom_lost_password() {
  if (isset($_POST['user_login']) && !empty($_POST['user_login'])) {
      $user_login = sanitize_text_field($_POST['user_login']);
      $user = get_user_by('email', $user_login);
      
      if ($user) {
          $errors = retrieve_password();
          if (!is_wp_error($errors)) {
              // Redirect to the same page with success parameter
              $redirect_to = add_query_arg('password_reset', 'true', esc_url($_POST['redirect_to']));
              wp_redirect($redirect_to);
              exit();
          } else {
              // Handle errors from retrieve_password()
              $redirect_to = add_query_arg('password_reset_error', urlencode($errors->get_error_message()), esc_url($_POST['redirect_to']));
              wp_redirect($redirect_to);
              exit();
          }
      } else {
          // User not found error
          $redirect_to = add_query_arg('password_reset_error', 'User not found', esc_url($_POST['redirect_to']));
          wp_redirect($redirect_to);
          exit();
      }
  }
}
add_action('init', 'custom_lost_password');
?>
<?php
function custom_comment_form( $args ) {
    // Customize form fields here if needed
    $args['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . _x( 'Comment', 'noun' ) . '</label> <textarea class="form-control" id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>';
    
    // Add a custom class to the form
    $args['class_form'] = 'custom-comment-form form-group';
    
    //Customize other fields like author, email, etc., if needed
    $args['fields'] = apply_filters( 'comment_form_default_fields', array(
        'author' => '<p class="comment-form-author">' . '<label for="author">' . __( 'Name' ) . '</label> ' . ( $req ? '<span class="required">*</span>' : '' ) .
            '<input class="form-control" id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>',
        'email'  => '<p class="comment-form-email"><label for="email">' . __( 'Email' ) . '</label> ' . ( $req ? '<span class="required">*</span>' : '' ) .
            '<input  class="form-control" id="email" name="email" type="text" value="' . esc_attr( $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>',
        'url'    => '<p class="comment-form-url"><label for="url">' . __( 'Website' ) . '</label>' .
            '<input class="form-control" id="url" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>',
            
    ) );
    // Customize the submit button
    $args['submit_button'] = '<input name="%1$s" type="submit" id="%2$s" class="btn btn-primary" value="%4$s" />';
    

    return $args;
}

add_filter( 'comment_form_defaults', 'custom_comment_form' );



function custom_user_avatar($avatar, $id_or_email, $size, $default, $alt) {
  // Get the user ID
  if (is_numeric($id_or_email)) {
      $user_id = $id_or_email;
  } elseif (is_object($id_or_email)) {
      $user_id = $id_or_email->user_id;
  } else {
      $user = get_user_by('email', $id_or_email);
      $user_id = $user->ID;
  }

  // Get the custom profile image URL
  $custom_avatar = get_user_meta($user_id, 'profile_image', true);

  if ($custom_avatar) {
      // Return the custom avatar image tag
      $avatar = '<img src="' . esc_url($custom_avatar) . '" alt="' . esc_attr($alt) . '" width="' . $size . '" height="' . $size . '" class="avatar avatar-' . $size . ' photo" />';
  }

  return $avatar;
}
add_filter('get_avatar', 'custom_user_avatar', 10, 5);

// restrict admin user to add job-applicants 

function hide_acf_add_row_button_for_admin() {
  if (current_user_can('administrator')) {
      ?>
      <style>
          .acf-repeater .acf-actions a[data-event="add-row"] {
              display: none !important;
          }
      </style>
      <?php
  }
}
//add_action('acf/input/admin_head', 'hide_acf_add_row_button_for_admin');

?>