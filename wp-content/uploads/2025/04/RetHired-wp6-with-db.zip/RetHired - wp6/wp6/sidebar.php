<?php $currentUser = wp_get_current_user();
    $user_role = $currentUser->roles[0];
?>
<div class="dashboard-nav d-none d-xl-block d-lg-block">
    <div class="dashboard-content">
        <h4>Main</h4>
        <ul>
            <?php if($user_role=='contributor'){ ?>
                <li><a href="<?php echo site_url('employer-dashboard'); ?>"><i class="flaticon-dashboard"></i>Dashboard</a></li>
                <li ><a href="<?php echo site_url('create-a-job'); ?>"><i class="flaticon-plus"></i>Post a New Job</a></li>
                <li><a href="<?php echo site_url('employer-job-list'); ?>"><i class="flaticon-work"></i>Manage Jobs</a></li>
                <!-- <li><a href="employer-dashboard-change-password.html"><i class="flaticon-lock"></i>Change Password</a></li> -->
            
            <?php }elseif($user_role=='subscriber'){?>
            
            <li class="active"><a href="<?php echo site_url('/candidate-dashboard') ?>"><i class="flaticon-dashboard"></i>Dashboard</a></li>
            <li><a href="<?php echo site_url('/candidate-resume');?>"><i class="flaticon-portfolio"></i>Add Resume</a></li>
            <!-- <li><a href="employer-dashboard-change-password.html"><i class="flaticon-lock"></i>Change Password</a></li> -->
            <?php }elseif($user_role=='administrator'){?>
                <li><a href="<?php echo site_url('employer-dashboard'); ?>"><i class="flaticon-dashboard"></i>Dashboard</a></li>
                <li><a href="<?php echo site_url('/candidate-resume');?>"><i class="flaticon-portfolio"></i>Add Resume</a></li>
                <li ><a href="<?php echo site_url('create-a-job'); ?>"><i class="flaticon-plus"></i>Post a New Job</a></li>
                <li><a href="<?php echo site_url('employer-job-list'); ?>"><i class="flaticon-work"></i>Manage Jobs</a></li>
            <?php }?>
        </ul>
        <h4>Account</h4>
        <?php if(is_user_logged_in()){?>
        <ul>
            <!-- user links dashboard -->
            <li><a href="<?php echo site_url('/profile'); ?>"><i class="flaticon-user"></i>Edit Profile</a></li>
            <li><a href="<?php echo site_url('/change-password'); ?>"><i class="flaticon-lock"></i>Change Password</a></li>
            <li><a href="#" onclick="modalDisplay();"><i class="flaticon-logout"></i>Logout</a></li>
        </ul>
        <?php } ?>
    </div>
</div>
 <div class="modal fade logout-modal" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="logoutModalLabel">Logout Confirmation</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            Are you sure you want to logout?
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            <a href="<?php echo site_url('/logout'); ?>" class="btn btn-primary">Logout</a>
        </div>
        </div>
    </div>
</div>


      
