<style>
    .tag-container{
        padding:100px;
    }
    .tag-container h1{
        font-size:70px;
    }
    .tag-container p{
        font-size:16px;
    }
    .nav-item a{
        color:black !important;
    }
    .dropdown a{
        color:black !important;
    }
</style>
<?php get_header(); ?>
<div class="tag-container">


<div class="row">
    <div class="col-md-8">
        <?php
        $tag = $wp_query->queried_object;
        ?>
        <h1><?php echo $tag->name; ?></h1>
        <?php if (!empty($tag->description)) { ?>
            <p><?php echo $tag->description; ?></p>
        <?php } ?>
    </div>
</div>
</div>

<?php get_footer(); ?>

