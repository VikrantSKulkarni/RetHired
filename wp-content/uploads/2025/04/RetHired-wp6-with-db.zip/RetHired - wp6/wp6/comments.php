<?php
// If the current post is protected by a password and the visitor has not yet entered the password, return early without loading the comments.
if ( post_password_required() ) {
    return;
}
?>

<!-- Comments start -->
<?php if ( have_comments() ) : ?>
    <ul id="comments" class="comments">
        <?php wp_list_comments( array(
            'style'       => 'ul',
            'short_ping'  => true,
            'avatar_size' => 60,
            'callback'    => 'custom_comment_template' // Custom callback function to display comments
        ) ); ?>
    </ul>
<?php endif; ?>

<!-- Comment form -->
<?php if ( comments_open() ) : ?>
    <div id="respond">
        <?php comment_form(); ?>
    </div>
<?php endif; ?>

<?php
// Custom callback function to display comments
function custom_comment_template( $comment, $args, $depth ) {
    ?>
    <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
        <div id="div-comment-<?php comment_ID(); ?>" class="comment-body">
            <div class="comment-author vcard">
                <?php echo get_avatar( $comment, 60 ); ?>
            </div>
            <div class="comment-content">
                <div class="comment-meta">
                    <h3><?php echo get_comment_author_link(); ?></h3>
                    <div class="comment-metadata">
                        <a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
                            <?php printf( __( '%1$s at %2$s' ), get_comment_date(),  get_comment_time() ); ?>
                        </a>
                        <?php edit_comment_link( __( '(Edit)' ), '  ', '' ); ?>
                    </div>
                </div>
                <p><?php comment_text(); ?></p>
                <?php
                comment_reply_link( array_merge( $args, array(
                    'depth'     => $depth,
                    'max_depth' => $args['max_depth'],
                    'before'    => '<div class="reply">',
                    'after'     => '</div>',
                ) ) );
                ?>
            </div>
        </div>
    <?php
}
?>

<?php
// Enqueue the comment-reply script
if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
    wp_enqueue_script( 'comment-reply' );
}
?>
