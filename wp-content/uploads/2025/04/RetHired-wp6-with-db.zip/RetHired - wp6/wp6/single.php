<?php
get_header(); // Include header template
?>
<style>
    .sub-banner{
        background: rgba(0, 0, 0, 0.04) url('<?php if($banner_image){ echo $banner_image; }else{ echo get_theme_file_uri("/img/job_list_bg4.png"); }?>') top center repeat;
    }
</style>
<!-- Sub banner start -->
<div class="sub-banner bg-color-full">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>Blog Details</h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <li class="active">Blog Details</li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub banner end -->

<!-- Blog body start -->
<div class="blog-body content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <!-- Blog 1 start -->
                <div class="blog-1 blog-big">
                    <div class="blog-photo">
                        <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'large'); ?>" alt="blog" class="img-fluid">
                    </div>
                    <div class="detail">
                        <h3 class="text-truncate">
                            <a href="#"><?php echo get_the_title(); ?></a>
                        </h3>
                        <p><?php echo the_content(); ?></p>
                        <br>
                        <div class="row clearfix">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="blog-tags">
                                <?php 
                                $tags = get_tags(array(
                                'hide_empty' => false
                                )); ?>
                                    <span>Tags</span>
                                    <?php foreach ($tags as $tag) { ?>
                                        <a href="<?php echo get_tag_link($tag->term_id); ?>"><?php echo $tag->name ?></a>
                                    <?php }?>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="social-list-2">
                                    <span>Share</span>
                                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo home_url()?>/<?php echo implode('-',explode(' ',get_the_title()));?>" class="facebook-bg">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                    <a href="#" class="twitter-bg">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                    <a href="https://www.google.com/share?url=<?php echo home_url()?>/<?php echo implode('-',explode(' ',get_the_title()));?>" class="google-bg">
                                        <i class="fa fa-google"></i>
                                    </a>
                                    <a href="https://www.linkedin.com/shareArticle?url=<?php echo home_url()?>/<?php echo implode('-',explode(' ',get_the_title()));?>" class="linkedin-bg">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                    <a href="#" class="pinterest-bg">
                                        <i class="fa fa-pinterest"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Heading 2 -->
                <h3 class="heading-2">Comments Section</h3>
                <!-- Comments start -->
               <?php  // If comments are open or we have at least one comment, load up the comment template.
                if ( comments_open() || get_comments_number() ) {
                    comments_template();
                } ?>
                <!-- <ul class="comments">
                    <li>
                        <div class="comment">
                            <div class="comment-author">
                                <a href="#">
                                    <img src="http://placehold.it/60x60" alt="comments-user">
                                </a>
                            </div>
                            <div class="comment-content">
                                <div class="comment-meta">
                                    <h3>
                                        Maikel Alisa
                                    </h3>
                                    <div class="comment-meta">
                                        8:42 PM 11/28/2018<a href="#">Reply</a>
                                    </div>
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus tincidunt aliquam. Aliquam gravida massa at sem vulputate interdum et vel eros. Maecenas eros enim, tincidunt vel turpis vel, dapibus tempus nulla.</p>
                            </div>
                        </div>
                        <ul>
                            <li>
                                <div class="comment">
                                    <div class="comment-author">
                                        <a href="#">
                                            <img src="http://placehold.it/60x60" alt="comments-user">
                                        </a>
                                    </div>
                                    <div class="comment-content">
                                        <div class="comment-meta">
                                            <h3>
                                                Karen Paran
                                            </h3>
                                            <div class="comment-meta">
                                                8:42 PM 11/28/2018<a href="#">Reply</a>
                                            </div>
                                        </div>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus tincidunt aliquam. Aliquam gravida massa .</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <div class="comment">
                            <div class="comment-author">
                                <a href="#">
                                    <img src="http://placehold.it/60x60" alt="comments-user">
                                </a>
                            </div>
                            <div class="comment-content">
                                <div class="comment-meta">
                                    <h3>
                                        Anne Brady
                                    </h3>
                                    <div class="comment-meta">
                                        8:42 PM 11/28/2018<a href="#">Reply</a>
                                    </div>
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus tincidunt aliquam. Aliquam gravida massa at sem vulputate interdum et vel eros. Maecenas eros enim, tincidunt vel turpis vel, dapibus tempus nulla.</p>
                            </div>
                        </div>
                        <ul>
                            <li>
                                <div class="comment">
                                    <div class="comment-author">
                                        <a href="#">
                                            <img src="http://placehold.it/60x60" alt="comments-user">
                                        </a>
                                    </div>
                                    <div class="comment-content mrg-bdr">
                                        <div class="comment-meta">
                                            <h3>
                                                Jane Doe
                                            </h3>
                                            <div class="comment-meta">
                                                8:42 PM 11/28/2018<a href="#">Reply</a>
                                            </div>
                                        </div>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus tincidunt aliquam. Aliquam gravida massa at sem</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul> -->
                <!-- Contact 2 start -->
                <!-- <div class="contact-2 mb-30">
                    <h3 class="heading-2">Contact Form</h3>
                    <form action="#" method="GET" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group name">
                                    <input type="text" name="name" class="form-control" placeholder="Name">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group email">
                                    <input type="email" name="email" class="form-control" placeholder="Email">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group subject">
                                    <input type="text" name="subject" class="form-control" placeholder="Subject">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group number">
                                    <input type="text" name="phone" class="form-control" placeholder="Number">
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group message">
                                    <textarea class="form-control" name="message" placeholder="Write message"></textarea>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                <div class="send-btn">
                                    <button type="submit" class="btn btn-md button-theme">Send Message</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div> -->
            </div>
            <div class="col-lg-4 col-md-12">
                <div class="sidebar-right-2">
                    <!-- Search box -->
                    <div class="widget search-box">
                        <h3 class="sidebar-title">Search</h3>
                        <div class="s-border"></div>
                        <form class="form-inline form-search" method="GET">
                            <div class="form-group">
                                <label class="sr-only" for="textsearch2">Search Keywords</label>
                                <input type="text" class="form-control" id="textsearch2" placeholder="Search Keywords">
                            </div>
                            <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                        </form>
                    </div>
                    <!-- Recent listing start -->
                    <div class="widget recent-listing">
                        <h3 class="sidebar-title">Recent Post</h3>
                        <div class="s-border"></div>
                        <?php 
                        $args = array(
                            'post_type'=> 'post',
                            'orderby'    => 'ID',
                            'post_status' => 'publish',
                            'order'    => 'DESC',
                            'posts_per_page' => 4, // this will retrive all the post that is published 
                            );
                            $result = new WP_Query( $args );
                            if ( $result-> have_posts() ) : 
                                while ( $result->have_posts() ) : $result->the_post();?>
                            <div class="media mb-4">
                                <a class="pr-3" href="#">
                                    <img class="media-object" src="<?php echo get_the_post_thumbnail_url(get_the_ID());?>" alt="recent-listing">
                                </a>
                                <div class="media-body align-self-center">
                                    <h5>
                                        <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                                    </h5>
                                    <div class="listing-post-meta">
                                        <a href="#"><i class="fa fa-calendar"></i> <?php echo get_the_date(); ?> </a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                        <?php  wp_reset_postdata(); endif; ?>
                    </div>
                    <!-- Category 2 Start -->
                    <div class="category-2 widget">
                        <h3 class="sidebar-title">Category</h3>
                        <div class="s-border"></div>
                        <?php $categories = get_categories();
                                foreach($categories as $category) {
                                    $post_count = $category->count;?>
                        <ul class="list-unstyled list-cat">
                            <li><a href="<?php echo esc_url( add_query_arg( 'cat_id', $category->term_id, site_url('jobs') ) ); ?>"><?php echo $category->name;?> <span>(<?php echo $post_count;?>)</span></a></li>
                        </ul>
                        <?php }?>
                    </div>
                    <!-- Tags box Start -->
                    <div class="widget-5 tags-box">
                        <h3 class="sidebar-title">Tags</h3>
                        <div class="s-border"></div>
                        <?php $tags = get_tags(array(
                            'hide_empty' => false
                            )); ?>
                        <ul class="tags">
                        <?php foreach ($tags as $tag) { ?>
                            <li><a href="<?php echo get_tag_link($tag->term_id); ?>"><?php echo $tag->name ?></a></li>
                        <?php }?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
//get_sidebar(); // Include sidebar template
get_footer(); // Include footer template
?>
