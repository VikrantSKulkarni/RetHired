<?php get_header(); ?>
<?php
    $author_id = get_post_field( 'post_author', get_the_ID() ); // Get the author ID of the current job post
    $author_info = get_userdata( $author_id );
    $banner_image = get_field('job_post_banner');
     ?>
<style>
    .sub-banner{
        background: rgba(0, 0, 0, 0.04) url('<?php if($banner_image){ echo $banner_image; }else{ echo get_theme_file_uri("/img/job_list_bg4.png"); }?>') top center repeat;
    }
</style>
<!-- Sub banner start -->
<div class="sub-banner bg-color-full">
    <div class="container">
        <div class="breadcrumb-area">
            <h1><?php echo get_the_title();?></h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <li class="active"><?php echo get_the_title();?></li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub banner end -->
<div class="container mt-2 mb-2">
    <?php if(isset($_SESSION['message'])){?>
    <div class="alert alert-success alert-2 text-capitalize" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo $_SESSION['message']; ?>
    </div>
    <?php }
    unset($_SESSION['message']);?>

    <?php if(isset($_SESSION['errorMessage'])){?>
    <div class="alert alert-danger alert-2 text-capitalize" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo $_SESSION['errorMessage']; ?>
    </div>
    <?php }
    unset($_SESSION['errorMessage']);?>
</div>

<!-- Job details page start -->
<div class="job-details-page content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <!-- job box 2 start -->
                <!-- <div class="job-box-2">
                    <div class="company-logo">
                        <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'medium'); ?>" alt="avatar">
                    </div>
                    <div class="description">
                        <h5 class="title"><a href="#"><?php echo the_title(); ?></a></h5>
                        <div class="candidate-listing-footer">
                            <ul>
                                <li><i class="flaticon-work"></i>UX Designer</li> 
                                <li><i class="flaticon-pin"></i> <?php echo get_field('location');?></li>
                                <li><i class="flaticon-time"></i>  <?php echo get_field('job_type');?></li>
                            </ul>
                        </div>
                    </div>
                </div> -->
                <!-- job description start -->
                <div class="job-description mb-40">
                    <h3 class="heading-2">Job Description</h3>
                    <?php
                    if(get_the_content()){
                        echo the_content();
                    }else{
                        echo "No data found !";
                    }
                    ?>
                </div>
                <!-- Education + experience start-->
                <div class="education-experience amenities mb-40">
                    <h3 class="heading-2">Education + Experience</h3>
                    <?php $qualification = get_field('qualification');
                          $experience = get_field('experience_required');
                    ?>
                    <ul>
                        <li>
                            <i class="fa fa-check"></i><?php if($qualification){echo $qualification;}else{echo "N.A.";}?>
                        </li>
                        <li><i class="fa fa-check"></i><?php if($experience){echo $experience." Years";}else{echo "N.A.";}?></li>
                        <!-- <li>
                            <i class="fa fa-check"></i>Excellent communication skills, most notably a demonstrated ability to solicit and address creative and design feedback
                        </li>
                        <li>
                            <i class="fa fa-check"></i>Masters of library science any Green University.
                        </li>
                        <li><i class="fa fa-check"></i>BA/BS degree in a technical field or equivalent practical experience.</li>
                        <li>
                            <i class="fa fa-check"></i>Ability to work independently and to carry out assignments to completion within parameters of instructions given, prescribed routines, and standard accepted practices
                        </li> -->
                    </ul>
                </div>
                <div class="location mb-50">
                    <div class="map">
                        <h3 class="heading-2">Location</h3>
                        <iframe
                            width="100%"
                            height="450"
                            style="border:0"
                            loading="lazy"
                            allowfullscreen
                            src="https://www.google.com/maps?q=<?php echo urlencode(get_field('location')); ?>&output=embed">
                        </iframe>

                    </div>
                </div>
                <?php if (is_user_logged_in() && (current_user_can('contributor') or current_user_can('administrator') )){
                $jobApplicants = get_field('job_applicant');
                if($jobApplicants){
                
                ?>
                <div class="education-experience amenities mb-40">
                    <h3 class="heading-2">Job Applicants : </h3>
                        <div class="dashboard-list">
                            <div class="job-info job-info-2 job-applicant">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Name </th>
                                        <th>Email </th>
                                        <th>Action </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        foreach($jobApplicants as $jobApplicant){
                                            if($jobApplicant['employer_id'] == get_current_user_id()){?>
                                    <tr class="responsive-table">
                                        <td class="pl-5"><?php echo $jobApplicant['name']; ?></td>
                                        <td><?php echo $jobApplicant['email']; ?></td>
                                        <td><a href="<?php echo esc_url(add_query_arg(array('user_id' => $jobApplicant['user_id'], 'post_id' => get_the_ID()), site_url('candidate-view-profile'))); ?>" class="btn btn-primary">View</a></td>
                                    </tr>
                                    <?php }else { ?>
                                        <tr class="responsive-table">
                                            <td class="pl-5" colspan="4">No application found !</td>
                                        </tr>
                                    <?php }?>
                                    <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                </div>
                <?php }?>
                <?php }?>
                <div class="clearfix"></div>
            </div>
                 <!-- Main header end -->
            <div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteConfirmLabel">Delete Confirmation</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to Delete?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <a href="<?php echo add_query_arg( array( 'post_id' => $post->ID,
                            'author_id'=>get_current_user_id() ), site_url( 'delete-job' ) );?>" class="btn btn-danger">Delete</a>
                    </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12">
                <?php if($author_id == get_current_user_id()){?>
                    <a class="btn btn-success mb-2" 
                    href="<?php echo add_query_arg( array( 'post_id' => $post->ID,'author_id'=>get_current_user_id() ), 
                    site_url( 'edit-a-job' ) ); ?>"> Edit 
                    </a>
                    <a class="btn btn-danger  mb-2"  data-toggle="modal" data-target="#deleteConfirm" href="<?php echo add_query_arg( array( 'post_id' => $post->ID,
                    'author_id'=>get_current_user_id() ), site_url( 'delete-job' ) );?>"> Delete </a>
                <?php }?>
                <div class="sidebar-right-2">
                    <!-- Search box start -->
                    <div class="widget search-box">
                            <div class="form-group mb-0">
                            <?php $endDate = get_field('application_end_date');
                                  $currentDate = date('Y/m/d');
                                  $currentUser = wp_get_current_user();
                                  //echo print_r($currentUser);
                                   ?>
                                <?php if(is_user_logged_in() && current_user_can('subscriber')){
                                             $candidates = get_field('job_applicant');
                                             if($candidates){
                                                $user_applied = false;
                                                $current_user_id = $currentUser->ID; 
                                                foreach ($candidates as $candidate) {
                                                    if ($current_user_id == $candidate['user_id']) {
                                                    $user_applied = true;
                                                    break; // Stop looping once we find a match
                                                 }
                                                 }
                                                 if ($user_applied) { ?>
                                                 <a href="#" class="btn btn-apply btn-lg  w-100 btn-danger ">Applied <i class="next flaticon-right-arrow"></i></a>
                                                <?php }else{
                                                     ?>
                                                     <?php  if(($currentDate > $endDate) || (get_field('status')=='In-Active')){ ?>
                                                        <div class="form-group mb-0">
                                                            <button class="btn btn-secondary w-100 btn-lg">
                                                            <a  href="#"  class="text-light"> closed </a>
                                                            </button>
                                                        </div>
                                                     <?php }else{?>
                                                    <div class="form-group mb-0">
                                                        <button class="search-button button-theme">
                                                        <a  href="<?php echo esc_url( add_query_arg(   array(
                                                            'userId' => $currentUser->ID,
                                                            'postId' => get_the_ID(),
                                                            ), site_url('apply-for-job') ) ); ?>" data-toggle="modal" data-target="#termsAlert" class="text-light">Apply Now </a>
                                                        </button>
                                                    </div>
                                                    <?php }?>
                                                <?php } 
                                             }else{ ?>
                                             <?php  if($currentDate > $endDate){ ?>
                                                        <div class="form-group mb-0">
                                                            <button class="btn btn-secondary w-100 btn-lg">
                                                            <a  href="#"  class="text-light"> closed </a>
                                                            </button>
                                                        </div>
                                                     <?php }else{?>
                                             <div class="form-group mb-0">
                                                <button class="search-button button-theme">
                                                <a  data-toggle="modal" data-target="#termsAlert" href="<?php echo esc_url( add_query_arg(   array(
                                                    'userId' => $currentUser->ID,
                                                    'postId' => get_the_ID(),
                                                    ), site_url('apply-for-job') ) ); ?>" class="text-light">Apply Now </a>
                                                </button>
                                            </div>
                                            <?php }?>
                                        <?php }
                                        }else{  //echo "User Role : " .$_SESSION['userrole']; ?>
                                            <?php if($currentDate > $endDate || (get_field('status')=='In-Active')){?>
                                               <div class="form-group mb-0">
                                                    <button class="btn btn-secondary w-100 btn-lg">
                                                    <a  href="#"  class="text-light"> closed </a>
                                                    </button>
                                                </div>
                                            <?php }else{?>
                                                <div class="form-group mb-0">
                                                    <button class="search-button button-theme">
                                                    <a  data-toggle="modal" data-target="#termsAlert" href="<?php echo esc_url( add_query_arg(   array(
                                                        'userId' => $currentUser->ID,
                                                        'postId' => get_the_ID(),
                                                        ), site_url('apply-for-job') ) ); ?>" class="text-light">Apply Now </a>
                                                    </button>
                                                </div>
                                            <?php }?>
                                        <?php }?>
                            </div>
                    </div>
                    <!-- Job overview start -->
                    <div class="job-overview widget">
                        <h3 class="sidebar-title">Job Overview</h3>
                        <div class="s-border"></div>
                        <?php $monthly_payment  = get_field('monthly_payment');
                              $location = get_field('location');
                              $job_type = get_field('job_type');
                              $qualification = get_field('qualification');
                              $experience_required = get_field('experience_required');
                              $post_id = get_the_ID();

                                $categories = wp_get_post_terms($post_id, 'job_category');

                                if (!is_wp_error($categories) && !empty($categories)) {
                                    $category_name = $categories[0]->name;
                                    //echo $category_name;
                                }
                        ?>
                        <ul>
                            <li><i class="flaticon-work"></i><h5>Category </h5><span><?php if($category_name){echo $category_name;}else{echo "N.A";}?></span></li>
                            <li><i class="flaticon-money"></i><h5>Salary </h5><span><?php if($monthly_payment){echo $monthly_payment."/month";}else{echo "N.A";}?></span></li>
                            <li><i class="flaticon-pin"></i><h5>Location</h5><span><?php if($location){echo $location;}else{echo "N.A";}?></span></li>
                            <li><i class="flaticon-work"></i><h5>Job Type</h5><span><?php if($job_type){echo $job_type;}else{echo "N.A";}?></span></li>
                            <li><i class="flaticon-honor"></i><h5>Qualification</h5><span><?php if($qualification){echo $qualification;}else{echo "N.A";}?></span></li>
                            <li><i class="flaticon-notepad"></i><h5>Experience</h5><span><?php if($experience_required){echo $experience_required." Year(s)";}else{echo "N.A";}?></span></li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                    <div class="job-overview widget">
                        <h3 class="sidebar-title">Employer Details</h3>
                        <div class="s-border"></div>
                        <?php 
                            $name = get_user_meta($author_info->ID,'first_name',true);
                            $email = $author_info->user_email;
                            $phone = get_user_meta($author_info->ID,'phone_number',true);
                            $company = get_user_meta($author_info->ID,'current_company',true);
                        ?>
                        <ul>
                            <li><i class="flaticon-user"></i><h5>Name </h5><span><?php if($name){ echo $name; }else{ echo "N.A";} ?></span></li>
                            <li><i class="flaticon-work"></i><h5>Company </h5><span><?php if($company){ echo $company; }else{ echo "N.A";} ?></span></li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                    <!-- Quick contact start -->
                    <!-- <div class="widget-5 contact-2 quick-contact">
                        <h3 class="sidebar-title">Employer Details </h3>
                        <div class="s-border"></div>
                        <!-- <form action="#" method="GET" enctype="multipart/form-data">
                            <div class="form-group name">
                                <input type="text" name="name" class="form-control" placeholder="Name">
                            </div>
                            <div class="form-group email">
                                <input type="email" name="email" class="form-control" placeholder="Email">
                            </div>
                            <div class="form-group message">
                                <textarea class="form-control" name="message" placeholder="Write message"></textarea>
                            </div>
                            <div class="send-btn">
                                <button type="submit" class="btn btn-md button-theme">Send Message</button>
                            </div>
                        </form> 
                    </div> -->
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                 <!-- Related jobs start -->
                 <div class="related-Jobs clearfix">
                    <h3 class="heading-2">Related Jobs</h3>
                    <?php $category_ids = wp_get_post_terms(get_the_ID(), 'job_category'); 
                          $cat_id = !empty($category_ids) ? $category_ids[0]->term_id : null;
                          
                          // Fetch posts for list view
                        $args = array(
                            'post_type' => 'job-post',
                            'posts_per_page' => 3,
                            'meta_key' => 'status',
                            'meta_value' => 'Active',
                            'meta_query' => array(),
                            'post__not_in' => array(get_the_ID()) 
                        );
                        if ($cat_id) {
                            $args['tax_query'] = array(
                                array(
                                    'taxonomy' => 'job_category',
                                    'field'    => 'term_id',
                                    'terms'    => $cat_id,
                                )
                            );
                        }
                        $query = new WP_Query($args);
                        // List view container
                        if ($query->have_posts()) :
                            while ($query->have_posts()) : $query->the_post();
                        ?>
                            <div class="job-box">
                                <div class="company-logo">
                                    <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>" alt="logo">
                                </div>
                                <div class="description">
                                    <div class="float-left">
                                        <h5 class="title"><a href="<?php the_permalink(); ?>"><?php
                                         $title = get_the_title(); echo wp_trim_words($title, 7, '...' );  ?></a></h5>
                                        <div class="candidate-listing-footer">
                                            <ul>
                                                <?php $author_id = get_post_field('post_author', get_the_ID());
                                                      $application_end_date = get_field('application_end_date');
                                                      $date = date("F j, Y", strtotime($application_end_date));     
                                                ?>
                                                <li><i class="flaticon-work"></i>  <?php echo get_user_meta($author_id,'current_company',true); ?></li>
                                                <li><i class="flaticon-pin"></i> <?php echo get_field('location'); ?></li>
                                                <li><i class="flaticon-time"></i> <?php echo get_field('job_type'); ?></li>
                                            </ul>
                                            <h6>Deadline: <?php echo $date; ?></h6>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-end">
                                        <a href="<?php echo get_the_permalink(); ?>" class="apply-button">View</a>
                                        <?php
                                        $author_id = get_post_field('post_author', get_the_ID());
                                        $author_info = get_userdata($author_id);
                                        if (is_user_logged_in() and $author_id == get_current_user_id()) { ?>
                                            <a class="text-success apply-button border-radius-0 ml-3" href="<?php echo add_query_arg(array('post_id' => $post->ID, 'author_id' => get_current_user_id()), site_url('edit-a-job')); ?>"><i class="fa fa-pencil"></i></a>
                                            <a class="text-danger apply-button ml-3" data-toggle="modal" data-target="#deleteConfirm" href="#"><i class="fa fa-trash"></i></a>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile;
                            wp_reset_postdata(); else: ?>
                                <div class="job-box">
                                    <h2>Not found!</h2>
                                </div>
                        <?php endif;
                        ?> 
                </div>

            </div>
        </div>
    </div>
</div>
<!-- Job details page end -->
<?php get_footer(); ?>
<div class="modal fade" id="termsAlert" tabindex="-1" role="dialog" aria-labelledby="termsAlertLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="termsAlertLabel">Accepts terms & conditions </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <b> Terms & Conditions  </b> <br>
            <ol>
                <li> Term 1 </li>
                <li> Term 2 </li>
                <li> Term 3 </li>
                <li> Term 4 </li>
            </ol>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            <a href="<?php echo esc_url( add_query_arg(   array(
                    'userId' => $currentUser->ID,
                    'postId' => get_the_ID(),
                    ), site_url('apply-for-job') ) ); ?>" class="btn btn-warning">Accept</a>
        </div>
        </div>
    </div>
</div>