<style>
    .sub-banner{
        background: rgba(0, 0, 0, 0.04) url(<?php echo get_theme_file_uri("/img/job_list_bg3.png"); ?>) top left repeat;
    }
</style>
<?php get_header(); ?>
<?php if (is_category()) {
    $current_category = get_queried_object();
}?>
<!-- Sub banner start -->
<div class="sub-banner bg-color-full">
    <div class="container">
        <div class="breadcrumb-area">
            <h1><?php echo $current_category->name; ?> </h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <li class="active"><?php echo $current_category->name; ?> </li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub banner end -->

<!-- Candidate listing section start -->
<div class="candidate-listing-section content-area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-10">
                <?php
                // Check if we are on a category archive page
                if (is_category()) {
                    // Get the current category object
                    $current_category = get_queried_object(); ?>
                    <div class="container">

                    <h1><?php echo $current_category->name; ?></h1>
                <?php 
                    // Output the category description (if available)
                    if (!empty($current_category->description)) { ?>
                    <p><?php echo $current_category->description; ?></p>
                    <?php }
                }
                ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
