<?php get_header();?>
<style>
    .counters{
        background-image: url('<?php echo get_theme_file_uri("/img/counter.jpg"); ?>');
    }
    .intro-section{
        background-image: url('<?php echo get_theme_file_uri("/img/intro.jpg"); ?>');
    }
</style>
<!-- Banner start -->
<div class="banner bg-color-full" id="banner">
    <div id="bannerCarousole" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item banner-max-height active">
                <img class="d-block w-100 h-100" src="<?php echo get_theme_file_uri("/img/old_man_final.png"); ?>" alt="banner">
                <div class="carousel-caption banner-slider-inner d-flex text-center"></div>
            </div>
            <div class="carousel-item banner-max-height">
                <img class="d-block w-100 h-100" src="<?php echo get_theme_file_uri("/img/old_man_final.png"); ?>" alt="banner">
                <div class="carousel-caption banner-slider-inner d-flex text-center"></div>
            </div>
            <div class="carousel-item banner-max-height">
                <img class="d-block w-100 h-100" src="<?php echo get_theme_file_uri("/img/old_man_final.png"); ?>" alt="banner">
                <div class="carousel-caption banner-slider-inner d-flex text-center"></div>
            </div>
        </div>
    </div>
    <div class="banner-inner bi-2 text-left">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <div class="tc">
                        <h1>Find your job</h1>
                        <p>Explore new job opportunities and stay active </p>
                        <script>
                            $( document ).ready(function() {
                                //console.log( "ready!" );
                                $( "#searchByCategory" ).on( "click", function() {              
                                    $( "#searchByCategoryDiv" ).show();
                                    $( "#searchByLocationDiv" ).hide();
                                } );
                                //console.log( "ready!" );
                                $( "#searchByLocation" ).on( "click", function() {              
                                    $( "#searchByLocationDiv" ).show();
                                    $( "#searchByCategoryDiv" ).hide();
                                } );
                            });

                        </script>
                        <div class="inline-search-area ml-auto mr-auto none-768">
                            <form method="get" action="<?php echo site_url('search-job'); ?>">
                            <div class="search-boxs">
                                <div class="search-col">
                                    <input type="text" name="search" class="form-control has-icon b-radius" placeholder="Job title, Keywords or company name" autofocus>
                                </div>
                                <div class="search-col" id="searchByLocationDiv">
                                    <select class="form-control" style="height: 53px;" name="location">
                                        <option value="">-select-</option>
                                        <option value="Pune"> Pune</option>
                                        <option value="Baner"> Baner</option>
                                        <option value="Amaravati"> Amaravati</option>
                                        <option value="Baramati"> Baramati</option>
                                    </select>
                                </div>
                                <div class="search-col" id="searchByCategoryDiv" style="display:none;">
                                <select class="form-control" style="height:53px;" id="job_category" name="job_category" required>
                                    <?php
                                    
                                    $categories = get_terms(array(
                                        'taxonomy'   => 'job_category',
                                        'hide_empty' => false,
                                    )); ?>
                                    <option value="0">Category</option>
                                    <?php foreach ($categories as $category) {
                                    ?>
                                        <option value="<?php echo $category->term_id; ?>"><?php echo $category->name; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                                </div>
                                <div class="find">
                                    <button type="submit" name="submit" class="btn button-theme btn-search btn-block b-radius">
                                        <i class="fa fa-search"></i><strong>Find Job</strong>
                                    </button>
                                </div>
                            </div>
                            </form>
                        </div>
                        <div class="clearfix"></div>
                        <div class="browse-jobs none-768">
                            Browse job offers by <a id="searchByCategory" href="#">Category</a> or <a id="searchByLocation" href="#">Location</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Banner end -->

<!-- Popular categories strat -->
<div class="popular-categories content-area-7">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Popular Categories</h1>
            <p> Explore our most popular categories </p>
        </div>
        <div class="row">
            <?php 

            $categories = get_terms(array(
                'taxonomy'   => 'job_category',
                'hide_empty' => false,
                'number' =>8
            )); 
              foreach($categories as $category) {
                $post_count = $category->count;?>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="categorie-box">
                    <?php if($category->name == "Design and Creative"){ ?>
                        <img height="80px;" src="<?php echo get_theme_file_uri()."/img/icons/design.png"; ?>" alt="">
                    <?php }elseif($category->name == "Education and Training"){?>
                        <img height="80px;" src="<?php echo get_theme_file_uri()."/img/icons/training.png"; ?>" alt="">
                    <?php }elseif($category->name == "Healthcare and Life Science"){?>
                        <img height="80px;" src="<?php echo get_theme_file_uri()."/img/icons/health.png"; ?>" alt="">
                    <?php }elseif($category->name == "HR and Recruitment"){?>
                        <img height="80px;" src="<?php echo get_theme_file_uri()."/img/icons/hr.png"; ?>" alt="">
                    <?php }elseif($category->name == "IT and Software"){?>
                        <img height="80px;" src="<?php echo get_theme_file_uri()."/img/icons/it.png"; ?>" alt="">
                    <?php }elseif($category->name == "Marketing and Sales"){?>
                        <img height="80px;" src="<?php echo get_theme_file_uri()."/img/icons/marketing.png"; ?>" alt="">
                    <?php }elseif($category->name == "Research and Development"){?>
                        <img height="80px;" src="<?php echo get_theme_file_uri()."/img/icons/research.png"; ?>" alt="">
                    <?php }else{?>
                        <img height="80px;" src="<?php echo get_theme_file_uri()."/img/icons/others.png"; ?>" alt="">
                    <?php }?>
                    <div class="categorie-heading">
                        <h5><a href="<?php echo esc_url( add_query_arg( 'job_category', $category->term_id, site_url('jobs') ) ); ?>"><?php echo $category->name;?></a></h5>
                    </div>
                    <span>(<?php echo $post_count;?>)</span>
                </div>
            </div>
            <?php } ?>          
          
        </div>
    </div>
</div>
<!-- Popular categories end -->

<!-- Job section strat -->
<div class="job-section content-area-5 bg-grea">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Recent Jobs</h1>
            <p>Discover the latest job openings and opportunities.</p>
        </div>
        <div class="row">
            <div class="col-lg-12">
            <?php $post_count =  0;
                $args = array(
                    'post_type'      => 'job-post',
                    'posts_per_page' => 4,
                    'meta_query'     => array(
                        array(
                            'key'   => 'status',
                            'value' => 'Active'
                        )
                    )
                );
                $query  = new WP_Query( $args );
                if ($query->have_posts()) : 
                    while ($query->have_posts()) : $query->the_post(); ?>
                    <?php $post_count = $query->post_count; ?>
                    <div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="deleteConfirmLabel">Delete Confirmation</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    Are you sure you want to Delete?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    <a href="<?php echo add_query_arg( array( 'post_id' => $post->ID,
                                        'author_id'=>$_SESSION['userid'] ), site_url( 'delete-job' ) );?>" class="btn btn-danger">Delete</a>
                                </div>
                            </div>
                        </div>
                    </div>
                       <div class="job candidate-box d-flex">
                            <div class="candidate-logo">
                            <img src="<?php 
                                if (has_post_thumbnail()) {
                                    echo get_the_post_thumbnail_url(get_the_ID(), 'medium');
                                } else {
                                    echo 'https://via.placeholder.com/300x300?text=No+Image';
                                }
                            ?>" alt="logo">
                            </div>
                            <div class="description d-inline d-md-flex">
                                <div>
                                    <h5 class="title"><a href="<?php echo the_permalink(); ?>"><?php the_title(); ?></a>
                                    <?php $endDate = get_field('application_end_date');
                                    $currentDate = date('Y/m/d');
                                    if($currentDate > $endDate){ 
                                      $status =  get_field('status');
                                      update_field('status', 'In-Active');?>
                                    <div class="badge badge-secondary">Closed </div>
                                    <?php } ?></h5>
                                    <div class="candidate-listing-footer">
                                        <ul>
                                             <li><i class="flaticon-pin"></i> <?php echo get_field('location');?></li>
                                            <li><i class="flaticon-time"></i> <?php echo get_field('job_type');?></li>
                                        </ul>
                                        <h6>Deadline: <?php echo get_field('application_end_date');?></h6>
                                    </div>
                                </div>
                                <div>
                                    <a href="<?php echo get_the_permalink(); ?>" class="apply-button">view</a>
                                    <?php
                                    $author_id = get_post_field( 'post_author', get_the_ID() ); 
                                    $author_info = get_userdata( $author_id );
                                    if(isset($_SESSION['userid']) and  ($author_id == $_SESSION['userid'])){?>
                                    <a class="text-success p-2" 
                                    href="<?php echo add_query_arg( array( 'post_id' => $post->ID,'author_id'=>$_SESSION['userid'] ), 
                                    site_url( 'edit-a-job' ) ); ?>"><i class="fa fa-pencil"></i> 
                                    </a>
                                    <a class="text-danger"  data-toggle="modal" data-target="#deleteConfirm" href="<?php echo add_query_arg( array( 'post_id' => $post->ID,
                                    'author_id'=>$_SESSION['userid'] ), site_url( 'delete-job' ) );?>"><i class="fa fa-trash"></i></a>
                                    <?php }?>
                                </div>
                            </div>
                        </div>
                <?php endwhile; wp_reset_postdata(); endif; ?>
                <div class="text-center clearfix mt-2">
                    <a href="<?php echo site_url('jobs'); ?>" class="browse-all">Browse All Jobs</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Job section end -->

<!-- Counters strat -->
<div class="counters bg-color-full-2">
    <div class="container">
        <div class="row">
            <?php $users = get_users(); ?>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="counter-box">
                    <i class="flaticon-user"></i>
                    <h1 class="counter"><?php echo count($users);?></h1>
                    <p>Members</p>
                </div>
            </div>
            <?php 
            $args = array( 'post_type' => 'job-post','posts_per_page' => -1,'meta_key'=>'status',
            'meta_value'   => 'Active');
            $query  = new WP_Query( $args );
            if ($query->have_posts()) : 
                while ($query->have_posts()) : $query->the_post(); ?>
                <?php $post_count = $query->post_count; ?>
                <?php endwhile; wp_reset_postdata(); endif; ?>
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="counter-box">
                        <i class="flaticon-work"></i>
                        <h1 class="counter"><?php echo $post_count; ?></h1>
                        <p>Jobs</p>
                    </div>
                </div>
                <?php $users = get_users();
                $resume_count = 0;
                $company_count = 0;

                foreach($users as $user) {
                    $resume = get_user_meta($user->ID, 'resume', true);
                    $company = get_user_meta($user->ID, 'current_company', true);
                    
                    if (!empty($resume)) { // Check if resume meta exists and is not empty
                        $resume_count++;
                    }
                    if (!empty($company)) { // Check if resume meta exists and is not empty
                        $company_count++;
                    }
                }
            ?>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="counter-box">
                    <i class="flaticon-document"></i>
                    <h1 class="counter"><?php echo $resume_count; ?></h1>
                    <p>Resumes</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="counter-box">
                    <i class="flaticon-factory"></i>
                    <h1 class="counter"><?php echo $company_count; ?></h1>
                    <p>Companies</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Counters end -->

<!-- Testimonial start -->
<!-- <div class="testimonial">
    <div class="container">
        <div class="main-title">
            <h1>What Our Users Say</h1>
        </div>
        <div class="slick-slider-area">
            <div class="row slick-carousel" data-slick='{"slidesToShow": 2, "responsive":[{"breakpoint": 1024,"settings":{"slidesToShow": 2}}, {"breakpoint": 768,"settings":{"slidesToShow": 1}}]}'>
                <div class="slick-slide-item">
                    <div class="testimonial-inner">
                        <div class="content-box">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever</p>
                        </div>
                        <div class="media">
                            <a href="#">
                                <img src="http://placehold.it/50x50" alt="testimonial-avatar" class="img-fluid">
                            </a>
                            <div class="media-body align-self-center">
                                <h5>
                                    Eliane Perei
                                </h5>
                                <h6>Web Developer</h6>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slick-slide-item">
                    <div class="testimonial-inner">
                        <div class="content-box">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever</p>
                        </div>
                        <div class="media">
                            <a href="#">
                                <img src="http://placehold.it/50x50" alt="testimonial-avatar" class="img-fluid">
                            </a>
                            <div class="media-body align-self-center">
                                <h5>
                                    Maria Blank
                                </h5>
                                <h6>Office Manager</h6>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slick-slide-item">
                    <div class="testimonial-inner">
                        <div class="content-box">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever</p>
                        </div>
                        <div class="media">
                            <a href="#">
                                <img src="http://placehold.it/50x50" alt="testimonial-avatar" class="img-fluid">
                            </a>
                            <div class="media-body align-self-center">
                                <h5>
                                    Karen Paran
                                </h5>
                                <h6>Support Manager</h6>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slick-slide-item">
                    <div class="testimonial-inner">
                        <div class="content-box">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever</p>
                        </div>
                        <div class="media">
                            <a href="#">
                                <img src="http://placehold.it/50x50" alt="testimonial-avatar" class="img-fluid">
                            </a>
                            <div class="media-body align-self-center">
                                <h5>
                                    John Pitarshon
                                </h5>
                                <h6>Creative Director</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->
<!-- Testimonial end -->

<!-- Partners strat -->
<!-- <div class="partners content-area-15 bg-grea">
    <div class="container">
        <div class="main-title">
            <h1>Companies We've Helped</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
        <div class="slick-slider-area">
            <div class="row slick-carousel" data-slick='{"slidesToShow": 5, "responsive":[{"breakpoint": 1024,"settings":{"slidesToShow": 3}}, {"breakpoint": 768,"settings":{"slidesToShow": 2}}]}'>
                <div class="slick-slide-item"><img src="http://placehold.it/130x66" alt="brand" class="img-fluid"></div>
                <div class="slick-slide-item"><img src="http://placehold.it/130x66" alt="brand" class="img-fluid"></div>
                <div class="slick-slide-item"><img src="http://placehold.it/130x66" alt="brand" class="img-fluid"></div>
                <div class="slick-slide-item"><img src="http://placehold.it/130x66" alt="brand" class="img-fluid"></div>
                <div class="slick-slide-item"><img src="http://placehold.it/130x66" alt="brand" class="img-fluid"></div>
                <div class="slick-slide-item"><img src="http://placehold.it/130x66" alt="brand" class="img-fluid"></div>
                <div class="slick-slide-item"><img src="http://placehold.it/130x66" alt="brand" class="img-fluid"></div>
                <div class="slick-slide-item"><img src="http://placehold.it/130x66" alt="brand" class="img-fluid"></div>
            </div>
        </div>
    </div>
</div> -->
<!-- Partners end -->

<!-- Testimonial start -->
<div class="testimonial">
    <div class="container">
        <div class="main-title">
            <h1>What Our Users Say</h1>
            <p>Real stories from retirees enjoying flexible work that fits their lifestyle.</p>
        </div>
        <div class="slick-slider-area">
            <div class="row slick-carousel" data-slick='{"slidesToShow": 2, "responsive":[{"breakpoint": 1024,"settings":{"slidesToShow": 2}}, {"breakpoint": 768,"settings":{"slidesToShow": 1}}]}'>
            <?php 
            $args = array(
                'post_type' => 'testimonial',
                'posts_per_page' => -1,
                'meta_key'=>'status',
                'meta_value'   => 'Active'
                
            );
            $query = new WP_Query($args);
            
            // List view container
            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post(); ?>
                <div class="slick-slide-item">
                    <div class="testimonial-inner">
                        <div class="content-box">
                            <p><?php echo get_the_content(); ?></p>
                        </div>
                        <div class="media">
                            <a href="#">
                                <?php $url  = get_the_post_thumbnail_url(get_the_ID());?>
                                <img src="<?php if($url){ echo $url;}else { echo 'http://placehold.it/50x50';}?>" alt="testimonial-avatar" class="img-fluid">
                            </a>
                            <div class="media-body align-self-center">
                                <h5>
                                    <?php echo get_the_title();?>
                                </h5>
                                <h6><?php echo get_field('designation'); ?></h6>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                endwhile;  
                wp_reset_postdata();
                endif;
                ?>
            </div>
        </div>
    </div>
</div>
<!-- Testimonial end -->

<!-- Blog start -->
<div class="blog content-area">
    <div class="container"> 
        <!-- Main title -->
        <div class="main-title">
            <h1>Latest Blog</h1>
            <p>Stay updated with our latest insights and stories.</p>
        </div>

        <!-- Slick slider area start -->
        <div class="slick-slider-area">
            <div class="row slick-carousel" data-slick='{"slidesToShow": 3, "responsive":[{"breakpoint": 1024,"settings":{"slidesToShow": 2}}, {"breakpoint": 768,"settings":{"slidesToShow": 1}}]}'>
            <?php
                $args = array(
                'post_type'=> 'post',
                'orderby'    => 'ID',
                'post_status' => 'publish',
                'order'    => 'DESC',
                'posts_per_page' => -1 // this will retrive all the post that is published 
                );
                $result = new WP_Query( $args );
                if ( $result-> have_posts() ) : 
                    while ( $result->have_posts() ) : $result->the_post();
            ?>
                <div class="slick-slide-item">
                <?php $date = get_the_date();
                      $expl_date = explode(' ',$date); ?>
                    <div class="blog-3">
                        <div class="blog-photo">
                            <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'medium'); ?>" alt="blog" class="img-fluid" style="height:231px;">
                           
                            <div class="date-box">
                                <span><?php echo $expl_date[1]; ?></span><?php echo $expl_date[0]; ?>
                            </div>
                        </div>
                        <div class="detail">
                            <h3 class="text-truncate">
                                <a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                            </h3>
                            <div class="post-meta">
                                <span><a href="#"><i class="flaticon-male"></i><?php the_author(); ?></a></span>
                                <span><a href="#"><i class="flaticon-comment"></i><?php echo get_comments_number(); ?></a></span>
                                <!-- <span><a href="#"><i class="fa fa-heart-o"></i>27</a></span> -->
                            </div>
                            <p style="height:90px;overflow-y:hidden;"><?php echo get_the_excerpt(); ?></p>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php endif; wp_reset_postdata(); ?>

            </div>
            <div class="slick-prev slick-arrow-buton">
                <i class="fa fa-angle-left"></i>
            </div>
            <div class="slick-next slick-arrow-buton">
                <i class="fa fa-angle-right"></i>
            </div>
        </div>
    </div>
</div>
<!-- Blog end -->

<!-- Intro section -->
<div class="intro-section bg-color-full-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12">
                <div class="intro-text">
                    <h3>Gat a RetHired App</h3>
                    <p>Searching for jobs never been that easy. Now you can find job matched your career expectation</p>
                </div>
            </div>
            <div class="col-lg-5 col-md-12 col-sm-12">
                <div class="app-download-button">
                    <a href="#" class="android-app"><i class="flaticon-robot"></i>Google Play</a>
                    <a href="#" class="apple-app"><i class="flaticon-apple"></i>Apple Store</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Intro end -->

<?php get_footer(); ?>