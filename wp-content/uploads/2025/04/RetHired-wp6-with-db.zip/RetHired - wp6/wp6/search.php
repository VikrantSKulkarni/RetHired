<?php get_header(); ?>

<main id="site-content" role="main">

    <header class="page-header alignwide">
        <h1 class="page-title"><?php printf( esc_html__( 'Search Results for: %s', 'twentytwenty' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
    </header><!-- .page-header -->
    <?php if ( have_posts() ) : ?>

        <div class="post-list">

            <?php
            // Start the Loop.
            while ( have_posts() ) :
                the_post();

                /*
                 * Include the post format-specific template for the content. If you want to
                 * use this in a child theme, then include a file called called content-___.php
                 * (where ___ is the post format) and that will be used instead.
                 */
                get_template_part( 'template-parts/content', get_post_format() );

            // End the loop.
            endwhile;

            // Previous/next page navigation.
            twentytwenty_the_posts_navigation();

            // If no content, include the "No posts found" template.
            else :
                get_template_part( 'template-parts/content', 'none' );

            endif;
            ?>

        </div><!-- .post-list -->

</main><!-- #site-content -->

<?php get_footer(); ?>
