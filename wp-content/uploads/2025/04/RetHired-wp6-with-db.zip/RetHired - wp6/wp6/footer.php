
<!-- Footer start -->
<footer class="footer">
    <div class="container footer-inner">
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                <div class="footer-item clearfix">
                <img class="f-logo" src="<?php echo get_theme_file_uri("/img/logos/p6-square.png"); ?>" alt="">    
                <!-- <img src="<?php ?>" alt="logo" > -->
                    <ul class="contact-info">
                        <li>
                            <i class="flaticon-pin"></i>404, V18, Balewadi High Street, Baner Pune, Maharashtra India - 411045
                        </li>
                        <li>
                            <i class="flaticon-mail"></i><a href="mailto:info@pixel6.co">info@pixel6.co </a>
                        </li>
                        <li>
                            <i class="flaticon-internet"></i><a href="https://pixel6.co/" target="__blank">info@pixel6.co </a>
                        </li>
                        <li>
                            <i class="flaticon-phone"></i><a href="tel:+91 88 0506 0506">+91 88 0506 0506 </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                <div class="footer-item">
                    <h4>Helpful Links</h4>
                    <ul class="links">
                        <li>
                            <a href="<?php echo site_url('about');?>">About Us</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('contact');?>">Contact Us</a>
                        </li>
                        <li>
                            <a href="#">Terms & Conditions</a>
                        </li>
                        <li>
                            <a href="#">Privacy Policy</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('blogs'); ?>">Blog</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                <div class="footer-item">
                    <h4>Job Seekers</h4>
                    <ul class="links">
                        <?php if(is_user_logged_in() && current_user_can('subscriber')){?>
                        <li>
                            <a href="<?php echo site_url('logout'); ?>">Logout </a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('jobs');?>">Find Job </a>
                        </li> 
                        <?php }else{?>   
                        <li>
                            <a href="<?php echo site_url('register'); ?>">Create Account </a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('jobs');?>">Find Job </a>
                        </li>
                        <?php }?>
                    </ul>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                <div class="footer-item">
                    <h4>Employers</h4>
                    <ul class="links">
                    <?php if(is_user_logged_in() && current_user_can('contributor')){?>
                        <li>
                            <a href="<?php echo site_url('logout'); ?>">Logout</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('create-a-job'); ?>">Post a Job</a>
                        </li>
                        <?php }else{?>
                        <li>
                            <a href="<?php echo site_url('register'); ?>">Create Account</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('create-a-job'); ?>">Post a Job</a>
                        </li>
                        <?php }?>
                    </ul>
                </div>
            </div>
            <!-- <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                <div class="footer-item clearfix">
                    <h4>Newsletter</h4>
                    <div class="Subscribe-box">
                        <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit.</p>
                        <form class="form-inline" action="#" method="GET">
                            <input type="text" class="form-control mb-sm-0" id="inlineFormInputName3" placeholder="Email Address">
                            <button type="submit" class="btn"><i class="fa fa-paper-plane"></i></button>
                        </form>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
</footer>
<!-- Footer end -->

<!-- Sub footer start -->
<div class="sub-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8">
                <p class="copy">&#169; <?php echo date('Y');?> <a href="https://pixel6.co/">Pixel6 Pvt.Ltd</a></p>
            </div>
            <div class="col-lg-4 col-md-4">
                <ul class="social-list clearfix">
                    <li><a href="https://www.facebook.com/" class="facebook"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" class="twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.google.com/" class="google"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#" class="rss"><i class="fa fa-rss"></i></a></li>
                    <li><a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub footer end -->

<!-- Full Page Search -->
<div id="full-page-search">
    <button type="button" class="close">X</button>
    <form action="index.html#">
        <input type="search" value="" placeholder="type keyword(s) here" />
        <button type="submit" class="btn btn-sm button-theme">Search</button>
    </form>
</div>


<!-- <script src="js/jquery-2.2.0.min.js"></script> -->
<!-- <script src="js/popper.min.js"></script> -->
<!-- <script src="js/bootstrap.min.js"></script> -->
<!-- <script  src="js/bootstrap-submenu.js"></script> -->
<!-- <script  src="js/rangeslider.js"></script> -->
<!-- <script  src="js/jquery.mb.YTPlayer.js"></script> -->
<!-- <script  src="js/bootstrap-select.min.js"></script> -->
<!-- <script  src="js/jquery.easing.1.3.js"></script> -->
<!-- <script  src="js/jquery.scrollUp.js"></script> -->
<!-- <script  src="js/jquery.mCustomScrollbar.concat.min.js"></script> -->
<!-- <script  src="js/leaflet.js"></script> -->
<!-- <script  src="js/leaflet-providers.js"></script> -->
<!-- <script  src="js/leaflet.markercluster.js"></script> -->
<!-- <script  src="js/moment.min.js"></script> -->
<!-- <script  src="js/daterangepicker.min.js"></script> -->
<!-- <script  src="js/dropzone.js"></script> -->
<!-- <script  src="js/slick.min.js"></script> -->
<!-- <script  src="js/jquery.filterizr.js"></script> -->
<!-- <script  src="js/jquery.magnific-popup.min.js"></script> -->
<!-- <script  src="js/jquery.countdown.js"></script> -->
<!-- <script  src="js/maps.js"></script> -->
<!-- <script  src="js/app.js"></script> -->

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<!-- <script  src="js/ie10-viewport-bug-workaround.js"></script> -->
<!-- Custom javascript -->
<!-- <script  src="js/ie10-viewport-bug-workaround.js"></script> -->
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-89110077-3', 'auto');
    ga('send', 'pageview');
</script>

<script>
    var latitude = 51.541216;
    var longitude = -0.095678;
    var providerName = 'Hydda.Full';
    generateMap(latitude, longitude, providerName);
</script>
</body>
</html>