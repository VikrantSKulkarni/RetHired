function validateFormlogin(event) {
    const password = document.getElementById("password").value;
    console.log("login");
    const passwordLengthErrorlogin = document.getElementById("passwordLengthError-login");
    //   const submitButton = document.querySelector('button[type="submit"]');
    var submitButtonlogin = document.querySelector('[name="login"]');
    if (password.length < 8) {
        passwordLengthErrorlogin.style.display = "block";
        submitButtonlogin.disabled = true;
    } else {
        passwordLengthErrorlogin.style.display = "none";
        submitButtonlogin.disabled = false;
    }
}
function validateFormCanCan(event) {
    const password = document.getElementById("password_can").value;
    console.log("gayu");
    const passwordLengthError = document.getElementById("passwordLengthError-can");
  //   const submitButton = document.querySelector('button[type="submit"]');
    var submitButtoncancan = document.querySelector('[name="submit"]');

    if (password.length < 8) {
        passwordLengthError.style.display = "block";
        // submitButtoncancan.disabled = true;
    } else {
        passwordLengthError.style.display = "none";
        // submitButtoncancan.disabled = false;
    }
}
document.getElementById("confirmPassword-can").addEventListener("input", validateConfirmPassword);
                     
function validateConfirmPassword(event) {
    event.preventDefault();
    
    const password = document.getElementById("password_can").value;
    const confirmPassword = document.getElementById("confirmPassword-can").value;
    const passwordLengthError = document.getElementById("passwordLengthError-can");
    const passwordMatchError = document.getElementById("passwordMatchError-can");
    const submitButton = document.querySelector('[name="submit"]');
    
    if (password.length < 8) {
        passwordLengthError.style.display = "block";
        submitButton.disabled = true;
    } else {
        passwordLengthError.style.display = "none";
        if (password === confirmPassword) {
            passwordMatchError.style.display = "none";
            submitButton.disabled = false;
        } else {
            passwordMatchError.style.display = "block";
            submitButton.disabled = true;
        }
    }
}

function validateFormemp(event) {
    const password = document.getElementById("password-emp").value;
    console.log("emp");
    const passwordLengthErroremp = document.getElementById("passwordLengthError-emp");
  //   const submitButton = document.querySelector('button[type="submit"]');
    var submitButtonemp = document.querySelector('[name="submit1"]');

    if (password.length < 8) {
        passwordLengthErroremp.style.display = "block";
        // submitButtoncancan.disabled = true;
    } else {
        passwordLengthErroremp.style.display = "none";
        // submitButtoncancan.disabled = false;
    }
}
document.getElementById("confirmPassword-emp").addEventListener("input", validateConfirmPasswordemp);
                     
function validateConfirmPasswordemp(event) {
event.preventDefault();

const password = document.getElementById("password-emp").value;
const confirmPassword = document.getElementById("confirmPassword-emp").value;
const passwordLengthError = document.getElementById("passwordLengthError-emp");
const passwordMatchError = document.getElementById("passwordMatchError");
const submitButton = document.querySelector('[name="submit1"]');

if (password.length < 8) {
    passwordLengthError.style.display = "block";
    submitButton.disabled = true;
} else {
    passwordLengthError.style.display = "none";
    if (password === confirmPassword) {
        passwordMatchError.style.display = "none";
        submitButton.disabled = false; // Enable submit button when both conditions are satisfied
    } else {
        passwordMatchError.style.display = "block";
        submitButton.disabled = true;
    }
}
}
function validateForm(event) {
    event.preventDefault();
   //  console.log("Validating form...");
    // for employer
    var email = document.getElementById("email-emp").value;
    var password = document.getElementById("password-emp").value;
    var confirmPassword = document.getElementById("confirmPassword-emp").value;
    var acceptTerms = document.getElementById("acceptTerms").checked;
    var passwordMatchError = document.getElementById("passwordMatchError");
    var submitButton = document.querySelector('[name="submit1"]');
   if (email && password && confirmPassword) {
        if (password === confirmPassword) {
            // console.log("Passwords match.");
            passwordMatchError.style.display = "none";
            submitButton.disabled = false; // Enable the submit button
        } else {
            // console.log("Passwords do not match.");
            passwordMatchError.style.display = "block";
            submitButton.disabled = true; // Disable the submit button
        }
    } else {
      //   console.log("Some fields are empty or terms are not accepted.");
        passwordMatchError.style.display = "block";
        submitButton.disabled = true; // Disable the submit button
    }
}
// Script to toggle password visibility
function togglePasswordLog(){
    console.log("toggle login");
    var passwordInput = document.getElementById('password');
    var icon = document.getElementById('eye-icon'); 

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.add('fa-eye');
        icon.classList.remove('fa-eye-slash');
    }
}
// for candidate
 function togglePasswordCan(){
    var passwordInput = document.getElementById('password_can');
    var icon = document.getElementById('eye-can'); 
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.add('fa-eye');
        icon.classList.remove('fa-eye-slash');
    }
 }
 function togglePasswordCanCconfirm(){
    var passwordInput = document.getElementById('confirmPassword-can');
    var icon = document.getElementById('eye-can-confirm'); 
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.add('fa-eye');
        icon.classList.remove('fa-eye-slash');
    }
}
// for employer
function TogglePasswordEmp(){
    var passwordInput = document.getElementById('password-emp');
    var icon = document.getElementById('eye-emp'); 
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.add('fa-eye');
        icon.classList.remove('fa-eye-slash');
    }
}

function togglePasswordEmpConfirm(){
    var passwordInput = document.getElementById('confirmPassword-emp');
    var icon = document.getElementById('eye-emp-confirm'); 
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.add('fa-eye');
        icon.classList.remove('fa-eye-slash');
    }
}
function showRegister(){
    console.log("hello");
    document.getElementById("loginForm").style.display = "none";
    // Show the registration form
    document.getElementById("registerForm").style.display = "block";
    document.getElementById("b1").classList.add("active");
    document.getElementById("loginModalLabel2").style.display = "block";
    document.getElementById("loginModalLabel").style.display = "none";
    document.getElementById("can-empl-reg-btn").style.display = "block";
}
function showLogin(){
    document.getElementById("loginForm").style.display = "block";
    // Show the registration form
    document.getElementById("registerForm").style.display = "none";
    document.getElementById("loginModalLabel2").style.display = "none";
    document.getElementById("loginModalLabel").style.display = "block";
    document.getElementById("can-empl-reg-btn").style.display = "none";
}
function showLoginFormEmp(){
    document.getElementById("loginForm").style.display = "block";
    // Show the registration form
    document.getElementById("registerForm-employer").style.display = "none";
    document.getElementById("b1").classList.add("active");
    document.getElementById("b2").classList.remove("active");
    document.getElementById("loginModalLabel2").style.display = "none";
    document.getElementById("loginModalLabel").style.display = "block";
    document.getElementById("can-empl-reg-btn").style.display = "none";
}
function CandidateBtn(){
    var candidateBtn = document.getElementById("b1");
    var employerBtn = document.getElementById("b2");
    document.getElementById("registerForm").style.display = "block";
    document.getElementById("registerForm-employer").style.display = "none";
    employerBtn.classList.remove("active");
    candidateBtn.classList.add("active");
    console.log("Candidate button clicked");
}
function employerBtn(){
    var candidateBtn = document.getElementById("b1");
    var employerBtn = document.getElementById("b2");
    document.getElementById("registerForm").style.display = "none";
    document.getElementById("registerForm-employer").style.display = "block";
    candidateBtn.classList.remove("active");
    employerBtn.classList.add("active");
    console.log("Employer button clicked");
}

// candidate-dashboard script
function previewImage(event) {
    var input = event.target;
    var reader = new FileReader();
    var chooseimg = document.getElementById('feature-image');
    reader.onload = function() {
        var imgContainer = document.getElementById('image-container');
        var img = document.getElementById('preview');
        img.src = reader.result;
        imgContainer.style.display = 'block'; 
        }
    reader.readAsDataURL(input.files[0]);
}
function removeImage() {
    var chooseimg = document.getElementById('feature-image');
    var imgContainer = document.getElementById('image-container');
    // imgContainer.style.display = 'none';
  
    // Clear the file input value to allow selecting the same file again
    chooseimg.value = '';
}


// candidate profile script
function previewImage(event) {
    var input = event.target;
    var reader = new FileReader();
    var chooseimg = document.getElementById('feature-image');
    reader.onload = function() {
        var imgContainer = document.getElementById('image-container');
        var img = document.getElementById('preview');
        img.src = reader.result;
        imgContainer.style.display = 'block'; 
     }
    reader.readAsDataURL(input.files[0]);
}
function removeImage() {
    var chooseimg = document.getElementById('feature-image');
    var imgContainer = document.getElementById('image-container');
    imgContainer.style.display = 'none';
  
    // Clear the file input value to allow selecting the same file again
    document.getElementById('feature-image').value = '';
}
function addSocialLink(containerId) {
    var container = document.getElementById(containerId);
    var input = document.createElement('input');
    input.type = 'text';
    input.className = 'form-control mb-2';
    input.name = containerId + '[]';
    container.appendChild(input);
}
// var inputField = document.getElementById("phone-number");
// inputField.addEventListener("keypress", function (event) {
//   if (/[a-zA-Z]/.test(event.key)) {
//     event.preventDefault(); 
//   }
// });
// function validateMobileNumber() {
//     console.log("i am chaypatiiuuu");
//   var mobileNumber = inputField.value;
//   if (/^\d{10}$/.test(mobileNumber)) {

//   } else {

//   }
// }


var inputField = document.getElementById("phone-number");

// Restrict input to digits only and enforce a maximum length of 10
function validatephoneNumber(event){
    var value = event.target.value;
    // Allow only digits and restrict length to 10
    event.target.value = value.replace(/[^0-9]/g, '').slice(0, 10);
    // console.log(event.target.value);
};

// Prevent entering more than 10 digits
inputField.addEventListener("keydown", function (event) {
    if (event.target.value.length >= 10 && event.keyCode !== 8 && event.keyCode !== 46) {
        event.preventDefault();
    }
});






// create-a job script
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('add-skill').addEventListener('click', function () {
        var container = document.getElementById('skills-container');
        var inputGroup = document.createElement('div');
        inputGroup.className = 'input-group mb-2';
        var input = document.createElement('input');
        input.type = 'text';
        input.name = 'skills[]';
        input.className = 'form-control';
        input.placeholder = 'Add Skills*';
        var removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'btn btn-danger remove-skill';
        removeBtn.textContent = 'Remove';
        removeBtn.addEventListener('click', function () {
            inputGroup.remove();
        });
        inputGroup.appendChild(input);
        inputGroup.appendChild(removeBtn);
        container.appendChild(inputGroup);
    });
    // Event delegation for dynamically added remove buttons
    document.addEventListener('click', function (event) {
        if (event.target.classList.contains('remove-skill')) {
            event.target.parentElement.remove();
        }
    });
});

function modalDisplay() {
    console.log("logout is clickkk");
    var modal = $('#logoutModal');
    modal.modal('show');
}


function removeImage(){
    var imgPre =  document.getElementById('imagePreview');
    var rmBtn = document.getElementById('rmBtn');
    imgPre.removeAttribute('src');
    rmBtn.style.display='none';
}
function previewImage(event) {
var input = event.target;
var reader = new FileReader();
var rmBtn = document.getElementById('rmBtn');
    

reader.onload = function(){
    var dataURL = reader.result;
    var imagePreview = document.getElementById('imagePreview');
    imagePreview.src = dataURL;
    rmBtn.style.display='block';
};

reader.readAsDataURL(input.files[0]);
}

function removeBannerImage(){
    var imgPre =  document.getElementById('bannerImagePreview');
    var rmBannerBtn = document.getElementById('rmBannerBtn');
    imgPre.removeAttribute('src');
    rmBannerBtn.style.display='none';
}
function previewBannerImage(event) {
var input = event.target;
var reader = new FileReader();
var rmBannerBtn = document.getElementById('rmBannerBtn');
    

reader.onload = function(){
    var dataURL = reader.result;
    var imagePreview = document.getElementById('bannerImagePreview');
    imagePreview.src = dataURL;
    rmBannerBtn.style.display='block';
};

reader.readAsDataURL(input.files[0]);
}
 

function viewResume(event){
    document.querySelectorAll('#resume-alert-trigger').forEach(function(element) {
            event.preventDefault();
            alert('Please upload your resume.');
        });
    ;
}
    // Function to calculate age
    function calculateAge() {
        var dob = document.getElementById("date-of-birth").value;
        var dobDate = new Date(dob);
        var today = new Date();
        var age = today.getFullYear() - dobDate.getFullYear();
        var m = today.getMonth() - dobDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < dobDate.getDate())) {
            age--;
        }
        //document.getElementById("age").innerText = "Your age is: " + age;
        document.getElementById("age").value = age;
    }

    // Call calculateAge function when the date input changes
    //document.getElementById("date-of-birth").addEventListener("change", calculateAge);
