<?php
 $_SESSION = [];
echo "<script type='text/javascript'>window.location.href='". site_url("/home") ."'</script>";
exit;
?>
