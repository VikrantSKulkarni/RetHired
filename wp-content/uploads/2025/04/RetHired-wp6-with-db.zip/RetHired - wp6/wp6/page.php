<?php
    global $post;
    $pageName = $post->post_name;
    $custom_template = locate_template('template-parts/content-' . $pageName . '.php');

    if ($custom_template) {
        get_header();
        // Load the custom template if it exists
        get_template_part('template-parts/content', $pageName);
        //get_footer();
    } else { 
        include(get_template_directory() . '/template-parts/content-dashboard-header.php'); 
        ?>
        <div class="container pt-5 pb-5">
            <div class="mt-5 pt-5">
                <?php the_content(); ?>
            </div>
        </div>
        <?php get_footer();
     }
?>